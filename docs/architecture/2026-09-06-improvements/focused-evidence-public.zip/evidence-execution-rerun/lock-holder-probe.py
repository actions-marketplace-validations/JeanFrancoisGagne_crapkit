"""Record launcher identity and release after terminating the actual lock holder."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile

from crapkit.errors import ToolError
from crapkit.locks import exclusive_lock


OWNER = '''import os, sys
from pathlib import Path
from crapkit.locks import exclusive_lock
with exclusive_lock(Path(sys.argv[1]), label='probe'):
    print(os.getpid(), flush=True)
    sys.stdin.readline()
'''

with tempfile.TemporaryDirectory(prefix="holder-", dir=Path(__file__).parent) as directory:
    path = Path(directory) / "owner.lock"
    child = subprocess.Popen([sys.executable, "-c", OWNER, str(path)],
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, text=True)
    holder = int(child.stdout.readline())
    try:
        with exclusive_lock(path, label="probe"):
            busy = False
    except ToolError:
        busy = True
    os.kill(holder, signal.SIGTERM)
    child.communicate(timeout=10)
    with exclusive_lock(path, label="probe"):
        print(json.dumps({"interpreter": sys.executable, "launcher_pid": child.pid,
                          "holder_pid": holder, "different_processes": child.pid != holder,
                          "busy_before_holder_death": busy, "reacquired_after_holder_death": True,
                          "launcher_exit": child.returncode}))
