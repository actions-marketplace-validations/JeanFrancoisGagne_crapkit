# RT1 bounded admission review

The review found no new compatibility regression in RT1. One existing finite-number admission defect remained and is repaired in commit `78378fa` on branch `architecture/config-review-20260906`, based on integrated commit `39f610c`.

## Confirmed defect and repair

A 401-digit integer for `crapkit.tighten_max_jump` passed type/minimum admission, then `config.py:770` converted it with `float(...)`. Public `inventory --json` exited 1 with empty stdout and an OverflowError traceback. The same defect existed before `5511b47`; it was not introduced by the shared contract.

`config_contract.py` now checks fields declared as `number` for finite float representability before configuration construction. It catches OverflowError at that numeric boundary and raises ConfigError with the field name. Fields declared as `integer` keep their exact arbitrary-size values. The CLI adds no broad exception handler.

The test-first public config and inventory regressions both failed before the repair. After it, 164 focused configuration, shape, schema and CLI checks passed. Tests retain a 401-digit `max_file_bytes` value and admit `sys.float_info.max`. The active commit hook passed, source compilation passed, and the largest function in config_contract.py has CCN 5.

## Inspected coverage

- Read the complete shared field contract and config construction delta from `5511b47`.
- Read doctor key derivation and the public doctor load path. Configuration admission precedes doctor findings.
- Compared the generated editor schema to `schema()` and checked doctor key sets.
- Read existing config shape, numeric/boolean admission, configuration defaults and public inventory tests before adding edge cases.
- Replayed five older valid forms through the pre-RT1 and current loaders: minimal scope, root scope, lane defaults, explicit options/maps/booleans and unknown future fields. They produced identical configuration values.
- Replayed 12 malformed nested-array/map, boolean, NaN and infinity inputs. Each produced ConfigError with its field path.
- Confirmed numeric environment/scoped-test coercion is deliberately refused: the prior published schema and docs already declared string values.

`rt1-review-probe.py` and `rt1-review-probe.txt` preserve the old/new comparison and public traceback. `rt1-overflow-red.log` holds the two failing regressions; `rt1-overflow-green.log` holds the 164 passing checks. All probes ran outside root with explicit PYTHONPATH and bytecode writes disabled. The repair ran in the isolated config-review worktree; root source stayed frozen. No full suite, self-coverage run, install or additional review scope was started.
