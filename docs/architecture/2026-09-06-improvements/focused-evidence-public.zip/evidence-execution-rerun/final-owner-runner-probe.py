"""A direct runner must not remove evidence held by a measurement owner."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import crapkit
from crapkit.config import Lane
from crapkit.lanes import measurement_owner


ROOT = Path(r"C:\Users\jfgag\crapkit")
assert Path(crapkit.__file__).resolve() == ROOT / "src/crapkit/__init__.py"
CHILD = '''import importlib.util, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location('suite_runner', sys.argv[1])
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
def stop_before_pytest(*args):
    raise RuntimeError('probe stopped at first suite command')
runner._suite = stop_before_pytest
runner.run_suites(Path(sys.argv[2]), coverage=True)
'''

with tempfile.TemporaryDirectory(prefix="owned-runner-", dir=Path(__file__).parent) as directory:
    fixture = Path(directory)
    output = fixture / ".crapkit/cov"
    output.mkdir(parents=True)
    files = [output / "py.json", output / "junit.xml"]
    for path in files:
        path.write_text("owned measurement evidence", encoding="utf-8")
    lane = Lane(name="py", command="unused", artifact=".crapkit/cov/py.json",
                parser="coveragepy", scopes=(), results_artifact=".crapkit/cov/junit.xml")
    with measurement_owner(fixture, [lane]) as owner:
        result = subprocess.run([sys.executable, "-c", CHILD,
                                 str(ROOT / "tools/testing/run.py"), str(fixture)],
                                capture_output=True, text=True, timeout=20)
        owner.check()
        print(json.dumps({"source": str(crapkit.__file__), "owner_still_alive": True,
                          "child_reached_suite_boundary": "probe stopped" in result.stderr,
                          "child_exit": result.returncode,
                          "owned_files_still_present": [path.exists() for path in files]}))
