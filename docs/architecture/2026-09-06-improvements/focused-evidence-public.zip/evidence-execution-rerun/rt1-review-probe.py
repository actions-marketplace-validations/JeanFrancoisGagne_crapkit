import copy, json, subprocess, sys, tempfile, types
from pathlib import Path
import crapkit
from crapkit.config import load_config_text
from crapkit.config_contract import schema, known_keys, admit
from crapkit.errors import ConfigError
root=Path("C:/Users/jfgag/crapkit")
assert Path(crapkit.__file__).resolve()==root/"src/crapkit/__init__.py"
old=types.ModuleType("crapkit._rt1_before")
sys.modules[old.__name__]=old
source=subprocess.check_output(["git","show","5511b47^:src/crapkit/config.py"],cwd=root,encoding="utf-8")
exec(compile(source,"<config-before-RT1>","exec"),old.__dict__)
scope='[[scope]\nname="src"\npaths=["src"]\nlanguages=["python"]\n'.replace('[[scope]','[[scope]]')
lane='[[lane]]\nname="py"\ncommand="run"\nartifact="cov.json"\nparser="coveragepy"\nscopes=["src"]\n'
def outcome(loader,text):
    try:
        value=loader(text)
        return {"accepted":True,"value":str(value)}
    except Exception as error:
        return {"error":type(error).__name__,"message":str(error)}
valid={"minimum":scope,"root_scope":scope.replace('["src"]','["."]'),
       "lane":scope+lane,"options":'[crapkit]\ntighten_max_jump=1\nanalysis_workers=0\nscoped_tests={src="run"}\nnotes=["one"]\n'+scope+lane+'env={COUNT="1"}\nfull_suite=false\ncontainer_ok=false\n',
       "unknown_future":'[crapkit]\nnew_field={nested=[true]}\n'+scope}
print("COMPAT",json.dumps({name:{"before":outcome(old.load_config_text,text),"after":outcome(load_config_text,text)} for name,text in valid.items()}))
malformed={"nested_path":scope.replace('["src"]','[["src"]]'),"nested_language":scope.replace('["python"]','[["python"]]'),
           "map_in_path":scope.replace('["src"]','[{file="src"}]'),"notes_bool":scope+'notes=[true]\n',
           "scope_bool":scope+'coverage_optional=1\n',"nested_env":scope+lane+'env={A={B="x"}}\n',
           "array_env":scope+lane+'env=["x"]\n',"bool_env":scope+lane+'env={A=true}\n',
           "nested_scoped":'[crapkit]\nscoped_tests={src=["run"]}\n'+scope,
           "infinity":'[crapkit]\ntighten_max_jump=inf\n'+scope,"nan":'[crapkit]\ntighten_max_jump=nan\n'+scope,
           "bool_integer":'[crapkit]\nmutation_workers=true\n'+scope}
print("MALFORMED",json.dumps({name:outcome(load_config_text,text) for name,text in malformed.items()}))
published=json.loads((root/'crapkit.schema.json').read_text(encoding='utf-8'))
print("SCHEMA_MATCH",published==schema())
print("DOCTOR_KEYS",json.dumps({name:sorted(keys) for name,keys in known_keys().items()}))
large='[crapkit]\ntighten_max_jump='+('1'+'0'*400)+'\n'+scope
print("LARGE_INTEGER",json.dumps({"before":outcome(old.load_config_text,large),"after":outcome(load_config_text,large)}))
with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as scratch:
    path=Path(scratch)
    (path/'crapkit.toml').write_text(large,encoding='utf-8')
    result=subprocess.run([sys.executable,'-B','-m','crapkit','inventory','--json'],cwd=path,text=True,encoding='utf-8',capture_output=True)
    print("CLI_LARGE_INTEGER",json.dumps({"returncode":result.returncode,"stdout":result.stdout,"stderr":result.stderr}))
