# Execution completion

EX1, EX2 and EX3 are complete in branch `architecture/execution-fixes-20260906`. The checkout is `work/implementation/execution-rerun`. All commits ran the active repository hook with this checkout's `src` on PYTHONPATH. No editable installation, root edit, push, publishing operation or ratchet ceiling change occurred.

| Slice | Commit | Result |
|---|---|---|
| EX2 init scope ownership | `c672bb4` | Init uses universe ownership for root, file, directory and bidirectional overlap; deletes three private scope predicates. |
| Shared OS lock | `837b115` | `exclusive_lock(path, *, label)` uses nonblocking kernel ownership and retains its stable lock file. |
| EX1 automatic reuse | `193c643` | Reuse requires the same clean HEAD, lane/config/environment hashes and matching parsed coverage/JUnit bytes. |
| EX3 measurement ownership | `43bcc1e` | Ownership covers reuse admission, execution, parsing and stamp publication; command cleanup precedes release after caller death. |

## Evidence

Every test command ran from `execution-rerun` with `$env:PYTHONPATH=(Join-Path (Get-Location).Path 'src')`, using `python -m pytest <paths> -n0 -p no:randomly`. Logs preserve the output. `ccn-final.txt` also proves `crapkit.__file__` resolves to this checkout.

| Log | Focused check | Result |
|---|---|---|
| `ex2-focused.log` | Init overlap, discovery, universe and root finding | 64 passed |
| `locks-green.log` | Actual competing processes, crash release and independent files | 4 passed |
| `ex1-focused.log` | Reuse, scope gaps, lane abort/refusal and scheduling | 134 passed; one generated-output fixture failure |
| `ex1-fixture-green.log` | Corrected fixture ignores generated `.coverage` files | 3 passed |
| `ex1-inproc.log` | Public CLI inventory/coverage/rescore | 34 passed |
| `ex3-focused.log` | Process deadlines, retries, literal retest arguments and parallel lanes | 57 passed |
| `ex3-reuse-integration.log` | Reuse, Git facts, CLI and ownership integration | 147 passed |
| `ex3-final-lanes.log` | Lane failures, scope checks, refusal and ownership | 97 passed |
| `ex3-readside.log` | Uncovered readers and owner failure paths | 22 passed, 1 Windows platform skip |
| `ex3-final-owner.log` | Final public concurrency/crash/retest/worktree and owner checks | 12 passed, 1 Windows platform skip |
| `ex3-hook.log` | Explicit staged hook; commit then ran the same active hook | Passed |
| `ccn-final.txt` | Compile touched source and calculate function complexity | Maximum CCN 6 |

These batches overlap. Their counts are separate checks, not a claimed unique test total. The red logs record the failures before each repair: `ex1-red.log`, `ex1-dirty-red.log`, `ex1-environment-red.log`, `ex1-artifacts-red.log`, `ex2-red.log`, `locks-red.log`, `ex3-red.log` and `ex3-path-red.log`.

## Decisions and compatibility

EX1 uses clean repository proof instead of copying or hashing the entire dirty checkout. Tracked and untracked changes, including a second edit to an already dirty path, cause another measurement. A new commit also reruns every lane. Old stamps have no complete input proof and cannot qualify. The inherited environment is hashed; values are never persisted in the stamp. `--reuse-artifacts` keeps its deliberate artifact-only behavior and existing source-staleness warning. Ignored inputs other than `crapkit.toml`, installed dependencies, external files and services remain outside Git proof; their changes require a fresh measurement.

EX2 calls the existing universe predicates. Root aliases `.`, `./`, nested paths, file scopes and both overlap directions use the same ownership rule as inventory. The existing Git discovery stop still permits an independent nested repository.

EX3 uses one small guardian per measurement batch, plus a blocked launch process for each executed command. The command cannot run until the guardian registers its PID. The guardian keeps the output locks until registered command trees stop when the calling CLI disappears. Coverage maps and parsed results stay in the caller. Within-run lane threads remain parallel. An independent Git worktree with separate artifacts remains independent. Resolved shared artifacts are exclusive across checkout roots and TEMP/TMP settings.

Artifact lock files live under `.crapkit` beside each resolved artifact. A checkout's log/stamp lock is `.crapkit/measurement.lock`. The directories must be writable; lock files remain after release. Nonblocking conflict returns a measurement-in-use refusal. Existing config validation already rejects two lanes sharing one declared artifact. No second scheduling system or command broker was added.

A lock owned only by the caller failed the hard-kill requirement because its suite survived it. Separate parent/command locks also leave a handoff gap. The guardian removes that gap while keeping metric and coverage processing in place. Windows retains process handles during registration to prevent PID reuse from targeting another process. POSIX replaces the launch barrier with the shell, preserving signed signal return codes.

## Cost and platform evidence

`ownership-cost.py` ran 20 interleaved plain/owned pairs. `ownership-cost.json` contains raw samples, Python version and source hashes. Medians on this Windows/Python 3.11 host were 55.9 ms for a plain shell plus Python no-op, 174.4 ms for an owned operation, 59.8 ms for guardian startup, and 110.0 ms for a command under an existing owner. The added cost was about 60 ms per measurement batch plus 54 ms per executed command. These are local measurements, not a CI timing budget.

Real Windows tests proved hard CLI termination, timeout cleanup, idle deadlines, competing processes, retry literals, retest exclusion, shared absolute artifacts and independent Git worktrees. POSIX locking and process-group handling remain in the implementation; the new POSIX signal-exit regression is skipped on Windows and awaits integrated Linux CI. No full suite or configured self-coverage run was started from this worktree.

## Integration

Root already integrated EX1/EX2 and the shared lock. Cherry-pick `43bcc1e` for the remaining source and tests. `lane_unchanged` now takes only `(root, lane)`; all callers and tests migrated, including the single approved `uncovered.py` call. `run_lane` accepts an optional owner for the existing lane orchestrator, and `run_bounded` accepts the same owner for command registration. Retest obtains the same output ownership itself. JUnit provenance adds `results_artifact_sha256` beside the existing coverage digest.

Root owns public docs and the integrated full coverage/verify run. The broader reuse contract, writable artifact directories and measured helper cost were sent to root. `decisions.tsv` records this task's decisions separately from the root log.
