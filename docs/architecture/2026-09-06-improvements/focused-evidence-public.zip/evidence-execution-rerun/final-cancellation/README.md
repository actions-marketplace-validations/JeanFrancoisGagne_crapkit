# Ownership and cancellation test repairs

Commit `ec6bfe1dfcc7f6302e5088f811b980f6cf0a63f7` changes only tests. Active hooks
and an explicit `hook-precommit` check passed. Production `procs.py` matches
frozen root 9e08454 byte for
byte, SHA-256 `63e8864dffe81beecffdf642757629c8ca5c42ba1082ce07e43099056f60aa5b`.
No production deadline, idle budget, ratchet ceiling or override changed.

## Root failure

`root-unit-failure.txt` contains the original configured-root traceback. The
ownership-release test completed its exit-7 command and reacquired ownership,
then its no-op Python command returned `None` at the incidental five-second
deadline. Root unit results were 1 failed, 3637 passed, 1 skipped in 1370.67 s.
The same frozen source passed all 3638 applicable clean-wheel unit tests.

The test now uses no deadline for these two normal completions. Its assertions
still require exit codes 7 and 0 across release and reacquisition. Actual timeout
and idle behavior remain the subject of the unchanged `test_procs.py` tests.

The traceback proves a deadline expiry. It does not identify whether scheduling,
coverage startup, coverage shutdown or another machine cost consumed the time.
`root-environment.json` records the older global dependency set used by that run.

## Missing cancellation branch

The completed CI attempt `attempt-8975pq86` had passing candidate tests but a
refused verdict. `run_bounded` covered only branch 284 to 286. Branch 284 to 285,
which kills a still-live command after an exception, was missing. CCN 6 and
branch coverage 0.5 produced CRAP 10.5.

The new `test_owned_interrupt.py` starts a real parent and grandchild. Both hold
separate OS locks before the test injects `KeyboardInterrupt` at the subprocess
wait boundary. It then requires both locks to be available and measurement
ownership to be reusable. Plain and owned commands share the same assertions.

This tests exception cleanup. It does not claim to test Windows signal delivery.
An initial `_thread.interrupt_main` experiment waited for each child's natural
60-second exit and took 123.70 seconds for two cases. A four-second trace then
showed the exception arriving after the child exited, taking branch 284 to 286.
That design was discarded.

## Regression sensitivity

`without-cancellation-cleanup/crapkit` is a disposable copy of the package. Its
single deliberate mutation replaces the live-child `_kill_tree(proc)` call
inside `run_bounded` with `pass`. Neither repository's source was changed.

Running the new tests with that directory as `PYTHONPATH` failed both cases in
2.54 seconds because the real parent lock remained held. `red.log` records both
failures. Cleanup stops the known fixture PIDs when an assertion fails.

## Focused validation

`passing.log` records 11 passed and 1 POSIX-only skip in 45.21 seconds under
branch coverage. It includes both new cases, all ownership and exclusive-lock
checks, and the existing deadline-kind check.

`passing.json` contains the measured artifact. `function-coverage.json` extracts
the actual `run_bounded` result: 11 of 11 statements, 2 of 2 branches, no missing
lines or branches, CCN 6 and CRAP 6.

A broader instrumented run overlapped root's eight-worker E2E run and reported
19 passed, 1 skipped and two failures in unchanged timing tests. The idle kill
took 6.14 seconds against its existing five-second ceiling, and a chatty child
hit its existing one-second idle deadline. `focused-under-load.log` retains
those results. Their budgets remain unchanged. Root had already passed both
checks under coverage in its full unit run; the clean-wheel unit run passed them
too. After root E2E finished, the same two unchanged tests passed under the same
global coverage setup in 7.84 seconds. `quiet.log` records that single quiet
rerun. The result supports machine contention as the cause of the two temporary
timing failures; it does not identify the resource that delayed them.

Commands ran from the isolated `runner-review` checkout with `PYTHONPATH` set to
that checkout's `src`. The deliberate red run instead selected the disposable
mutated package. No root source, test, artifact, stamp or ledger was modified.

```powershell
$env:PYTHONPATH = (Join-Path (Get-Location) 'src')
$env:COVERAGE_FILE = (Join-Path (Split-Path (Get-Location)) 'evidence-execution-rerun/final-cancellation/.coverage-admitted')
python -B -m pytest tests/unit/test_owned_interrupt.py tests/unit/test_measurement_owner.py tests/unit/test_exclusive_lock.py tests/unit/test_procs.py::test_run_bounded_says_which_deadline_killed_the_tree -n 0 -p no:randomly --cov=crapkit --cov-branch --cov-report=json:../evidence-execution-rerun/final-cancellation/passing.json
```
