# EX1 read-side repair

Commit: `8fe0d5f2b37ae110a2ef7bda249eca01fb4aa559`.

Checkout: `work/implementation/config-review`, branch
`architecture/config-review-20260906`. Parent `78378fa` contains the separate
numeric admission fix on integrated baseline `39f610c`. This commit changes four
files and can be applied independently of the numeric fix. The checkout is clean.

## Cause and change

All three saved self-coverage failures reproduced before the fix:

| Public test | Observation |
|---|---|
| `test_every_field_the_brief_published_before_is_unchanged` | Missing lines became `null` instead of `[4, 6, 16]` |
| `test_the_text_brief_keeps_its_lines_and_appends_the_new_ones` | The uncovered-line text disappeared |
| `test_a_new_commit_refreshes_to_the_answer_a_rebuild_gives` | The traced read returned `null`; the ordinary read returned `[]` |

The brief fixture leaves `.crapkit/` and `cov.json` unignored. Its successful
coverage receipt therefore has no automatic-reuse input proof. The churn fixture
has a complete receipt, but its traced read adds `GIT_TRACE2_EVENT` to the process
environment. Neither case changes source line locations.

`uncovered._artifact_state` previously called the strict automatic-reuse predicate.
It now calls `lanes.lane_sources_unchanged`. That function checks the existing
artifact and commit stamp, write refusals, commit ancestry and changes under the
lane's scope paths. It shares the command's `GitFacts` across lanes.

`cli.scoring` still calls strict `lane_unchanged`. Automatic reuse still requires
the same clean commit, command/config/environment and measured artifact bytes.
Explicit artifact reuse retains its existing behavior.

The read-side rule remains conservative: any edit under a configured scope path
makes the lane's line numbers stale. Legacy commit stamps can support display,
but never automatic reuse. Missing artifacts/stamps, recorded write refusals,
lost ancestry and Git errors suppress line display. No receipt format changed.

## Verification

Every Python command used this checkout's `src` through explicit `PYTHONPATH`.
`read-side-receipts.log` proves the imported package path, records both receipt
states, confirms the three failures in `self-first-junit.xml`, and records CCN.

| Check | Result | Log |
|---|---:|---|
| Original three public failures before fix | 3 failed | `read-side-existing-red.log` |
| New input/display cases before fix | 7 failed, 2 passed | `read-side-new-red.log` |
| Shared Git facts before fix | 1 failed | `read-side-facts-red.log` |
| Original three plus new public regressions | 12 passed | `read-side-public-green.log` |
| Freshness, report, Git facts and refusal unit tests | 63 passed | `read-side-unit-final.log` |
| Strict input reuse, explicit reuse, refusal and churn tests | 28 passed | `read-side-compatibility.log` |
| Explicit hook and commit hook | passed | `read-side-hook.log`, `read-side-commit.log` |

The new Istanbul fixture has no dark statements. Its initial expected `[3]`
mistook a missed branch for a missed statement. The corrected assertion expects
`[]`, preserving the distinction from unavailable `null`. The original brief
fixture separately proves positive line lists survive unchanged.

Changed production CCN: `_artifact_commit` 3, `lane_sources_unchanged` 4,
`lane_unchanged` 4, `_artifact_state` 3. Compilation and `git diff --check` pass.
No full suite, full coverage, threshold change or root checkout edit was made.

## Replay

Run from `work/implementation/config-review` in PowerShell:

```powershell
$env:PYTHONPATH=(Join-Path (Get-Location).Path 'src')
python -m pytest tests/e2e/test_brief_packet_e2e.py::test_every_field_the_brief_published_before_is_unchanged tests/e2e/test_brief_packet_e2e.py::test_the_text_brief_keeps_its_lines_and_appends_the_new_ones tests/e2e/test_churn_log_e2e.py::test_a_new_commit_refreshes_to_the_answer_a_rebuild_gives tests/e2e/test_lanes_scope_gaps.py -k 'uncovered_lines or test_every_field_the_brief_published_before_is_unchanged or test_the_text_brief_keeps_its_lines_and_appends_the_new_ones or test_a_new_commit_refreshes_to_the_answer_a_rebuild_gives' -n0 -p no:randomly
python -m pytest tests/unit/test_git_facts.py tests/unit/test_report_command.py tests/unit/test_uncovered.py tests/unit/test_uncovered_notes.py tests/unit/test_lane_reuse_refusal.py -n0 -p no:randomly
python -m pytest tests/e2e/test_measurement_inputs_e2e.py tests/e2e/test_lane_reuse_e2e.py tests/e2e/test_lane_reuse_refusal_e2e.py tests/e2e/test_churn_log_e2e.py -n0 -p no:randomly
```
