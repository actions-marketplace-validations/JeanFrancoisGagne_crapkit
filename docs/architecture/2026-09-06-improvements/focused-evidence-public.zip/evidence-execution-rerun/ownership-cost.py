import hashlib, json, statistics, subprocess, sys, tempfile, time
from pathlib import Path
import crapkit
from crapkit.procs import own_processes, run_bounded
root = Path(__file__).resolve().parent.parent / "execution-rerun"
assert Path(crapkit.__file__).resolve() == root / "src/crapkit/__init__.py"
command = f'"{sys.executable}" -c "pass"'
samples = {"plain": [], "owned_total": [], "owner_start": [], "owned_command": []}
with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as scratch:
    lock = Path(scratch) / "measurement.lock"
    for sample in range(20):
        for mode in (("plain", "owned_total") if sample % 2 else ("owned_total", "plain")):
            started = time.perf_counter()
            if mode == "plain":
                assert run_bounded(command, 10) == 0
            else:
                with own_processes([lock]) as owner:
                    samples["owner_start"].append((time.perf_counter() - started) * 1000)
                    command_start = time.perf_counter()
                    assert run_bounded(command, 10, owner=owner) == 0
                    samples["owned_command"].append((time.perf_counter() - command_start) * 1000)
            samples[mode].append((time.perf_counter() - started) * 1000)
files = ("procs.py", "_process_owner.py", "lanes.py", "locks.py")
result = {"source": str(crapkit.__file__), "python": sys.version,
          "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
          "hashes": {name: hashlib.sha256((root / "src/crapkit" / name).read_bytes()).hexdigest() for name in files},
          "samples_ms": samples,
          "medians_ms": {name: statistics.median(values) for name, values in samples.items()}}
print(json.dumps(result, indent=2))
