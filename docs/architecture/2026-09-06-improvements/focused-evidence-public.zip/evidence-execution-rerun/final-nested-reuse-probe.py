"""A nested config can run tests that read tracked inputs above its root."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import crapkit

ROOT = Path(r"C:\Users\jfgag\crapkit")
assert Path(crapkit.__file__).resolve() == ROOT / "src/crapkit/__init__.py"
RUNNER = '''import json
from pathlib import Path
hit = int(Path('../checks.txt').read_text().strip() == 'pass')
output = Path('.crapkit')
output.mkdir(exist_ok=True)
count = output / 'counter'
count.write_text(str(int(count.read_text()) + 1 if count.exists() else 1))
loc = {'start': {'line': 1, 'column': 0}, 'end': {'line': 3, 'column': 1}}
data = {'src/app.js': {'path': 'src/app.js', 'fnMap': {'0': {'name': 'f', 'decl': loc, 'loc': loc}},
        'f': {'0': hit}, 'statementMap': {'0': loc}, 's': {'0': hit}, 'branchMap': {}, 'b': {}}}
(output/'cov.json').write_text(json.dumps(data))
failed = '' if hit else '<failure message="changed parent input"/>'
(output/'junit.xml').write_text('<testsuite tests="1"><testcase classname="tests" name="test_f">'
    + failed + '</testcase></testsuite>')
'''

with tempfile.TemporaryDirectory(prefix="nested-reuse-", dir=Path(__file__).parent) as directory:
    top = Path(directory)
    app = top / "app"
    (app / "src").mkdir(parents=True)
    (app / "src/app.js").write_text("function f() {\n  return 1;\n}\n")
    (app / "measure.py").write_text(RUNNER)
    (top / "checks.txt").write_text("pass")
    (top / ".gitignore").write_text(".crapkit/\n__pycache__/\n")
    command = json.dumps(f'"{sys.executable}" measure.py')
    (app / "crapkit.toml").write_text(
        '[[scope]]\nname="src"\npaths=["src"]\nlanguages=["javascript"]\n'
        '[[lane]]\nname="js"\nparser="istanbul"\nscopes=["src"]\n'
        f'command={command}\nartifact=".crapkit/cov.json"\n'
        'results_artifact=".crapkit/junit.xml"\nfull_suite=true\n')
    for args in (["init", "-q", "-b", "main"], ["add", "."],
                 ["-c", "user.name=Probe", "-c", "user.email=probe@example.test", "commit", "-qm", "fixture"]):
        subprocess.run(["git", *args], cwd=top, capture_output=True, check=True)
    results = []
    for args in (["coverage", "--json"], ["verify", "--reuse-unchanged", "--no-tighten", "--json"],
                 ["verify", "--no-tighten", "--json"]):
        if args[0] == "verify":
            (top / "checks.txt").write_text("fail")
        result = subprocess.run([sys.executable, "-m", "crapkit", *args], cwd=app,
                                capture_output=True, text=True, timeout=30)
        body = json.loads(result.stdout)
        results.append({"args": args, "exit": result.returncode,
                        "executions": int((app / ".crapkit/counter").read_text()),
                        "reused": "reusing without rerun" in result.stderr,
                        "ok": body.get("ok")})
    print(json.dumps(results))
