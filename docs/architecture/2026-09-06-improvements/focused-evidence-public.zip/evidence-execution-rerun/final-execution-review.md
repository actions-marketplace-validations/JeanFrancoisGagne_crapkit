# Final execution integration review

Reviewed source: `c20560241643f66093380ca04fc8ec91f83159ea`, against
`47629ea14ddea38e55ce2332d08297c31888acb9`.

Two actionable integration concerns were confirmed. Both have focused repairs
on `architecture/runner-isolation-20260906`, in `work/implementation/runner-review`.
A later installed-wheel failure exposed a test process-identity error, also fixed
there. No root source edits or full suite runs were made by this review.

## Confirmed concerns and repairs

| Concern at the reviewed source | Evidence | Repair commit |
|---|---|---|
| `tools/testing/run.py:110` directly deletes and rewrites the same outputs held by a measurement owner | Real owner stays alive while another process enters `run_suites`; both owned files disappear before its first suite command | `7a098fc5c760d6aa1ae74b27b11e966e0d775fdf` |
| `src/crapkit/lanes.py:469` checks dirty inputs only below the config root | A changed tracked parent test input yields reused verify exit 0 and fresh verify exit 8 | `ed2034c6168acb6bd483c561de2b9868a169795a` |
| Existing nested-coverage test still expects the old direct output destination | Fixed-path caller inspection | `045a242a642744ccd20b943ef0608d1b7ff22b91` |
| Crashed-owner test kills the Windows venv launcher instead of the lock holder | Launcher PID 69740, holder PID 71448; actual holder death immediately releases the lock | `b7ffc59555cc17d041eabd82fb3ba2845c882574` |

The direct runner now retains unique `.crapkit/test-runs/run-*` directories and
prints the selected absolute path before execution. Its optional `--output`
destination is caller-managed and must resolve inside `--repo`. The self lane
and private CI checkout explicitly select `.crapkit/cov`; ordinary direct runs
cannot overwrite those files.

A runner-only lock was rejected because it ends when the runner exits, before
the parent finishes parsing and stamping. Passing the parent's lease through
another protocol was unnecessary once direct runs had separate outputs.
An explicit output argument remains a deliberate request to replace files at
that destination. Contributor guidance states who owns those destinations.

Strict automatic reuse now asks `gitio.worktree_root` for the checkout before
reading its dirty state and HEAD. This includes tracked and untracked inputs
above a nested `crapkit.toml`. Source-line freshness, source ownership, relative
row paths and explicit artifact reuse retain their existing rules.

The lock test now receives the actual holder PID from inside its acquired lock,
terminates that process and waits for its launcher. Normal fixture cleanup closes
stdin. Production lock and guardian code did not change.

## Verification

| Check | Result | Saved evidence |
|---|---:|---|
| Direct runner against a real live owner | Both owned files removed before fix | `final-owner-runner-probe.py`, `.json` |
| New runner output tests before fix | 4 failed | `runner-output-red.log` |
| Output isolation, concurrent runners, failure retention and coverage/context schedule | 10 passed | `runner-output-green.log` |
| CI installation/verdict/failure and generated guidance callers | 10 passed | `runner-output-callers.log` |
| Existing nested coverage, no-Git refusal and unchanged reuse | 3 passed | `runner-nested-caller-green.log` |
| Nested-root public verify before fix | 2 failed, 1 unchanged control passed | `nested-reuse-red.log` |
| Complete focused measurement-input file after fix | 14 passed | `nested-reuse-green.log` |
| Read-side freshness, Git facts and report unit checks | 51 passed | `nested-reuse-read-side.log` |
| Installed-wheel lock/guardian checks | 8 passed, 1 POSIX-only skip | `lock-wheel-green.log` |
| Source-interpreter lock checks | 4 passed | `lock-source-green.log` |

The original crashed-owner test passed once in the recreated private venv. This
does not erase the recorded full-wheel-run failure. The diagnosis rests on the
distinct launcher and holder identities, and on immediate reacquisition after
killing the actual holder. No sleeps, retries or timing-threshold changes were
added. `lock-holder-proof.json` records that experiment.

The private venv installs the saved local wheel and uses existing development
dependencies. `lock-wheel-proof.log` records its interpreter and installed package
paths, and verifies its lock implementation matches the checkout. This was a
launcher/lock check, not another clean dependency-resolution run.

Every changed production/tool function remains at CCN 3 or below. Compilation,
generated guidance, diff checks, explicit staged gates and all commit hooks
passed. The checkout is clean at `b7ffc59555cc17d041eabd82fb3ba2845c882574`.

## Reviewed coverage and report corrections

| Area | Reviewed paths and flows | Disposition |
|---|---|---|
| EX1 | `lanes.py` receipt creation/reuse and source freshness; scoring reuse caller; `uncovered.py`; Git root-relative facts | Nested-root gap repaired. Scoped display rule retained. |
| EX2 | `universe.py` path matchers and overlap; admin ancestor admission; init regressions | No further finding. Root and bidirectional overlap tests remain applicable. |
| EX3 | `locks.py`, `procs.py`, `_process_owner.py`; lane, retest, parallel collection and stamp lifetimes | No new production guardian finding. Direct runner sharing repaired. |
| RT5 interaction | Shared runner, CI measurement caller, self lane command, direct workflow command, direct and imported test callers, contributor guidance | Default outputs separated; fixed consumers explicitly select their output. |

For `docs/architecture/2026-09-06-improvements/implementation.md` as read at the
start of this review:

- EX1's integrated-commit cell should name the scoped read repair (`6ab8c12`) and
  the integrated equivalent of `ed2034c`, instead of leaving the former unnamed.
- The EX3/RT5 record should include direct-output separation and the nested test
  caller migration. The timing figures for the guardian need no correction.
- RT5 should describe default retained direct-run outputs separately from the
  explicitly selected self-lane/CI measurement directory.
- Replace the pending nested-coverage wording only after the state-owned
  `COVERAGE_RCFILE` repair is integrated and checked. Its new fixed-output fixture
  also needs `--output .crapkit/cov`; that coordination was sent to its owner.

No further actionable concern was found in this bounded pass. Final full
verification remains the root task's responsibility.
