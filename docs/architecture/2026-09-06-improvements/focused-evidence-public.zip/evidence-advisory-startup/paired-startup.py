"""Compare fixed startup sources with alternating pairs and Python floors."""
import argparse
import hashlib
import io
import json
import os
import pathlib
import random
import statistics
import subprocess
import sys
import tarfile
import time


def git(repo, *words):
    return subprocess.check_output(['git', '-C', str(repo), *words])


def materialize(repo, output, baseline):
    data = git(repo, 'archive', '--format=tar', baseline, 'src')
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        for member in archive.getmembers():
            if member.isfile():
                target = output / 'source-A' / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.extractfile(member).read())
    for relative in git(repo, 'ls-files', '-z', 'src').decode().split('\0'):
        if relative:
            target = output / 'source-B' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((repo / relative).read_bytes())


def child_env(source):
    env = {k: v for k, v in os.environ.items() if not k.startswith(('COVERAGE_', 'COV_CORE_'))}
    env['PYTHONPATH'] = str(source)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return env


def invoke(command, cwd, env, payload):
    start = time.perf_counter()
    result = subprocess.run([sys.executable, *command], cwd=cwd, env=env, input=payload,
                            capture_output=True, text=True, encoding='utf-8', timeout=30)
    assert result.returncode == 0, result.stderr
    return (time.perf_counter() - start) * 1000, result


def provenance(source, fixture, payload):
    probe = ("import sys,json,pathlib,crapkit; from crapkit.cli import main; "
             "assert pathlib.Path(crapkit.__file__).resolve()==pathlib.Path(sys.argv[1]).resolve(); "
             "code=main(['claude-hook','--protocol','1']); "
             "print(json.dumps({'code':code,'modules':{k:v.__file__ for k,v in sys.modules.items() "
             "if k.startswith('crapkit') and hasattr(v,'__file__')}}))")
    _, result = invoke(['-c', probe, str(source / 'crapkit/__init__.py')], fixture, child_env(source), payload)
    return json.loads(result.stdout)


def sample(envs, fixture, payload, count):
    hook = ['-m', 'crapkit', 'claude-hook', '--protocol', '1']
    for env in envs.values():
        invoke(hook, fixture, env, payload)
        invoke(hook, fixture, env, payload)
    result = []
    for index in range(count):
        names = list(envs) if index % 2 == 0 else list(reversed(envs))
        floor1 = invoke(['-c', 'pass'], fixture, envs[names[0]], '')[0]
        block = {name: invoke(hook, fixture, envs[name], payload)[0] for name in names}
        floor2 = invoke(['-c', 'pass'], fixture, envs[names[1]], '')[0]
        result.append({'index': index, 'order': names, 'floor_before': floor1, 'floor_after': floor2, **block})
    return result


def interval(differences):
    rng = random.Random(1776)
    samples = sorted(statistics.median(rng.choices(differences, k=len(differences))) for _ in range(4000))
    return [samples[100], samples[3900]]


def floors(blocks):
    return [b[k] for b in blocks for k in ['floor_before', 'floor_after']]


def summarize(blocks):
    result = {}
    for name in ['baseline', 'candidate']:
        raw = [block[name] for block in blocks]
        adjusted = [block[name] - (block['floor_before'] + block['floor_after']) / 2 for block in blocks]
        result[name] = {'raw_min_ms': min(raw), 'raw_median_ms': statistics.median(raw),
                        'adjusted_median_ms': statistics.median(adjusted), 'adjusted_min_ms': min(adjusted)}
    difference = [block['candidate'] - block['baseline'] for block in blocks]
    result['candidate_minus_baseline_median_ms'] = statistics.median(difference)
    result['paired_bootstrap_median_95_percent_interval_ms'] = interval(difference)
    result['floor_median_ms'] = statistics.median(floors(blocks))
    return result


def trace(sources, fixture, payload, output):
    modules = {}
    for name, source in sources.items():
        modules[name] = provenance(source, fixture, payload)
        _, done = invoke(['-X', 'importtime', '-m', 'crapkit', 'claude-hook', '--protocol', '1'],
                         fixture, child_env(source), payload)
        (output / (name + '-importtime.txt')).write_text(done.stderr, encoding='utf-8')
    compared = {}
    for name, path in modules['baseline']['modules'].items():
        base = hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
        candidate = hashlib.sha256(pathlib.Path(modules['candidate']['modules'][name]).read_bytes()).hexdigest()
        compared[name] = {'baseline': base, 'candidate': candidate, 'equal': base == candidate}
    return {'modules': modules, 'module_hashes': compared}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=pathlib.Path, required=True)
    parser.add_argument('--output', type=pathlib.Path, required=True)
    parser.add_argument('--baseline', default='47629ea')
    parser.add_argument('--samples', type=int, default=50)
    args = parser.parse_args()
    import crapkit
    assert pathlib.Path(crapkit.__file__).resolve() == args.repo.resolve() / 'src/crapkit/__init__.py'
    args.output.mkdir(parents=True, exist_ok=True)
    materialize(args.repo, args.output, args.baseline)
    fixture = args.output / 'fixture'
    (fixture / '.git').mkdir(parents=True, exist_ok=True)
    (fixture / 'calc').mkdir(exist_ok=True)
    (fixture / 'calc/grade.py').write_text('def f():\n    return 1\n')
    payload = json.dumps({'hook_event_name': 'PostToolUse', 'tool_name': 'Edit', 'cwd': str(fixture),
                          'tool_input': {'file_path': str(fixture / 'calc/grade.py')}})
    sources = {'baseline': args.output / 'source-A/src', 'candidate': args.output / 'source-B/src'}
    blocks = sample({k: child_env(v) for k, v in sources.items()}, fixture, payload, args.samples)
    result = {'baseline_ref': git(args.repo, 'rev-parse', args.baseline).decode().strip(),
              'candidate_ref': git(args.repo, 'rev-parse', 'HEAD').decode().strip(), 'python': sys.version,
              'coverage_env_removed': True, 'bytecode_writes': False, 'samples': blocks,
              'summary': summarize(blocks), 'provenance': trace(sources, fixture, payload, args.output)}
    (args.output / 'results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result['summary'], indent=2))


if __name__ == '__main__':
    main()

