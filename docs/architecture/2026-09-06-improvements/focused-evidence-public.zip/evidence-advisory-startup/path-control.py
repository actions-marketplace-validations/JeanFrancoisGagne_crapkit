"""Compare the current checkout with its identical source snapshot."""
import argparse
import hashlib
import json
import pathlib
import runpy


def bytecode_files(source):
    return sorted(str(p.relative_to(source)) for p in source.rglob('*.pyc'))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=pathlib.Path, required=True)
    parser.add_argument('--evidence', type=pathlib.Path, required=True)
    args = parser.parse_args()
    import crapkit
    assert pathlib.Path(crapkit.__file__).resolve() == args.repo.resolve() / 'src/crapkit/__init__.py'
    helpers = runpy.run_path(str(args.evidence / 'paired-startup.py'))
    output = args.evidence / 'path-control'
    output.mkdir(exist_ok=True)
    sources = {'baseline': args.repo / 'src', 'candidate': args.evidence / 'source-B/src'}
    fixture = args.evidence / 'fixture'
    payload = json.dumps({'hook_event_name': 'PostToolUse', 'tool_name': 'Edit', 'cwd': str(fixture),
                          'tool_input': {'file_path': str(fixture / 'calc/grade.py')}})
    blocks = helpers['sample']({k: helpers['child_env'](v) for k, v in sources.items()}, fixture, payload, 15)
    result = {'labels': {'baseline': 'current checkout', 'candidate': 'identical source snapshot'},
              'samples': blocks, 'summary': helpers['summarize'](blocks),
              'provenance': helpers['trace'](sources, fixture, payload, output),
              'existing_package_bytecode': {k: bytecode_files(v) for k, v in sources.items()}}
    (output / 'results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result['summary'], indent=2))


if __name__ == '__main__':
    main()
