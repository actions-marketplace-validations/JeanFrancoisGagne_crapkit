# Advisory startup comparison

No production regression was found between baseline `47629ea14ddea38e55ce2332d08297c31888acb9` and the integrated source. All seven crapkit modules imported by the no-configuration path, plus the `__main__` entry file, have identical bytes. The paired timing difference spans zero. Neither a production change nor a larger timing budget is justified by this comparison.

## Paired source comparison

`paired-startup.py` extracted baseline source with `git archive` and copied the current tracked source to adjacent, equal-length paths. Both copies had no package bytecode cache and disabled bytecode writes. Each child used its selected src directory as PYTHONPATH. The child provenance probe asserted the imported package location, ran the real public CLI entry and recorded the loaded project modules. Every child ran the same no-toml PostToolUse payload from a disposable directory. The no-toml fixture has a `.git` directory, matching the root-discovery stop used by the golden test.

Fifty alternating baseline/current blocks each ran a Python floor before and after the two hooks. All timing children removed inherited COVERAGE_ and COV_CORE_ variables. Two initial calls warmed filesystem state for each source. All samples remain in `results.json`.

| Measurement, milliseconds | Baseline | Current snapshot |
|---|---:|---:|
| Hook median | 104.2395 | 106.3917 |
| Hook minimum | 89.4391 | 85.1799 |
| Median after subtracting each block's mean floor | 60.7938 | 61.0381 |
| Minimum hook minus minimum floor, matching the strict test's calculation | 53.5486 | 49.2894 |

The Python floor median was 45.0478 ms and its minimum was 35.8905 ms. The median paired current-minus-baseline difference was **-0.0812 ms**. Its seeded paired bootstrap 95% interval was **[-4.5083, +6.0484] ms**. This is no measured regression. Both fixed source snapshots exceed the 40 ms strict calculation in this measurement window. This probe did not rerun or change the strict pytest test.

The root HEAD moved from `f9c2efd5374dac0f54efaa86d993364b4791bf96` to `1a0e4ab052d9ed9133ba4c5be392371773e28fd0` during this work. That commit changed only the timing test helper; `git diff f9c2efd 1a0e4ab -- src` is empty. The snapshot therefore matches either source revision. `source-hashes.json` gives every compared module digest.

## Existing control and import traces

A final 15-block control compared current root source with its identical copied source. It made no source or cache changes in root. The checkout had 81 existing package `.pyc` files; the copied source had none. PYTHONDONTWRITEBYTECODE prevents writes, but still permits reading existing bytecode. This control therefore covers source location and existing bytecode together; it cannot isolate either cost.

| Control measurement | Result |
|---|---:|
| Root hook median | 149.1218 ms |
| Identical copied-source hook median | 153.7159 ms |
| Paired copied-minus-root median | +11.1209 ms |
| Paired bootstrap 95% interval | [+1.4382, +23.6534] ms |
| Python floor median | 71.3390 ms |

The floor rose from 45.05 to 71.34 ms between the two windows. Identical code also changed measured latency with location/cache conditions. These observations support host load and startup conditions as the explanation for the hard-to-repeat timing result. They do not identify a specific competing process or separate filesystem work from scheduling delays.

The original import traces load the same module names. Summed self import times were 77.063 ms for baseline and 74.488 ms for current. The largest cumulative entries were existing `site`, the CLI parser, `argparse`, `importlib.util`, `shutil`, and regular-expression imports. The parser cumulative times were 20.601 and 23.187 ms. These are single diagnostic traces, not another performance estimate. No new analysis stack or store import entered the no-toml path.

## Reproduce and inspect

From the projectless workspace, with PYTHONPATH set to the chosen current repository's src:

```
python work/implementation/evidence-advisory-startup/paired-startup.py --repo C:/Users/jfgag/crapkit --output C:/Users/jfgag/Documents/Codex/2026-09-06/c-users-jfgag-appdata-local-temp/work/implementation/evidence-advisory-startup --baseline 47629ea --samples 50
python work/implementation/evidence-advisory-startup/path-control.py --repo C:/Users/jfgag/crapkit --evidence C:/Users/jfgag/Documents/Codex/2026-09-06/c-users-jfgag-appdata-local-temp/work/implementation/evidence-advisory-startup
```

Files beside this report:

- `results.json`, `paired-startup.txt`: all 50 paired blocks and summaries.
- `source-hashes.json`: exact matching project source hashes.
- `baseline-importtime.txt`, `candidate-importtime.txt`: the original import traces.
- `path-control/results.json`, `path-control.txt`: the 15 control blocks, paths and cache inventory.
- `path-control/*-importtime.txt`: control import traces.
- `source-A/src`, `source-B/src`: exact compared source copies.

The replay tools accept repository/evidence paths as arguments. Their summaries were recalculated from saved samples and matched exactly; every tool function meets CCN 6. No root source, test, configuration, threshold or artifact was changed. Root retains the unmet strict opt-in budget and its own ordinary hard-budget/full-verification evidence. This bounded diagnosis is complete; no further timing variants were run.
