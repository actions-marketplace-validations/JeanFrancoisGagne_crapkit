# Dedicated configured-run runtime

Ready for the next normal configured root measurement after the pending test repairs. Preparation ran no tests, coverage command or verification command. Root tracked files, package bytes and current .crapkit artifacts were not changed.

The shared clone is detached at `9e084545e85779121943ea48346dc8f895ed0af6` in `clone/`. A clean Python 3.11.2 virtual environment is in `venv/` with system site packages disabled. The package was built once from that clone, then its wheel was installed with the declared `[dev]` extra. This is a noneditable installation. Dependencies came from the public PyPI index using pip's isolated configuration. The wheel build and pip installation used caches and temporary directories under this runtime directory.

## Start the source environment

```powershell
$runtime = 'C:/Users/jfgag/Documents/Codex/2026-09-06/c-users-jfgag-appdata-local-temp/work/implementation/configured-runtime'
$env:PATH = (Join-Path $runtime 'venv/Scripts') + [IO.Path]::PathSeparator + $env:PATH
$env:PYTHONPATH = 'C:/Users/jfgag/crapkit/src'
Set-Location -LiteralPath C:/Users/jfgag/crapkit
```

The root task chooses and starts the actual configured command. Source mode uses this venv's interpreter without `-I` so PYTHONPATH selects root's current package. `source-mode-proof.json` verifies that arrangement and confirms PATH also selects the venv's python executable. The installed-wheel proof uses `-I` to inspect the isolated installed package instead.

## Versions

| Package | Version |
|---|---|
| Python | 3.11.2 |
| pytest | 9.1.1 |
| pytest-cov | 7.1.0 |
| coverage | 7.16.0 |
| pytest-xdist | 3.8.0 |
| PyYAML | 6.0.3 |
| Pillow | 12.3.0 |
| lizard | 1.24.0 |

`dependencies.json` and `installed-distributions.txt` list all 17 installed distributions, including bootstrap packages. Pytest exposes only the pytest-cov and pytest-xdist entry points. No unrelated pytest plugin is installed in this venv. `pip-check.log` reports no broken requirements, and the proof helper checks every active package/dev requirement against its installed version.

## Package proof

Wheel: `crapkit-0.6.0-py3-none-any.whl`

SHA256: `3b1574cef99c673eab1c31254748e8c551230060beb69217d50c77a0ad7bcd46`

All 69 Python source files have identical raw bytes in the frozen clone, wheel and installed package. `wheel-package-proof.json` records the complete path/hash maps, interpreter, package location, direct wheel URL, noneditable status and declared dev requirements. Root has CRLF-only differences in `config.py` and `doctor.py`. Its raw hashes are recorded separately; comparison classified those two differences in memory and changed no bytes. The next configured root run will measure the actual root files.

The earlier source-mode package mismatch was this newline distinction, not different source logic. `source-byte-differences.json` retains that diagnostic. `prove-runtime.py` can be rerun with `venv/Scripts/python.exe -I prove-runtime.py`. Its maximum function CCN is 5.

## Retained evidence

- `setup.log` records the shared clone, wheel build and noneditable extra installation.
- `install-report.json` records downloaded distributions, URLs and hashes.
- `wheel-package-proof.json` and the wheel preserve the frozen package input.
- `dependencies.json`, `installed-distributions.txt` and `pip-check.log` record exact installed dependencies.
- `source-mode-proof.json` and `source-mode-proof.log` prove current root source plus this venv.
- `decisions.tsv` records the preparation choices.

Keep these top-level files in the final evidence collection. Exclude `clone/`, `venv/`, `cache/` and `tmp/`. This directory contains no full-test result and grants no verification pass.

Prepared: 2026-09-07T09:25:08.2825118-04:00
