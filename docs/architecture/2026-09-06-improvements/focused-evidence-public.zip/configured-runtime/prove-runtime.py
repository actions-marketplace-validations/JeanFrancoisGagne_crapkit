"""Record the frozen wheel, isolated package and declared development dependencies."""
from importlib import metadata
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

from packaging.requirements import Requirement

FROZEN = '9e084545e85779121943ea48346dc8f895ed0af6'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def package_files(package, normalize=False):
    return {p.relative_to(package).as_posix(): digest(p.read_bytes().replace(b'\r\n', b'\n') if normalize else p.read_bytes())
            for p in sorted(package.rglob('*.py'))}


def wheel_files(wheel):
    with zipfile.ZipFile(wheel) as archive:
        return {name.removeprefix('crapkit/'): digest(archive.read(name)) for name in archive.namelist()
                if name.startswith('crapkit/') and name.endswith('.py')}


def declared_requirements(distribution):
    active = []
    for value in distribution.requires or ():
        req = Requirement(value)
        if req.marker is not None and not req.marker.evaluate({'extra': 'dev'}):
            continue
        assert metadata.version(req.name) in req.specifier, str(req)
        active.append(str(req))
    return active


def installed_distributions():
    return sorted([{'name': dist.metadata['Name'], 'version': dist.version}
                   for dist in metadata.distributions()], key=lambda row: row['name'].lower())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def root_comparison(clone):
    root = Path('C:/Users/jfgag/crapkit/src/crapkit')
    current = package_files(root)
    original = package_files(clone)
    assert package_files(root, normalize=True) == package_files(clone, normalize=True)
    return {'root_source_sha256': current, 'root_source_crlf_normalized_equal': True,
            'root_newline_differences': [name for name in original if original[name] != current[name]]}


def proof(runtime):
    import crapkit
    clone = runtime / 'clone'
    package = Path(crapkit.__file__).resolve().parent
    assert package.is_relative_to(runtime / 'venv/Lib/site-packages'), package
    head = subprocess.check_output(['git', '-C', str(clone), 'rev-parse', 'HEAD'], text=True).strip()
    assert head == FROZEN, head
    wheel, = runtime.glob('crapkit-*.whl')
    source = package_files(clone / 'src/crapkit')
    assert source == package_files(package) == wheel_files(wheel)
    assert 'include-system-site-packages = false' in (runtime / 'venv/pyvenv.cfg').read_text()
    distribution = metadata.distribution('crapkit')
    direct = json.loads(distribution.read_text('direct_url.json'))
    assert direct.get('dir_info', {}).get('editable') is not True
    return {'frozen_commit': head, 'python': sys.version, 'executable': sys.executable,
            'prefix': sys.prefix, 'base_prefix': sys.base_prefix, 'package': str(package),
            'wheel': wheel.name, 'wheel_sha256': digest(wheel.read_bytes()),
            'source_sha256': source, 'source_file_count': len(source),
            'clone_installed_wheel_source_equal': True, 'direct_url': direct,
            **root_comparison(clone / 'src/crapkit'),
            'noneditable': True, 'dev_requirements': declared_requirements(distribution)}


def main():
    runtime = Path(__file__).resolve().parent
    manifest = proof(runtime)
    write_json(runtime / 'wheel-package-proof.json', manifest)
    distributions = installed_distributions()
    plugins = sorted([{'name': item.name, 'value': item.value, 'distribution': item.dist.metadata['Name']}
                      for item in metadata.entry_points(group='pytest11')], key=lambda item: item['name'])
    assert {plugin['distribution'].lower() for plugin in plugins} <= {'pytest-cov', 'pytest-xdist'}
    write_json(runtime / 'dependencies.json', {'distributions': distributions, 'pytest_plugins': plugins})
    (runtime / 'installed-distributions.txt').write_text(
        ''.join(f"{item['name']}=={item['version']}\n" for item in distributions), encoding='utf-8')
    print(json.dumps({'source_file_count': manifest['source_file_count'], 'noneditable': True, 'pytest_plugins': plugins,
                      'tests_started': False}, indent=2))


if __name__ == '__main__':
    main()
