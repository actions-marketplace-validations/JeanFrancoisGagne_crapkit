"""Synthetic analysis and coverage comparison; run with --repo and --output."""
import argparse
import hashlib
import json
import os
import statistics
import subprocess
import tempfile
import time
import tracemalloc
import types
from pathlib import Path
from unittest.mock import patch

import crapkit
from crapkit import analyze, covstream


def sample(work):
    started = time.perf_counter()
    result = work()
    return time.perf_counter() - started, result


def measured(work):
    cold, expected = sample(work)
    warm = [sample(work) for _ in range(5)]
    assert all(result == expected for _, result in warm)
    tracemalloc.start()
    result = work()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    assert result == expected
    return {"cold_seconds": cold, "warm_seconds": [s for s, _ in warm],
            "warm_median_seconds": statistics.median(s for s, _ in warm), "peak_bytes": peak}


def duplicate_analysis(root, *, unique=False):
    paths = [f"m{i}.py" for i in range(12)]
    source = "\n".join(f"def f{i}(x):\n    return 1 if x else 0\n" for i in range(100))
    for path in paths:
        text = f"# {path}\n{source}" if unique else source
        (root / path).write_text(text, encoding="utf-8")
    run = lambda: analyze.analyze_files(root, paths, cache={}, workers=1)
    result = measured(run)
    with patch.object(analyze.lizard.FileAnalyzer, "analyze_source_code",
                      autospec=True, side_effect=analyze.lizard.FileAnalyzer.analyze_source_code) as calls:
        records, _, cache = run()
    result.update(parser_calls=calls.call_count, files=len(paths), cache_entries=len(cache["entries"]),
                  output_sha256=hashlib.sha256(repr(sorted(records.items())).encode()).hexdigest())
    settled = time.time_ns() - 3600_000_000_000
    for path in paths:
        os.utime(root / path, ns=(settled, settled))
    _, _, cache = run()
    result["settled_warm_cache"] = measured(lambda: analyze.analyze_files(root, paths, cache=cache, workers=1))
    return result


def coverage(root, *, large=True):
    report = {"meta": {"branch_coverage": True}, "files": {"large.py": {
        "functions": {"f": {"start_line": 1, "executed_lines": [1, 2], "missing_lines": [],
                              "summary": {"num_branches": 2, "covered_branches": 2,
                                          "num_statements": 2, "covered_lines": 2}}},
        "missing_lines": [], "contexts": {"2": ["test_" + "x" * 95] * (16 * 1048576 // 104)}}}}
    if not large:
        file = report["files"]["large.py"]
        del file["contexts"]
        report["files"] = {f"file{i}.py": file for i in range(5000)}
    path = root / "coverage.json"
    raw = json.dumps(report).encode()
    path.write_bytes(raw)
    result = measured(lambda: covstream.parse_coveragepy_both_file(path, path_prefix=""))
    result.update(bytes=len(raw), artifact_sha256=hashlib.sha256(raw).hexdigest())
    return result


def baseline_module(repo, ref, name):
    raw = subprocess.run(["git", "show", f"{ref}:src/crapkit/{name}.py"], cwd=repo,
                         capture_output=True, check=True).stdout
    module = types.ModuleType(f"crapkit._baseline_{name}")
    exec(compile(raw, f"{ref}/src/crapkit/{name}.py", "exec"), module.__dict__)
    return module


def main():
    global analyze, covstream
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--baseline-ref")
    args = parser.parse_args()
    assert Path(crapkit.__file__).resolve() == args.repo.resolve() / "src/crapkit/__init__.py"
    if args.baseline_ref:
        analyze = baseline_module(args.repo, args.baseline_ref, "analyze")
        covstream = baseline_module(args.repo, args.baseline_ref, "covstream")
    with tempfile.TemporaryDirectory() as folder:
        result = {"synthetic": True, "source": str(crapkit.__file__), "baseline_ref": args.baseline_ref,
                  "sample_contract": "One first sample, five warm-process repeats. Analysis cache is cold except in settled_warm_cache. Peak bytes are Python tracemalloc, not process RSS.",
                  "duplicates": duplicate_analysis(Path(folder)),
                  "unique": duplicate_analysis(Path(folder), unique=True), "coverage": coverage(Path(folder)),
                  "coverage_many_files": coverage(Path(folder), large=False)}
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
