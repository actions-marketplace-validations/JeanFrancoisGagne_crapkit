"""Interleave baseline/current samples to reduce contention bias."""
import argparse
import hashlib
import json
import statistics
import tempfile
import time
from pathlib import Path

import crapkit
from crapkit import analyze, covstream
from measure import baseline_module


def observe(work):
    start = time.perf_counter()
    result = work()
    return time.perf_counter() - start, result


def paired(before, after):
    samples = {"before": [], "after": []}
    orders = [(('before', before), ('after', after)), (('after', after), ('before', before))]
    for index in range(6):
        values = {name: observe(work) for name, work in orders[index % 2]}
        assert values["before"][1] == values["after"][1]
        for name, value in values.items():
            samples[name].append(value[0])
    return {"seconds": samples, "before_repeat_median": statistics.median(samples["before"][1:]),
            "after_repeat_median": statistics.median(samples["after"][1:]),
            "output_sha256": hashlib.sha256(repr(values['after'][1]).encode()).hexdigest()}


def analysis_case(root, old, *, unique):
    paths = [f"file{i}.py" for i in range(12)]
    source = "\n".join(f"def f{i}(x):\n    return 1 if x else 0\n" for i in range(100))
    for path in paths:
        (root / path).write_text(f"# {path}\n{source}" if unique else source, encoding="utf-8")
    before = lambda: old.analyze_files(root, paths, cache={}, workers=1)[0]
    after = lambda: analyze.analyze_files(root, paths, cache={}, workers=1)[0]
    return paired(before, after)


def coverage_case(root, old, *, large):
    file = {"functions": {"f": {"start_line": 1, "executed_lines": [1, 2], "missing_lines": [],
                                "summary": {"num_branches": 2, "covered_branches": 2,
                                            "num_statements": 2, "covered_lines": 2}}}, "missing_lines": []}
    if large:
        file["contexts"] = {"2": ["test_" + "x" * 95] * (16 * 1048576 // 104)}
    files = {"large.py": file} if large else {f"file{i}.py": file for i in range(5000)}
    path = root / "coverage.json"
    path.write_text(json.dumps({"meta": {"branch_coverage": True}, "files": files}), encoding="utf-8")
    before = lambda: old.parse_coveragepy_both_file(path, path_prefix="")
    after = lambda: covstream.parse_coveragepy_both_file(path, path_prefix="")
    result = paired(before, after)
    result["artifact_bytes"] = path.stat().st_size
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert Path(crapkit.__file__).resolve() == args.repo.resolve() / "src/crapkit/__init__.py"
    old_analyze = baseline_module(args.repo, "47629ea", "analyze")
    old_cov = baseline_module(args.repo, "47629ea", "covstream")
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        result = {"baseline": "47629ea", "synthetic": True,
                  "note": "Six alternating paired blocks. First sample retained; medians use five repeats. Root unit verification ran on the same machine.",
                  "duplicates": analysis_case(root, old_analyze, unique=False),
                  "unique": analysis_case(root, old_analyze, unique=True),
                  "large_member": coverage_case(root, old_cov, large=True),
                  "many_members": coverage_case(root, old_cov, large=False)}
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
