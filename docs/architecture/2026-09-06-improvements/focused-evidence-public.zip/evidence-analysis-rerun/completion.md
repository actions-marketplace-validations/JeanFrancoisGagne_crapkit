# AN1 through AN4 completion

All four candidates are implemented against baseline `47629ea14ddea38e55ce2332d08297c31888acb9`. Analysis version remains 10. Cache fingerprint format advances to 4 because older entries can bind records to different bytes. Git-derived maps gain an exact-path format stamp; raw history caches remain reusable.

| Candidate | Change | Public evidence |
|---|---|---|
| AN1 | Worker verifies the expected digest, then parses those same bytes. Changed or missing input refuses without publishing poisoned records. | `an1-red.txt`, `an1-green.txt`, `test_analysis_input_snapshot.py` |
| AN2 | NUL-delimited Git paths retain spaces and Unicode separators. One C-quoted history decoder owns unquoting. Derived path caches rebuild. | `an2-red.txt`, `an2-green.txt`, `test_git_path_identity.py` |
| AN3 | One bounded decode attempt preserves the small-member fast path. Incomplete members frame new chunks before the complete decode. JSONDecoder still owns grammar. | `an3-red.txt`, `an3-fast-red.txt`, `an3-string-green.txt` |
| AN4 | Cold files with identical content and reader identity share one verified parse; each result keeps its path. | `an4-red.txt`, `an4-green.txt`, `test_analysis_cold_duplicates.py` |

## Verification

- 749 focused unit tests passed in 101.01 seconds; 230 affected end-to-end tests passed in 264.28 seconds.
- After the final JSON fast-path refinement, 386 focused coverage tests and 48 additional coverage checks passed. Six affected coverage/lane end-to-end tests passed in 11.75 seconds.
- `_path_hash`, `_analyze_verified`, `_ValueFrame.advance`, and Git `_run` have 100% measured statement and branch coverage. See `critical-function-coverage.json`.
- All nine changed production files and both measurement scripts have no function above CCN 6. The actual configured precommit command passed. The commit also runs the repository hook.
- Coverage data lives in this evidence directory. Root coverage and run artifacts were not touched.

## Measured work and cost

`paired-final.json` contains six alternating original/final blocks. The table uses the five repeat medians after the first sample. Inputs are synthetic. Other agents ran tests on the same machine, so these timings include contention. Both sides import from this checkout; the original modules come from the fixed baseline commit through the replay script. Every paired result compares equal.

| Synthetic case | Original seconds | Final seconds | Work or memory |
|---|---:|---:|---|
| 12 identical files, 100 functions each | 0.149873 | 0.016846 | Parser calls 12 to 1; traced peak 570,390 to 209,281 bytes |
| 12 unique files, 100 functions each | 0.126287 | 0.145019 | Parser calls remain 12; traced peak 789,350 to 795,011 bytes |
| One large coverage member, 16,777,460 artifact bytes | 0.491935 | 0.371822 | Traced peak 43,317,999 to 43,318,035 bytes |
| 5,000 coverage members, 1,098,936 artifact bytes | 0.082395 | 0.078289 | Traced peak 4,661,338 to 4,661,310 bytes |

Unique inputs pay for digest verification. Settled warm cache reads retain the hash-free stat shortcut. Tracemalloc is Python allocation evidence, not whole-process RSS or worker-tree memory. The large reader retains a chunk plus the largest member; string concatenation still copies the growing buffer. The implementation removes repeated decoder passes over that buffer, not every possible copy.

The original always-frame prototype made 5,000 small members slower. `final-expanded.json` preserves that result. The final version restores direct decoding for complete buffered members and frames only incomplete values. Large members can use one failed prefix attempt plus the final decode; they do not promise one raw_decode invocation total.

Result digests from `paired-final.json`:

| Case | SHA256 of complete returned result |
|---|---|
| Identical analysis | `3debd471421632ea66d48b4bd9ee0d4a39f77eb6e2ee9cdc4a1b9779ffcc53bf` |
| Unique analysis | `bb1f713135bfbd1d208cff44a895be5a8748bf1e5105fe3f5a4b14c46652950d` |
| Large coverage | `c74d707da9e2583cc3bc34b239be7f71409e466005ba0a333cec5c6e21986c6a` |
| Small coverage | `2aa536eea33a049037ec9181c28c3aa4c19577f7ef072092ad5a111c76613a93` |

The large artifact SHA256 is `2c5e60a021c28da5eca830f6ec8038e8172948910b0856333e3fa50dbc681a80`. The small artifact SHA256 is `c3b27e26830ccda4874bd2d793cd1d5a0a440191774a26e475cc46eae30800dc`.

Replay from the analysis checkout with PYTHONPATH set to its src directory:

```
python ../evidence-analysis-rerun/paired.py --repo . --output ../evidence-analysis-rerun/paired-replay.json
python ../evidence-analysis-rerun/measure.py --repo . --output ../evidence-analysis-rerun/memory-replay.json
python ../evidence-analysis-rerun/measure.py --repo . --baseline-ref 47629ea --output ../evidence-analysis-rerun/baseline-replay.json
```

## Exact limits and integration

- This binds parsed bytes to the cache identity; it does not create an atomic checkout snapshot. The settled stat shortcut retains its documented inability to detect a same-size edit with deliberately restored mtime.
- Git tests run real Windows repositories with leading spaces, non-ASCII names and Unicode line separators, including worker counts 1 and 2. POSIX-only newline, carriage return, tab, trailing-space and literal-backslash filenames are conditionally exercised on POSIX. Pure quoting tests cover their decoding on Windows. Path decoding remains strict UTF-8.
- Newline-bearing staged filenames use individual argv Git reads because the older supported Git batch protocol uses newline framing. Ordinary paths keep batching. No minimum Git version increase.
- Existing malformed JSON, UTF-8 chunks, missing-line intersections, typed reader identity, same-span refusal, deterministic outputs and per-path diagnostics remain covered.
- No lanes, mutation pool, CLI, ratchet, threshold or public export schema changes are included. Parent integrates this commit and performs full project verification.

Commit: `a725d36`. Actual hooks ran; parent integrated this as `d3a2137`.
