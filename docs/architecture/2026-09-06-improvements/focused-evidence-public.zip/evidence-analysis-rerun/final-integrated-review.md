# Final integrated analysis and release review

Reviewed frozen root source `c20560241643f66093380ca04fc8ec91f83159ea` against `47629ea14ddea38e55ce2332d08297c31888acb9`. This was a bounded read-only review. No root files, tests or artifacts changed.

## Findings

One RT3 defect remained: release writes inherited Twine and gh destinations while recovery readbacks used canonical PyPI and GitHub URLs. It is being repaired in the isolated analysis checkout. The public stage reproductions and final patch evidence are in `../evidence-release-rerun/destinations-*`.

No further AN1-AN4 cross-module defect was found. Integrated owned files match the previously tested analysis commit `a725d36`; the pre-repair release files match `db6906f`.

## Scope checked

- Analyzer input hashing, worker reads, cold-content grouping, reader identity, cache format and path restamping. The bytes parsed by each worker match its expected digest. This does not promise an atomic snapshot of the checkout or detect deliberately restored file metadata in an existing stat-cache shortcut.
- Git path consumers in dirty-file selection, diff parsing, churn, coupling and mutation input reads. NUL paths retain valid UTF-8 spelling; legacy decoded maps invalidate while raw history caches remain usable.
- Coverage JSON member framing, UTF-8 chunk handling and strict decoding. One bounded prefix decode remains on the common fast path; incomplete members then frame new bytes before final decode. The parser retains chunk plus largest-member storage and string concatenation costs.
- The integrated uncovered-line caller uses the scoped source-freshness read rule. Automatic lane reuse has the separately strengthened clean-tree rule.
- RT3 immutable artifacts, digest readbacks, pending actions, partial retry, failed Pages transitions and confirmed-tag/main-advance handling. One active release stage per checkout remains an explicit operational limit. No live publication was attempted.

## Measurement audit

The analysis rows in `docs/architecture/2026-09-06-improvements/implementation.md` match `paired-final.json` and the saved allocation results. These are synthetic inputs measured while other work ran on the host. Timing entries are warm medians from five samples after the first sample in six alternating baseline/candidate blocks. Tracemalloc measures Python allocations, not process RSS.

| Workload | Baseline seconds | Final seconds | Meaning |
|---|---:|---:|---|
| 12 identical files | 0.1498732 | 0.0168458 | 12 parser calls become 1; full results equal |
| 12 unique files | 0.1262866 | 0.1450189 | 12 parser calls remain; digest verification costs 0.0187323 seconds |
| 16,777,460-byte coverage artifact | 0.4919352 | 0.3718218 | Output digest equal; traced peak 43,317,999 to 43,318,035 bytes |
| 5,000 small members | 0.0823952 | 0.0782893 | Output digest equal; traced peak 4,661,338 to 4,661,310 bytes |

The small-member 4 ms difference is not a general speed claim. The scheduling and measurement-owner rows belong to other workstreams and were not remeasured here.

AN2's report wording should specify valid UTF-8. Real Windows fixtures cover leading whitespace, non-ASCII and U+2028. Filesystem cases requiring tab, newline, carriage return, trailing space or literal backslash names run only on POSIX; this Windows session did not execute those cases.

## Startup caveat

The strict opt-in no-toml startup budget remains unmet on this host. In 50 paired source comparisons, baseline/current minimum-above-Python-floor times were 53.5486/49.2894 ms against 40 ms. All seven imported project modules and the entry file are byte-identical. Median paired change was -0.0812 ms, with a paired bootstrap 95% interval from -4.5083 to +6.0484 ms. This does not show a code regression.

The 15-pair identical-source control combined different paths and existing bytecode caches, so its +11.1209 ms paired difference is not a pure path estimate. Ordinary hard budgets and full verification are reported separately. No budget was raised. Exact commands, source hashes, sample counts and control limits are in `../evidence-advisory-startup/conclusion.md` and its linked raw files.
