import importlib.util
import json
from pathlib import Path

root = Path('C:/Users/jfgag/crapkit')
work = Path('C:/Users/jfgag/Documents/Codex/2026-09-06/c-users-jfgag-appdata-local-temp/work/implementation')
spec = importlib.util.spec_from_file_location('ci_verdict', root / 'tools/testing/ci.py')
ci = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ci)
python, env, proof = ci.install_revision(root, work / 'wheel-install')
proof['scope'] = 'current working-tree wheel, clean isolated venv with resolved dev dependencies'
(work / 'wheel-install-proof.json').write_text(json.dumps(proof, indent=2), encoding='utf-8')
print(json.dumps({'python': str(python), 'package': proof['package'], 'wheel_sha256': proof['wheel_sha256'], 'modules': len(proof['source_sha256'])}))
