"""Preserve the existing ledger and audit a configured self-verification run."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(root, *args):
    return subprocess.run(["git", *args], cwd=root, capture_output=True, check=True).stdout


def inputs(root):
    paths = git(root, "ls-files", "-z").decode("utf-8").split("\0")
    return {path: digest((root / path).read_bytes()) for path in paths if path}


def history(db):
    return {str(row[0]): digest(json.dumps(row, default=bytes.hex).encode("utf-8"))
            for row in db.execute("SELECT * FROM runs ORDER BY id")}


def snapshot(root, output):
    with sqlite3.connect(root / ".crapkit/crap.sqlite") as original:
        with sqlite3.connect(output / "configured-before.sqlite") as copied:
            original.backup(copied)
        saved = {"commit": git(root, "rev-parse", "HEAD").decode().strip(),
                 "inputs": inputs(root), "runs": history(original)}
    (output / "configured-before.json").write_text(json.dumps(saved, indent=2) + "\n")
    print(json.dumps({"prior_runs": len(saved["runs"]), "tracked_inputs": len(saved["inputs"])}))


def unchanged(before, after, label):
    mismatches = [key for key, value in before.items() if after.get(key) != value]
    if mismatches:
        raise ValueError(f"changed {label}: {mismatches}")


def audit(root, output, expected_ok=True):
    before = json.loads((output / "configured-before.json").read_text())
    verdict = json.loads((output / "verify.json").read_text(encoding="utf-8-sig"))
    unchanged(before["inputs"], inputs(root), "measured inputs")
    with sqlite3.connect(root / ".crapkit/crap.sqlite") as db:
        unchanged(before["runs"], history(db), "prior runs")
        row = db.execute("SELECT id,commit_sha,kind,verdict_ok,findings FROM runs WHERE id=?",
                         (verdict["run_id"],)).fetchone()
    findings = 0 if expected_ok else verdict["committed_findings"] + verdict["dirty_findings"]
    expected = (verdict["run_id"], git(root, "rev-parse", "HEAD").decode().strip(),
                "verify", int(expected_ok), findings)
    if verdict["ok"] != expected_ok or row != expected:
        raise ValueError(f"verification does not match the expected ledger: {row}")
    result = {"prior_runs_unchanged": len(before["runs"]), "tracked_inputs_unchanged": len(before["inputs"]),
              "ledger": row, "coverage_sha256": digest((root / ".crapkit/cov/py.json").read_bytes()),
              "junit_sha256": digest((root / ".crapkit/cov/junit.xml").read_bytes())}
    name = "configured-audit.json" if expected_ok else "refused-audit.json"
    (output / name).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


def audit_refused(root, output):
    audit(root, output, expected_ok=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("snapshot", "audit", "audit-refused"))
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    actions = {"snapshot": snapshot, "audit": audit, "audit-refused": audit_refused}
    actions[args.action](args.repo.resolve(), args.output.resolve())


if __name__ == "__main__":
    main()
