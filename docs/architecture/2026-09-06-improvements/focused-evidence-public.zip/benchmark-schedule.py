"""Compare serial and parallel scheduling on the same immutable CLI workload."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
root = work / 'schedule-benchmark'
source = Path('C:/Users/jfgag/crapkit')
if not root.exists():
    subprocess.run(['git', 'clone', '--shared', '--quiet', str(source), str(root)], check=True)
subprocess.run(['git', 'checkout', '--quiet', '--detach', '47629ea14ddea38e55ce2332d08297c31888acb9'], cwd=root, check=True)
cases = ['tests/e2e/test_init_doctor_e2e.py', 'tests/e2e/test_lane_reuse_e2e.py',
         'tests/e2e/test_lane_reuse_refusal_e2e.py', 'tests/e2e/test_lanes_scope_gaps.py']
environment = dict(os.environ, PYTHONPATH=str(root / 'src'))
results = []
for workers in (0, 8):
    junit = work / f'schedule-benchmark-{workers}.xml'
    command = [sys.executable, '-m', 'pytest', *cases, '-n', str(workers), '-p', 'no:randomly',
               '--junitxml=' + str(junit)]
    start = time.perf_counter()
    with (work / f'schedule-benchmark-{workers}.log').open('w', encoding='utf-8') as log:
        done = subprocess.run(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
    testcases = ET.parse(junit).findall('.//testcase')
    identities = sorted((case.attrib['classname'], case.attrib['name']) for case in testcases)
    row = {'workers': workers, 'seconds': time.perf_counter() - start, 'exit': done.returncode,
           'tests': len(testcases), 'failures': sum(case.find('failure') is not None for case in testcases),
           'test_identity_sha256': hashlib.sha256(json.dumps(identities).encode()).hexdigest()}
    results.append(row)
    (work / 'schedule-benchmark.json').write_text(json.dumps({'commit': '47629ea', 'cases': cases, 'results': results}, indent=2))
    print(json.dumps(row), flush=True)
