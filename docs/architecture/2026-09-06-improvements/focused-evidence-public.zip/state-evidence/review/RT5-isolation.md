# RT5 nested coverage correction

The runner's absolute COVERAGE_FILE let a nested pytest controller combine and delete the outer suite's active coverage data. The two-worker regression reproduced a mixed branch/statement database and failed final combination. A repository-relative COVERAGE_FILE isolates nested pytest data under the nested cwd. Coverage's serialized subprocess startup still sends ordinary CLI child data to the outer suite file, including children that change cwd.

The runner also imposed per-test contexts on projects that did not request them. The advisory test replaced sqlite3.connect globally, so coverage failed while writing those contexts and later tests inherited a broken collector. The runner now leaves context selection to project configuration. The advisory test guards SnapshotStore construction and still checks that the advisory creates no .crapkit directory.

## Behavior checks

| Check | Evidence |
|---|---|
| Absolute destination corrupts nested measurements | RT5-nested-red.txt |
| Relative destination keeps nested data local and retains a different-cwd CLI sibling's only false branch | RT5-relative-other-cwd.txt |
| Imposed contexts fail the no-context project contract | RT5-unrequested-context-red.txt |
| Advisory plus a later test reproduce the global SQLite patch failure under configured contexts | RT5-contexts-red.txt |
| Original init scaffold case through corrected runner, two xdist workers | RT5-init-green.txt: 3 passed, 68 measured crapkit files |

The initial contexts experiment used coverage dynamic_context=test_function with xdist, which pytest-cov refuses. The miniature parallel fixture now requests contexts through pytest's addopts="--cov-context=test". The serial advisory regression keeps dynamic_context to prove that the SnapshotStore guard does not intercept coverage writes. RT5-contexts-green.txt records the intermediate mixed result, not final acceptance.

The generated coverage-config alternative was not needed. No new configuration serializer, runner option, package patch, or subprocess coverage exclusion was added.

## Final validation

- 39 focused checks passed in 90.02 seconds. Command: `python -B -m pytest tests/unit/test_suite_schedule.py tests/unit/test_suite_nested_coverage.py tests/unit/test_advisory_coverage_contexts.py tests/unit/test_ratchet_reader_identity.py tests/unit/test_ratchet_finite_admission.py tests/unit/test_ci_verdict.py tests/unit/test_ci_failure_evidence.py tests/unit/test_ci_install_contract.py tests/unit/test_generated_guidance.py -o addopts='' -q --tb=short -p no:randomly`. Evidence: RT5-isolation-green.txt.
- Three new subprocess checks passed under outer branch coverage in 31.40 seconds. The parent tests intentionally run their measurements in child fixtures, so this outer check reports no measured parent crapkit code. Each child still asserts its own combined branch/context evidence. Evidence: RT5-outer-coverage-green.txt.
- The original init e2e and two related CLI checks passed under two outer workers. The saved outer data contains 68 crapkit modules and executed admin.py lines. Evidence: RT5-init-green.txt, RT5-init-replay.xml and RT5-init-replay.coverage.
- All 12 runner functions have CCN at or below 6. The changed _suite function has CCN 2. `git diff --check` passed.
- Python commands set PYTHONPATH to this checkout's src. Live crapkit.__file__ matched this checkout.
