# CI and suite-runner review

Reviewed commit `5511b47` in root. Follow-up worktree starts at `d3a2137`; the reviewed CI and runner files had no intervening changes. Root source stayed untouched.

Both findings are repaired in `8c7f686`. The active commit hook passed, the worktree is clean and `git diff HEAD --check` is clear.

## Confirmed findings

| Finding | Before | Repair |
|---|---|---|
| RT5 startup failure retained stale passing artifacts | `run.py:32-37,49-60` required both XML files before replacing the combined JUnit. A real unit conftest import failure left the previous two passing cases in place, lost the current e2e result during temporary-directory cleanup, and left earlier coverage available. | Clear prior final artifacts before starting. Write a synthetic infrastructure error for missing or invalid suite evidence. Preserve each current suite's XML and coverage data, and retain incomplete scratch data. |
| RT2 verification refusal lost its inputs | `ci.py:131-143` wrote evidence only after `verify_pair` returned. A failed candidate measurement with malformed coverage caused the real verifier to refuse; no output directory survived temporary checkout cleanup. | Save phase, available wheel/source proofs, suite exits and refusal reason on both success and failure. Archive coverage, JUnit and complete SQLite backup ledgers under a unique attempt directory. Keep a current verdict pointer and each attempt's own status. |

`suite-failure.py` is a complete public runner reproduction with disposable tests. `ci-failure.py` uses real Git checkouts and real CLI verification; it bypasses wheel installation and injects the broken candidate measurement. It does not claim to reproduce a package-build failure.

## Checked retained behavior

| Area | Review result |
|---|---|
| Wheel isolation | Base and candidate get separate venvs. Import proof runs with `-I`, rejects package paths outside the venv, and compares every installed Python file against the revision. Tests and CLI commands use that venv's interpreter and PATH. |
| Coverage path mapping | The installed package path maps to that revision's source tree. The small installed-source fixture checks both branches after subprocess coverage and rejects modified installed source. |
| Baseline transfer | SQLite backup transfers all tables instead of projecting a reduced baseline. The failure regression reads the retained base and candidate ledgers and verifies the copied commit. |
| Verdict checks | Candidate output must contain a verdict. Run ID, kind, trust value and commit must agree with the latest ledger row. Ordinary gate refusal remains nonzero. Suite failures also keep the overall comparison nonzero. |
| Workflow inputs | Pull requests use their base SHA; main pushes use the event's before SHA. Full history is fetched. Invalid or unavailable bases fail closed. No new trigger or base-selection change was needed. |
| Artifact upload | It remains restricted to `.crapkit/ci-verdict`. Hidden files are included so interrupted coverage shards survive upload; no environments or whole checkouts are copied. |

No other substantiated findings emerged in the assigned areas. This review did not run a complete wheel build/comparison, contact a package index, or replay hosted GitHub events. Root owns the final installed-wheel comparison.

## Validation

- `RT5-red.txt`: startup failure retained old passing JUnit.
- `RT2-red.txt`: candidate verification refusal produced no saved verdict.
- `RT2-upload-red.txt`: workflow omitted hidden evidence.
- `followup-green.txt` and `followup.xml`: 14 focused checks passed, including the real runner, path mapping, CLI verification and generated guidance.
- `RT2-upload-green.txt`: updated upload contract passed separately.
- `RT5-empty-suite-green.txt`: pytest exit 5 now appears as an infrastructure error alongside the completed e2e suite.
- `decisions.tsv` records the repair choices. Hook and commit output are saved beside this note.
