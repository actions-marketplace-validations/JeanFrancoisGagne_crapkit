from pathlib import Path
import gc, json, subprocess, sys, tempfile
import pytest
CHECKOUT = Path(r'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\implementation\analysis-rerun')
sys.path.insert(0, str(CHECKOUT/'tests/unit'))
from test_release_guards import repo, verified, git
from test_release_recovery import publish_adapter, receipt, ARTIFACTS, VERSION
from test_release_tool import release
with tempfile.TemporaryDirectory(prefix='release-main-') as folder, pytest.MonkeyPatch.context() as patch:
    scratch=Path(folder)
    root=repo(scratch,bumped=True)
    verified(root,patch)
    adapter=publish_adapter(root,patch,'pypi:'+sorted(ARTIFACTS)[0])
    calls=[]
    def execute(command, root, dry_run):
        calls.append(list(command))
        return adapter.execute(command,root,dry_run)
    patch.setattr(release,'_execute',execute)
    try:
        release.run('stage2b',VERSION,root)
    except release.ReleaseError as exc:
        first_error=str(exc)
    release_head=git(root,'rev-parse','HEAD')
    other=scratch/'other'
    git(scratch,'clone','--quiet','--branch','main',str(scratch/'remote.git'),str(other))
    (other/'later.txt').write_text('ordinary next commit\n')
    git(other,'add','later.txt')
    git(other,'-c','user.name=Review','-c','user.email=r@example.test','commit','-qm','later')
    git(other,'push','--quiet','origin','main')
    git(other,'merge-base','--is-ancestor',release_head,'HEAD')
    try:
        release.run('stage2b',VERSION,root)
        retry_error=None
    except release.ReleaseError as exc:
        retry_error=str(exc)
    print(json.dumps({'first_error':first_error,'retry_error':retry_error,
                      'release_head':release_head,'remote_main':git(other,'rev-parse','HEAD'),
                      'remote_main_contains_release':True,
                      'push_attempts':sum(c[:2]==['git','push'] for c in calls),
                      'pending':receipt(root).get('pending'),
                      'pypi_files':sorted(adapter.pypi),'expected_files':sorted(ARTIFACTS)},indent=2))
    assert retry_error is not None and receipt(root)['pending']==['push']
    gc.collect()

