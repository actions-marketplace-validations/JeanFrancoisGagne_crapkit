from pathlib import Path
import importlib.util, json, os, subprocess, sys, tempfile
ROOT = Path(r'C:\Users\jfgag\crapkit')
spec = importlib.util.spec_from_file_location('review_ci', ROOT/'tools/testing/ci.py')
ci = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ci)
sys.path.insert(0, str(ROOT/'tests/unit'))
from test_ci_verdict import prepared, git
with tempfile.TemporaryDirectory(prefix='ci-evidence-') as folder:
    repo=Path(folder)/'repo'; repo.mkdir(); (repo/'src').mkdir()
    (repo/'src/app.py').write_text('def f(value):\n    if value:\n        return 1\n    return 2\n')
    (repo/'.gitignore').write_text('.crapkit/\n')
    (repo/'crapkit.toml').write_text('[crapkit]\ntarget=5\n[[scope]]\nname="src"\npaths=["src"]\nlanguages=["python"]\n[[lane]]\nname="py"\ncommand="run"\nartifact=".crapkit/cov/py.json"\nparser="coveragepy"\nscopes=["src"]\nresults_artifact=".crapkit/cov/junit.xml"\n')
    git(repo,'init','-b','main'); git(repo,'add','.')
    git(repo,'-c','user.name=Test','-c','user.email=t@example.test','commit','-qm','base')
    baseline=git(repo,'rev-parse','HEAD')
    (repo/'src/app.py').write_text('def f(value):\n    if value:\n        return 11\n    return 22\n')
    git(repo,'add','.'); git(repo,'-c','user.name=Test','-c','user.email=t@example.test','commit','-qm','candidate')
    env=dict(os.environ,PYTHONPATH=str(ROOT/'src'))
    ci.install_revision=lambda root,destination: (Path(sys.executable),env,{'probe':'installation bypassed; current source CLI'})
    def measurement(root,*args):
        prepared(root,covered=True)
        if root.name=='candidate':
            (root/'.crapkit/cov/py.json').write_text('{broken')
            return 1
        return 0
    ci._measure=measurement
    output=Path(folder)/'output'
    code=ci.main(['--repo',str(repo),'--base',baseline,'--output',str(output)])
    print(json.dumps({'exit':code,'output_exists':output.exists(),'evidence_files':list(map(str,output.glob('**/*')))},indent=2))
    assert code==1 and not output.exists()
