from pathlib import Path
import importlib.util
import shutil
import sys
import tempfile
import coverage
import crapkit

root = Path(sys.argv[1]).resolve()
output = Path(__file__).resolve().parent
assert Path(crapkit.__file__).resolve() == root / 'src/crapkit/__init__.py'
spec = importlib.util.spec_from_file_location('schedule', root / 'tools/testing/run.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
with tempfile.TemporaryDirectory(prefix='init-replay-', dir=root / '.crapkit/cov') as directory:
    scratch = Path(directory)
    command = [sys.executable, '-m', 'pytest', 'tests/e2e/test_init_doctor_e2e.py',
               '-k', 'test_running_the_lane_init_scaffolded_leaves_git_status_empty or test_git_never_sees_the_store_init_just_ignored or test_version_names_the_program_that_produced_the_number',
               '-n', '2', '-p', 'no:randomly', '-o', 'addopts=', '-q', '--tb=short']
    result = runner._suite(command, root, scratch, 'e2e', True)
    data = coverage.CoverageData(basename=str(scratch / '.coverage.e2e'))
    data.read()
    files = {name.replace('\\', '/'): data.lines(name) for name in data.measured_files()}
    assert any(name.endswith('/cli/admin.py') and lines for name, lines in files.items()), files
    shutil.copyfile(scratch / 'e2e.xml', output / 'RT5-init-replay.xml')
    shutil.copyfile(scratch / '.coverage.e2e', output / 'RT5-init-replay.coverage')
    print('measured_files', len(files), 'exit', result)
    raise SystemExit(result)
