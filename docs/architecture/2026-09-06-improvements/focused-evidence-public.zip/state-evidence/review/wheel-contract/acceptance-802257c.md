# Independent clean-wheel acceptance: 802257c

The audit passed with no evidence inconsistencies. Candidate `802257c8796070f6a6be72e99cf284f6afd13362` passed all executed tests and the actual Crapkit verdict against baseline `47629ea14ddea38e55ce2332d08297c31888acb9`. The retained SQLite ledger agrees with the reported verdict. This audit read artifacts and source proofs; it ran no additional tests and changed no repository inputs.

The completed attempt is `final-ci-complete/attempt-yi62o7o2`. Its identity differs from the earlier refused comparison at `9e08454`. The driver reported phase `complete`, suite exits `[1, 0]`, and verification run 2 passed with zero findings.

## Complete test evidence

| Revision and suite | Passed | Failed | Skipped | Total |
| --- | ---: | ---: | ---: | ---: |
| Baseline unit | 3,396 | 2 | 42 | 3,440 |
| Baseline E2E | 716 | 1 | 2 | 719 |
| Baseline combined | 4,112 | 3 | 44 | 4,159 |
| Candidate unit | 3,644 | 0 | 1 | 3,645 |
| Candidate E2E | 759 | 0 | 2 | 761 |
| Candidate combined | 4,403 | 0 | 3 | 4,406 |

Both revisions have complete per-suite and combined JUnit. Declared totals match testcase counts; combined cases match the individual suites. The existing parser admits the reports without unfinished worker or session errors. The driver summary and verdict match the retained XML.

The baseline retains all three failures:

- `test_the_documented_pester_glob_reaches_a_root_level_test_file`: the old test locates repository documentation below the installed wheel's `Lib` directory.
- `test_a_source_tree_with_nothing_installed_falls_back_to_the_package`: the old fixture makes installed distribution metadata visible to its no-distribution check.
- `test_the_warm_path_stays_inside_the_ci_budget[no_toml]`: this attempt measured `521.9062000396661 ms` against the `500 ms` assertion. This is an observed baseline timing overrun.

Baseline unit skips comprise 41 missing-`yaml` cases and one missing-`PIL` module collection skip. Candidate unit has one POSIX signal return-code skip. Both E2E suites skip two optional strict latency cases. Candidate has no missing-dependency skips. Complete baseline failures remain comparison inputs under the established policy; candidate requires zero test failures and a passing verdict.

## Installed source and retained wheels

The independent capture hashed all 64 baseline and 69 candidate package Python files in the live virtual environments before cleanup. Every file matched its exact Git archive, the driver's installed-source proof, and the retained wheel contents. Both imports resolved to their separate virtual environments' `Lib/site-packages/crapkit` directories.

Both original wheel filenames were `crapkit-0.6.0-py3-none-any.whl`. The retained copies use distinct evidence names. Their byte hashes match the copies captured while the measured environments existed.

| Retained file | Bytes | SHA256 |
| --- | ---: | --- |
| `acceptance-802257c-base.whl` | 381,601 | `31045189827c31aabb6a613a9b1851695bee583aa24e81bd7574d5650382f902` |
| `acceptance-802257c-candidate.whl` | 390,718 | `007092af54d591c298a88653bc0a4033a2427de3d8a80b0269ac91062effba6f` |

## Ledger and coverage agreement

Both SQLite integrity checks passed. The candidate ledger preserves the complete baseline run, including its metadata, lanes, and 1,747 function rows. Its added verify run contains 1,867 function rows, the requested candidate SHA, `verdict_ok=1`, and zero findings. The stored candidate run agrees with the reported verdict. No override or ratchet rewrite occurred. The audit did not access the root historical ledger for writes.

Both coverage reports contain branch data for every package Python file. They contain no foreign source files, deleted synthetic paths, absolute source paths, missing package files, or normalized path collisions. Coverage bytes match the stored lane digests. Candidate JUnit bytes also match its stored digest. The old baseline stores no JUnit digest; its retained testcase totals and failure identities agree with its lane.

| Revision | Covered lines | Covered branches | Package files |
| --- | ---: | ---: | ---: |
| Baseline | 9,519 / 9,651 | 2,471 / 2,538 | 64 |
| Candidate | 9,916 / 10,066 | 2,539 / 2,616 | 69 |

The two previously deficient functions now have full measured branch coverage. Independent complexity and CRAP calculations agree with the passing gate.

| Function | Source location | CCN | Executed branches | CRAP |
| --- | --- | ---: | ---: | ---: |
| `_ratchet_merge` | `src/crapkit/cli/ratchet_cmds.py:86` | 6 | 2 / 2 | 6.0 |
| `run_bounded` | `src/crapkit/procs.py:257` | 6 | 2 / 2 | 6.0 |

## Limits and duration evidence

The verdict reports 23 changed uncovered lines. No diff-coverage maximum is configured. Candidate coverage still has 150 missing lines and 77 missing branches. Selected publication and state checks are recorded in the JSON receipt, including remaining branches in `_ratchet_entries`, `_lock`, and `_same_artifacts`, and error lines in `_measurement_key`. Windows execution does not cover the POSIX lock branch. Tool and release scripts are outside `--cov=crapkit`; their test results do not establish branch coverage for those scripts.

The five longest candidate unit cases are taken directly from this attempt's XML, without another timing run:

| Test | Seconds |
| --- | ---: |
| `test_advisory_and_following_test_pass_under_configured_contexts` | 46.754 |
| `test_installed_source_is_verified_before_coverage_paths_are_mapped` | 14.496 |
| `test_startup_failure_replaces_old_passing_evidence_and_keeps_the_other_suite` | 10.373 |
| `test_the_single_pass_reproduces_the_two_pass_record_for_every_committed_source` | 10.048 |
| `test_retry_allows_main_to_advance_after_confirmed_release_push` | 9.874 |

## Receipt and replay

The files beside this note retain the audit, live proofs, exact wheel bytes, and replay script:

- `acceptance-802257c.json`: complete audit receipt, `issues: []`, detailed failure and skip records, artifact digests, ledger comparison, and selected function coverage.
- `acceptance-802257c-installed-proof.json` and `acceptance-802257c-source-check.json`: live import hashes and exact Git archive comparison.
- `acceptance-802257c-wheel-artifacts.json`: wheel copy paths, original names, sizes, and digests.
- `acceptance-802257c-audit.py`: retained-artifact audit replay.

From the projectless workspace, set `PYTHONPATH` to the reviewed repository's `src` directory, then run:

```text
python -B work/implementation/state-evidence/review/wheel-contract/acceptance-802257c-audit.py <repository> work/implementation/final-ci-complete work/implementation/state-evidence/review/wheel-contract/acceptance-802257c.json
```

The earlier refusal remains intact in `final-acceptance.md`, `final-acceptance.json`, `refusal-9e08454-verdict.json`, and `refusal-9e08454-ci.log`. Its results have not been rewritten as a pass.
