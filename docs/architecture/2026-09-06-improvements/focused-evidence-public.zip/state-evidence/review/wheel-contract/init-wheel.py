from pathlib import Path
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile

root = Path(sys.argv[1]).resolve()
python = Path(sys.argv[2]).resolve()
output = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('schedule', root / 'tools/testing/run.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
env = {key: value for key, value in os.environ.items()
       if not key.startswith(('PYTHON', 'COVERAGE_', 'COV_CORE_'))}
env['PYTHONNOUSERSITE'] = '1'
env['PATH'] = str(python.parent) + os.pathsep + env.get('PATH', '')
probe = subprocess.run([str(python), '-I', '-c', 'import crapkit; print(crapkit.__file__)'],
                       env=env, cwd=root, capture_output=True, text=True, check=True)
package = Path(probe.stdout.strip()).resolve().parent
assert package.is_relative_to(python.parent.parent), package
(root / '.crapkit/cov').mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(prefix='wheel-init-', dir=root / '.crapkit/cov') as directory:
    scratch = Path(directory)
    config = scratch / 'wheel.coveragerc'
    config.write_text('[run]\nbranch=true\npatch=subprocess\nsource=crapkit\n[paths]\nsource=\n    '
                      + str(root / 'src/crapkit') + '\n    ' + str(package) + '\n')
    env['COVERAGE_RCFILE'] = str(config)
    os.environ.clear()
    os.environ.update(env)
    command = [str(python), '-m', 'pytest', 'tests/e2e/test_init_doctor_e2e.py',
               '-k', 'test_running_the_lane_init_scaffolded_leaves_git_status_empty or test_git_never_sees_the_store_init_just_ignored or test_version_names_the_program_that_produced_the_number',
               '-n', '2', '-p', 'no:randomly', '-o', 'addopts=', '-q', '--tb=short']
    print(json.dumps({'python': str(python), 'package': str(package)}), flush=True)
    result = runner._suite(command, root, scratch, 'e2e', True)
    shutil.copyfile(scratch / 'e2e.xml', output / 'init-wheel.xml')
    raise SystemExit(result)
