"""Read retained wheel evidence and compare it with the exact Git revisions."""
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
import zlib

import crapkit
import lizard
from crapkit.junitparse import suite_summary


repo, output, destination = map(lambda value: Path(value).resolve(), sys.argv[1:4])
assert Path(crapkit.__file__).resolve().is_relative_to(repo / "src")
record = json.loads((output / "verdict.json").read_text(encoding="utf-8"))
retained = output / record["evidence_dir"]
issues = []
receipt = {"evidence": str(retained), "phase": record["phase"],
           "suite_exits": record["suite_exits"], "issues": issues, "revisions": {}}
expected_commits = {"base": "47629ea14ddea38e55ce2332d08297c31888acb9",
                    "candidate": "9e084545e85779121943ea48346dc8f895ed0af6"}
for name, commit in expected_commits.items():
    if record[name]["commit"] != commit:
        issues.append(name + " differs from the requested frozen revision")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def source_files(commit):
    data = subprocess.run(["git", "archive", commit, "src/crapkit"], cwd=repo,
                          check=True, capture_output=True).stdout
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        return {item.name.removeprefix("src/crapkit/"): archive.extractfile(item).read()
                for item in archive if item.isfile() and item.name.endswith(".py")}


def junit(path):
    raw = path.read_bytes()
    root = ET.fromstring(raw)
    failed, admitted = suite_summary(raw.decode("utf-8"))
    cases = list(root.iter("testcase"))
    counts = Counter()
    rows = []
    for case in cases:
        status = next((name for name in ("error", "failure", "skipped")
                       if case.find(name) is not None), "passed")
        detail = case.find(status)
        message = "" if detail is None else detail.get("message", "")
        text = "" if detail is None else detail.text or ""
        rows.append({"id": case.get("classname", "?") + "::" + case.get("name", "?"),
                     "status": status, "message": message, "text": text})
        counts[status] += 1
    mismatches = [{"name": suite.get("name"), "declared": suite.get("tests"),
                   "actual": len(list(suite.iter("testcase")))}
                  for suite in root.iter("testsuite")
                  if int(suite.get("tests", "-1")) != len(list(suite.iter("testcase")))]
    return {"sha256": sha(raw), "counts": dict(counts), "tests": len(cases),
            "admitted": admitted, "failed_ids": sorted(failed),
            "count_mismatches": mismatches,
            "slowest": [{"id": case.get("classname", "?") + "::" + case.get("name", "?"),
                         "seconds": float(case.get("time", "0"))}
                        for case in sorted(cases, key=lambda case: float(case.get("time", "0")),
                                           reverse=True)[:5]],
            "nonpassing": [row for row in rows if row["status"] != "passed"]}, rows


def ledger(path):
    with sqlite3.connect(path.as_uri() + "?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
        runs = []
        for item in db.execute("SELECT * FROM runs ORDER BY id"):
            row = dict(item)
            raw = row.pop("lanes")
            row["lanes"] = json.loads(zlib.decompress(raw) if isinstance(raw, bytes) else raw)
            row["tool_versions"] = json.loads(row["tool_versions"])
            row["functions"] = db.execute("SELECT COUNT(*) FROM functions WHERE run_id=?",
                                           (row["id"],)).fetchone()[0]
            runs.append(row)
    return {"sha256": sha(path.read_bytes()), "integrity": integrity, "runs": runs}


for name in ("base", "candidate"):
    proof = record[name]
    files = source_files(proof["commit"])
    expected = {path: sha(data) for path, data in files.items()}
    measured = proof["source_sha256"]
    differences = sorted(path for path in expected.keys() | measured.keys()
                         if expected.get(path) != measured.get(path))
    unit, unit_rows = junit(retained / name / "cov/unit.xml")
    e2e, e2e_rows = junit(retained / name / "cov/e2e.xml")
    combined, combined_rows = junit(retained / name / "cov/junit.xml")
    same_cases = Counter(map(lambda row: json.dumps(row, sort_keys=True), combined_rows)) == Counter(
        map(lambda row: json.dumps(row, sort_keys=True), unit_rows + e2e_rows))
    cov_path = retained / name / "cov/py.json"
    cov = json.loads(cov_path.read_text(encoding="utf-8"))
    foreign = sorted(path for path in cov["files"]
                     if path.replace("\\", "/").removeprefix("src/crapkit/") not in expected
                     or not path.replace("\\", "/").startswith("src/crapkit/"))
    absent = sorted(set("src/crapkit/" + path for path in expected) -
                    {path.replace("\\", "/") for path in cov["files"]})
    database = ledger(retained / name / "crap.sqlite")
    receipt["revisions"][name] = {
        "commit": proof["commit"], "source_files": len(expected),
        "source_proof_mismatches": differences, "installed_package": proof["package"],
        "wheel": proof["wheel"], "wheel_sha256": proof["wheel_sha256"],
        "unit": unit, "e2e": e2e, "combined": combined,
        "combined_matches_suites": same_cases,
        "coverage": {"sha256": sha(cov_path.read_bytes()), "files": len(cov["files"]),
                     "meta": cov["meta"], "totals": cov["totals"],
                     "foreign_files": foreign, "absent_package_files": absent},
        "ledger": database}
    if differences or foreign or not same_cases or not cov["meta"].get("branch_coverage"):
        issues.append(name + " source, coverage, or combined JUnit validation failed")
    if any(data["count_mismatches"] for data in (unit, e2e, combined)):
        issues.append(name + " declared JUnit count differs from recorded cases")

base = receipt["revisions"]["base"]
candidate = receipt["revisions"]["candidate"]
unit_cases = list(ET.parse(retained / "candidate/cov/unit.xml").iter("testcase"))
progress = unit_cases[2952:3024]
candidate["unit"]["progress_81_to_83"] = {
    "case_range": [2953, 3024], "seconds": sum(float(case.get("time", "0")) for case in progress),
    "classes": sorted({case.get("classname", "?") for case in progress}),
    "basis": "The serial runner prints 72 progress marks per full line; 2952 and 3024 bracket 81%-83% of 3639 cases."}
verdict = record["verdict"]
receipt["verdict"] = verdict
actual = candidate["ledger"]["runs"][-1]
reported = verdict["ledger"]
receipt["ledger_matches_verdict"] = all(actual[key] == value for key, value in reported.items())
receipt["baseline_ledger_preserved"] = candidate["ledger"]["runs"][:-1] == base["ledger"]["runs"]
captured = json.loads(destination.with_name("final-installed-proof.json").read_text())
receipt["independent_installations_match"] = all(
    all(record[name][field] == value for field, value in captured[name].items())
    for name in ("base", "candidate"))
if not all((receipt["ledger_matches_verdict"], receipt["baseline_ledger_preserved"],
            receipt["independent_installations_match"],
            receipt["phase"] == "complete", receipt["suite_exits"][1] == 0)):
    issues.append("final verdict, installation proof, or baseline ledger validation failed")
if not verdict["ok"]:
    issues.append(f"candidate verification refused with {actual['findings']} findings")
for name in ("base", "candidate"):
    current = receipt["revisions"][name]
    latest = current["ledger"]["runs"][-1]
    current["lane_artifact_matches"] = [
        {"lane": lane, "coverage": data.get("artifact_sha256") == current["coverage"]["sha256"],
         "junit": None if "results_artifact_sha256" not in data else
         data["results_artifact_sha256"] == current["combined"]["sha256"]}
        for lane, data in latest["lanes"].items()]
    if not all(item["coverage"] and item["junit"] is not False for item in current["lane_artifact_matches"]):
        issues.append(name + " retained artifact bytes differ from the stored measurement")
    current["reported_test_summary_matches"] = verdict["tests"][name] == {
        **current["combined"]["admitted"], "failures": current["combined"]["failed_ids"]}
    if not current["reported_test_summary_matches"]:
        issues.append(name + " reported test summary differs from retained JUnit")

critical = {
    "override.py": {"record_override", "_alert_or_refuse", "_grant_ratchet_debt"},
    "ratchetfile.py": {"_replace", "read", "publish", "_publish_locked"},
    "store.py": {"write_overrides", "prune_runs", "history_totals", "_store_rollup"},
    "ratchet_report.py": {"mark_age_days", "_replay"},
    "cli/_shared.py": {"_ratchet_entries"},
    "cli/verifying.py": {"_write_marks_if_changed", "_settle_verify"},
    "cli/ratchet_cmds.py": {"_ratchet_merge"},
    "procs.py": {"run_bounded"},
    "sarif.py": {"_esc", "_property", "github_annotation"},
    "config_contract.py": None,
    "locks.py": None,
    "lanes.py": {"lane_unchanged", "_measurement_key", "_same_artifacts", "measurement_owner"},
}
files = source_files(candidate["commit"])
coverage = json.loads((retained / "candidate/cov/py.json").read_text())
coverage_files = {path.replace("\\", "/"): item for path, item in coverage["files"].items()}
checked = []
for path, names in critical.items():
    measured = coverage_files["src/crapkit/" + path]
    for function in lizard.analyze_file.analyze_source_code(path, files[path].decode()).function_list:
        if names is not None and function.name.rsplit("::", 1)[-1] not in names:
            continue
        inside = lambda line: function.start_line <= line <= function.end_line
        executed = [branch for branch in measured["executed_branches"] if inside(branch[0])]
        missing = [branch for branch in measured["missing_branches"] if inside(branch[0])]
        missing_lines = [line for line in measured["missing_lines"] if inside(line)]
        checked.append({"file": "src/crapkit/" + path, "function": function.name,
                        "start": function.start_line, "end": function.end_line,
                        "branches_executed": len(executed), "branches_missing": missing,
                        "missing_lines": missing_lines})
receipt["critical_function_coverage"] = checked
receipt["limits"] = [
    "Wheel archives and installed package hashes were independently captured before cleanup; the receipt preserves those hashes, not the environments.",
    "Coverage is scoped to crapkit. Testing and release tool branch coverage is outside this measurement; their JUnit cases are retained.",
    "The immutable baseline records no JUnit digest. Its retained JUnit counts and failed IDs match its stored lane; its coverage digest matches exactly.",
    "This read-only audit does not rerun suites or change the root historical ledger."]
destination.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"phase": receipt["phase"], "issues": issues,
                  "suite_exits": receipt["suite_exits"], "verdict_ok": verdict["ok"],
                  "ledger_matches": receipt["ledger_matches_verdict"],
                  "baseline_preserved": receipt["baseline_ledger_preserved"]}))
