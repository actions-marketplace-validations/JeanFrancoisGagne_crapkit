# Ratchet merge coverage follow-up

Commit `d55bd15956d1e02f64ea96ef32464795e7972bff` adds four public CLI regressions. It changes no production code, thresholds, or marks.

The frozen `9e084545e85779121943ea48346dc8f895ed0af6` wheel run refused `_ratchet_merge` with CCN 6, coverage 0.5, and CRAP 10.5. Its only missing branch was the argument-count refusal at `src/crapkit/cli/ratchet_cmds.py:90`, leading to line 91. The existing guard worked; the suite had never measured it.

The new test invokes `crapkit.cli.main` with zero, one, two, or four merge inputs. Every case must return configuration exit 3, explain the required BASE/OURS/THEIRS arguments, leave all input bytes and modification times unchanged, and create no state directory or lock file. Existing successful merge tests measure the other branch.

| Check | Result | Evidence |
|---|---|---|
| Before: actual full-wheel gate and branch assertion | Refused; missing arc `90 -> 91` | `ratchet-merge-red.txt` |
| Focused admission, key-version and stamp tests | 17 passed | `ratchet-merge-green.txt` |
| New cases against installed wheel | 4 passed | `ratchet-merge-wheel.txt` |
| Focused branch measurement | 2/2 branches; no missing lines | `ratchet-merge-coverage.json` |
| Recomputed score | CCN 6, coverage 1.0, CRAP 6.0 | `ratchet-merge-measured.txt` |
| Active pre-commit hook | Passed; checkout clean | `ratchet-merge-commit.txt` |

The red check is the existing failed acceptance gate and a coverage assertion over that retained artifact. This is a test gap, so the new behavior assertions pass against the already-correct production guard. No new production defect or failing behavior test is claimed.

The production file's Git blob is `7b63b8b41fca2df2aade16080dfd761b6b9019d2` in both the isolated checkout and the frozen candidate. The focused measurement therefore exercises the same implementation that failed acceptance.

From the isolated checkout, with PYTHONPATH set to its `src`, the focused command is:

```powershell
python -B -m pytest -q -o addopts= -p no:randomly tests/unit/test_ratchet_merge_admission.py tests/unit/test_ratchet_key_commands.py tests/e2e/test_ratchet_stamp_e2e.py --cov=crapkit.cli.ratchet_cmds --cov-branch --cov-report=json:../state-evidence/review/wheel-contract/ratchet-merge-coverage.json --cov-report=
```

The frozen full-wheel attempt remains refused in `final-acceptance.md`. Only a new complete run can establish final acceptance after this test change and the separately owned `run_bounded` repair.
