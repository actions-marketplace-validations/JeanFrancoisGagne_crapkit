"""Read independent installation proofs while the CI scratch directory exists."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

scratch, destination = map(Path, sys.argv[1:3])
result = {}
for name in ("base", "candidate"):
    install = scratch / (name + "-install")
    python = install / "venv/Scripts/python.exe"
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith(("PYTHON", "COVERAGE_", "COV_CORE_"))}
    imported = subprocess.run([str(python), "-I", "-B", "-c",
                               "import crapkit; print(crapkit.__file__)"],
                              cwd=scratch / name, env=environment, capture_output=True,
                              text=True, check=True)
    package = Path(imported.stdout.strip()).parent
    assert package.is_relative_to(install / "venv"), package
    files = {file.relative_to(package).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest()
             for file in package.rglob("*.py")}
    wheel, = (install / "dist").glob("*.whl")
    result[name] = {"package": str(package), "source_sha256": files,
                    "wheel": wheel.name, "wheel_sha256": hashlib.sha256(wheel.read_bytes()).hexdigest()}
destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({name: {"package": proof["package"], "source_files": len(proof["source_sha256"]),
                         "wheel_sha256": proof["wheel_sha256"]} for name, proof in result.items()}))
