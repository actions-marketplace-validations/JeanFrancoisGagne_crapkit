from pathlib import Path
import json
import os
import subprocess
import sys

checkout = Path(sys.argv[1]).resolve()
python = Path(sys.argv[2]).resolve()
env = {key: value for key, value in os.environ.items()
       if not key.startswith(('PYTHON', 'COVERAGE_', 'COV_CORE_'))}
env['PYTHONNOUSERSITE'] = '1'
env['PATH'] = str(python.parent) + os.pathsep + env.get('PATH', '')
probe = subprocess.run([str(python), '-I', '-c', 'import crapkit; print(crapkit.__file__)'],
                       env=env, cwd=checkout, capture_output=True, text=True, check=True)
package = Path(probe.stdout.strip()).resolve()
assert package.is_relative_to(python.parent.parent), package
print(json.dumps({'python': str(python), 'package': str(package)}), flush=True)
command = [str(python), '-B', '-m', 'pytest', *sys.argv[3:], '-o', 'addopts=',
           '-q', '--tb=short', '-p', 'no:randomly']
raise SystemExit(subprocess.run(command, cwd=checkout, env=env).returncode)
