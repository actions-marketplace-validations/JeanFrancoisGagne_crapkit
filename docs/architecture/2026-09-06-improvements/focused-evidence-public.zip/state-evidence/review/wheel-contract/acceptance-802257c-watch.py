"""Capture live installation bytes, then stop at the requested retained verdict."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

workspace = Path(sys.argv[1]).resolve()
evidence = Path(__file__).resolve().parent
expected = "802257c8796070f6a6be72e99cf284f6afd13362"
output = workspace / "work/implementation/final-ci-complete"
capture = evidence / "acceptance-802257c-installed-proof.json"
seen = set()


def candidate_matches(scratch):
    result = subprocess.run(["git", "rev-parse", "HEAD"], cwd=scratch / "candidate",
                            capture_output=True, text=True)
    return result.returncode == 0 and result.stdout.strip() == expected


def ready_installations():
    for scratch in Path(os.environ["TEMP"]).glob("crapkit-ci-*"):
        if not (scratch / "candidate-install/venv/Scripts/python.exe").is_file():
            continue
        if not (scratch / "candidate/.git").exists() or not candidate_matches(scratch):
            continue
        yield scratch


def capture_ready():
    for scratch in ready_installations():
        result = subprocess.run([sys.executable, "-B", str(evidence / "capture-installed-proof.py"),
                                 str(scratch), str(capture)], capture_output=True, text=True)
        if result.returncode == 0:
            print(result.stdout, end="", flush=True)
            return True
    return False


def requested_verdict():
    try:
        value = json.loads((output / "verdict.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    candidate = value.get("candidate") or {}
    if candidate.get("commit") == expected and value.get("evidence_dir") != "attempt-8975pq86":
        return value
    return None


while True:
    attempts = {path.name for path in output.glob("attempt-*")}
    fresh = attempts - seen - {"attempt-8975pq86"}
    if fresh:
        print(json.dumps({"new_attempts": sorted(fresh)}), flush=True)
    seen = attempts
    if not capture.exists():
        capture_ready()
    verdict = requested_verdict()
    if verdict:
        print(json.dumps({"candidate": expected, "phase": verdict["phase"],
                          "attempt": verdict["evidence_dir"], "verdict": verdict.get("verdict"),
                          "error": verdict.get("error"), "captured_installations": capture.exists()}),
              flush=True)
        break
    time.sleep(30)
