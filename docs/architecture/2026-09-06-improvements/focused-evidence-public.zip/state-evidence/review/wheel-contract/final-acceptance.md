# Clean-wheel acceptance audit

The frozen candidate was refused. All 4,397 candidate tests passed, but the actual verification row records two findings. This attempt is evidence of a working refusal, not acceptance for shipping.

| Item | Retained result |
|---|---|
| Base | `47629ea14ddea38e55ce2332d08297c31888acb9` |
| Candidate | `9e084545e85779121943ea48346dc8f895ed0af6` |
| Driver phase | `complete` |
| Suite exits | Base `1`; candidate `0` |
| Candidate ledger | Run `2`, kind `verify`, `verdict_ok=0`, `findings=2` |
| Baseline copy | Complete base ledger preserved as candidate run `1` |
| Verdict comparison | CLI output agrees with the stored row |

## Tests and skips

| Revision and suite | Passed | Failed | Skipped |
|---|---:|---:|---:|
| Base unit | 3,396 | 2 | 42 |
| Base e2e | 717 | 0 | 2 |
| Candidate unit | 3,638 | 0 | 1 |
| Candidate e2e | 759 | 0 | 2 |

The base failures are `test_powershell_admission::test_the_documented_pester_glob_reaches_a_root_level_test_file` and `test_version_metadata_cost::test_a_source_tree_with_nothing_installed_falls_back_to_the_package`. They are the known installed-wheel test assumptions repaired in the candidate. They remain failed in the immutable base evidence.

Base unit skips comprise 41 missing-YAML cases and one missing-Pillow collection skip in `test_demo_generator`. Candidate unit skips only `test_measurement_owner::test_owned_commands_keep_the_shell_signal_return_code`, which requires POSIX signal return codes. Both revisions skip two optional latency tests unless `CRAPKIT_STRICT_TIMING=1` is set. The receipt lists every skipped ID and reason.

Combined JUnit exactly reproduces both individual suite reports. Declared testcase totals match recorded cases. The existing JUnit admission parser accepts both combined reports; neither contains an unfinished-worker or session error. Reported test counts and failed IDs match the retained XML.

## Refused gates

| Function | Source line | CCN | Coverage | CRAP |
|---|---:|---:|---:|---:|
| `_ratchet_merge` | `src/crapkit/cli/ratchet_cmds.py:86` | 6 | 50% | 10.5 |
| `run_bounded` | `src/crapkit/procs.py:257` | 6 | 50% | 10.5 |

Both gates request tests. There are no new failed tests, ratchet regressions, or overrides. The report also records 24 changed uncovered lines; this repository has no configured diff-uncovered maximum. Separate follow-up work owns the two gate repairs. This audit leaves the failed attempt intact.

## Source and measurement checks

Independent reads of the live installed environments and wheel archives matched the driver's retained proofs. All 64 base Python source files match their exact Git revision; all 69 candidate files match theirs. Neither import resolved to an editable source tree. The independent hashes were captured before scratch cleanup in `final-installed-proof.json`.

Both coverage reports contain branch data for every package Python file. There are no foreign files, deleted synthetic package paths, absolute coverage keys, or missing package files. Candidate coverage and JUnit byte hashes match its stored lane. Base coverage bytes match its lane; that immutable version did not store a JUnit digest, so the base JUnit check uses its retained counts and failed IDs.

| Coverage | Base | Candidate |
|---|---:|---:|
| Lines covered | 9,519 / 9,651 | 9,914 / 10,066 |
| Branches covered | 2,471 / 2,538 | 2,537 / 2,616 |
| Branch percentage | 97.36% | 96.98% |

The selected override publication, prune, history snapshot, ratchet replay, atomic replacement, compare-and-swap, verify settlement, annotation encoding, and config admission functions have no missing executable lines or branch arcs. The receipt records exceptions separately: one unmeasured `_ratchet_entries` arc, the POSIX lock implementation on this Windows run, two measurement-key error lines, and the malformed-artifact-map path. The two refused functions remain explicit coverage gaps.

Tool scripts are outside the `--cov=crapkit` measurement. Their testcases are in the retained JUnit; this audit does not claim branch coverage for the testing or release tools.

## Unit-test duration

| Test | Seconds |
|---|---:|
| `test_advisory_coverage_contexts::test_advisory_and_following_test_pass_under_configured_contexts` | 31.035 |
| `test_release_recovery::test_uncertain_upload_stays_pending_and_retry_waits_for_readback` | 19.933 |
| `test_ci_verdict::test_installed_source_is_verified_before_coverage_paths_are_mapped` | 15.072 |
| `test_analyze_one_pass::test_the_single_pass_reproduces_the_two_pass_record_for_every_committed_source` | 10.942 |
| `test_ci_failure_evidence::test_ci_preserves_failed_measurement_and_copied_ledger` | 7.420 |

Cases 2,953 through 3,024 account for 143.0 seconds. They bracket the serial progress display's 81%-83% interval and include release destination, guard, and recovery subprocess tests. The XML explains the pause as completed work across many cases.

## Evidence and replay

The raw attempt is `work/implementation/final-ci-complete/attempt-8975pq86`; its sibling `verdict.json` identifies the same attempt. The full log is `work/implementation/final-ci-complete.log`. The structured audit is `final-acceptance.json` beside this note, with every nonpassing testcase, exact hashes, ledger rows, and selected function coverage.

From the projectless workspace, with the frozen repository's `src` on PYTHONPATH:

```powershell
python -B work/implementation/state-evidence/review/wheel-contract/audit-final.py C:/Users/jfgag/crapkit work/implementation/final-ci-complete work/implementation/state-evidence/review/wheel-contract/final-acceptance.json
```

The audit uses read-only SQLite connections. It runs no tests and changes no source, configuration, or historical root ledger. `capture-installed-proof.py` was a live read before the driver's temporary environments were deleted; that capture cannot be repeated against deleted paths.
