# Wheel and CI contract repair

All edits stayed in the c205602-based ci-wheel-contract checkout. Root source and its ledger were not changed.

## Implemented

| Failure | Repair | Red evidence |
|---|---|---|
| Pester docs test searched below wheel Lib/docs | Locate repository docs from the test file, while importing the installed package | red.txt |
| No-dist test added the installed site-packages directory back under -S | Copy only the imported package into a temporary source directory | red.txt |
| Clean development install skipped YAML and Pillow contracts | Declare PyYAML>=6 and Pillow in the dev extra, with a dependency admission test | red.txt; pillow-red.txt |
| Nested pytest inherited the outer wheel coverage source | Pass COVERAGE_RCFILE as an explicit outer --cov-config argument and remove it from child environment | init-wheel-red.txt; config-red.txt |
| A complete historical baseline failure rejected a passing candidate | Keep baseline exits, failures and counts; require candidate suite success and a passing real verdict | baseline-red.txt |
| Explicit reuse accepted missing, empty or crashed baseline JUnit with only a warning | Invoke each installed revision's existing JUnit parser before either revision is scored | baseline-red.txt |
| New config test read a fixed output after default output isolation | Request --output .crapkit/cov explicitly | output-red.txt |

The baseline remains immutable. No failed testcase is deleted, renamed or converted to a pass. A complete failing baseline is valid input to the existing no-new-failures comparison. Missing or unfinished evidence is not. The candidate must still pass its complete suites even when its failing ID also exists in the baseline.

PyYAML serves the action, workflow and skill contracts. Pillow serves committed rendering tests. No repository Pillow version floor existed, so its dependency has no invented minimum. The original clean CI log had 41 missing-yaml skips and one missing-PIL module skip; the module skip hid additional test cases.

## Validation

- Three failures reproduced against an installed c205602 wheel: Pester docs path, no-dist metadata behavior, and undeclared PyYAML. The Pillow contract failed separately before admission.
- 162 tests passed with zero skips in a new environment installed from the rebuilt wheel's dev extra. Included PowerShell admission, metadata behavior, dev dependencies, action/skill YAML contracts and both demo test files. Evidence: clean-wheel-green.txt.
- 23 driver/schedule/admission checks passed in that clean environment. Included configured and absent contexts, actual nested pytest with a concurrent CLI sibling, wheel source mapping, baseline failure policy, refusal evidence and generated docs. Evidence: clean-driver-green.txt.
- The original init-scaffold e2e plus two peers passed under two outer workers with coverage 7.16.0 and pytest-cov 7.1.0. Evidence: init-clean-wheel-green.txt.
- Complete installed-source equality was checked through ci.installed_source. The wheel digest and every Python source digest are recorded in source-proof.json.
- Every function in tools/testing/ci.py and run.py had CCN at or below 6 before the output dependency integration. The edited _suite is 3 and the new _test_evidence is 2. The active pre-commit hook passed for the main commit.
- Main commit: 2a58048. Output migration dependencies 7a098fc and 045a242 were then cherry-picked only into this isolated checkout for compatibility checks. They are already owned by the execution agent and are not part of this handoff.

All Python commands used this checkout's PYTHONPATH. The wheel-test subprocess boundary deliberately removes PYTHONPATH and checks that crapkit imports from its own virtual environment, so those tests cannot fall back to the root editable install. Initial environment setup found lizard only in user site-packages; installing it into the disposable environment repaired that setup before the recorded behavioral red run. The final validation used a new clean environment with the whole dev extra.

## Commands

From the isolated checkout, set PYTHONPATH to its src. run-wheel-tests.py takes the checkout path, the clean environment's Python path and pytest test paths. init-wheel.py takes the same first two arguments and runs the original e2e through the outer runner with a wheel coverage config. Both scripts and every red/green log remain beside this note.

The unrelated final CI contamination from a synthetic package is assigned to root and was not changed here. The original baseline failures remain in the retained first-pair evidence; this patch does not claim that old attempt passed.

## Collection-error admission follow-up

The real fixture produces a unit SyntaxError and a passing parallel e2e CLI test. Before the repair, the runner accepted pytest exit 2 as complete because its JUnit already contained an error. In the tested coverage 7.16.0 environment, a missing unit coverage file caused a later combine failure and prevented final publication. That later failure masked the JUnit admission defect; this probe does not claim that this particular fixture published partial coverage. The retained red log records both facts.

The runner now accepts only pytest exit 0, or exit 1 with recorded failure/error evidence. Other exits retain the original JUnit and add an explicit infrastructure error before coverage combination. A collection error therefore cannot rely on coverage combination to establish incompleteness. Both suites still execute.

- Red: collection-red.txt, one failing public runner regression. It retained the original SyntaxError and passing e2e testcase but lacked an explicit `unit exited 2` infrastructure error.
- Green: collection-green.txt, 13 tests passed in the clean wheel environment. Included the new collection case, passing suites, unit and e2e assertion failures, configured and absent contexts, empty/startup failures, baseline JUnit admission and nested coverage config ownership.
- CCN: `_completed_pytest` is 4; `_suite_xml` is 4. `git diff --check` passed.
- Output follow-up commit: `1c26f40e26f3b5fce1c82a4ba950ae42003caa63`, with 8 passing checks in output-green.txt.
- Collection admission commit: `15453818dcef9b7a42486ec30db4a2b28485bd43`. Active pre-commit hook passed, and the checkout is clean. Hook output: collection-commit.txt.

Replay from the isolated checkout with its src on PYTHONPATH:

```powershell
python -B ../state-evidence/review/wheel-contract/run-wheel-tests.py (Get-Location).Path ../state-evidence/review/wheel-contract/clean-venv/Scripts/python.exe tests/unit/test_suite_collection_failure.py tests/unit/test_suite_schedule.py tests/unit/test_ci_baseline_admission.py tests/unit/test_suite_config_ownership.py
```
