from pathlib import Path
import json, os, subprocess, sys, tempfile
import xml.etree.ElementTree as ET
ROOT = Path(r'C:\Users\jfgag\crapkit')
RUN = ROOT / 'tools/testing/run.py'
with tempfile.TemporaryDirectory(prefix='suite-evidence-') as folder:
    repo = Path(folder)
    for suite in ('unit', 'e2e'):
        (repo / 'tests' / suite).mkdir(parents=True)
        (repo / 'tests' / suite / 'test_ok.py').write_text('def test_initial():\n    assert True\n')
    (repo / 'pyproject.toml').write_text('[tool.pytest.ini_options]\ntestpaths=["tests"]\n')
    command = [sys.executable, str(RUN), '--repo', str(repo), '--workers', '2']
    first = subprocess.run(command, capture_output=True, text=True)
    evidence = repo / '.crapkit/cov/junit.xml'
    before = evidence.read_bytes()
    (repo / 'tests/unit/conftest.py').write_text('raise RuntimeError("unit startup failed")\n')
    (repo / 'tests/e2e/test_ok.py').write_text('def test_current():\n    assert True\n')
    second = subprocess.run(command, capture_output=True, text=True)
    print(json.dumps({'first_exit': first.returncode, 'second_exit': second.returncode,
                      'junit_unchanged': evidence.read_bytes() == before,
                      'recorded_tests': [case.attrib['name'] for case in ET.parse(evidence).findall('.//testcase')],
                      'scratch_left': [p.name for p in evidence.parent.iterdir()],
                      'second_stderr': second.stderr[-1600:]}, indent=2))
    assert first.returncode == 0 and second.returncode == 1
    assert evidence.read_bytes() == before
