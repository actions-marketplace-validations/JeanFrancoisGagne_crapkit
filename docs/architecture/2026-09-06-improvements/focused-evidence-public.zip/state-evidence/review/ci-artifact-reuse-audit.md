# Reusing retained CI artifacts in the root checkout

Reviewed root HEAD c20560241643f66093380ca04fc8ec91f83159ea. Root source and state were not changed. The final CI attempt was still running during this review, so the completed candidate artifacts have not yet been inspected.

## Decision

The candidate coverage JSON and combined JUnit can be copied into the root checkout after the checks below. Keep the root SQLite ledger. Do not copy the retained candidate ledger, the baseline ledger, artifact stamps, coverage databases or the entire cov directory over root state.

The retained ledger is evidence to read and compare. It is not the ledger to install. Root coverage and verify append their own runs and record the hashes of the artifacts they actually read.

## Required admission checks

1. Read the completed attempt's own verdict.json. Confirm evidence_dir names that same attempt, phase is complete, candidate.commit equals root HEAD, and the candidate suite exit is 0. For a fully passing CI result, both suite exits must be 0 and verdict.ok must be true. A false verdict with passing suites is still a valid measurement of a refused candidate, but it must not be relabeled as a successful verification.
2. Require the root checkout's tracked files to match HEAD. Recompute SHA-256 for every *.py below src/crapkit. Require exact path-set and digest equality with candidate.source_sha256, including missing or added files. The source proof covers installed Python files, not arbitrary source roots or changed tests/configuration. The exact clean commit check covers the tracked tests and configuration used by CI.
3. Read candidate/crap.sqlite with SQLite URI mode=ro. Locate verdict.run_id and require its commit, kind=verify, verdict_ok and findings to match the retained verdict. Decode runs.lanes, zlib-compressed for current stores. Require lanes.py.artifact_sha256 to equal the raw candidate/cov/py.json SHA-256 and results_artifact_sha256 to equal the raw candidate/cov/junit.xml SHA-256. This links the retained artifacts to the actual CI verdict, rather than relying on their filenames.
4. Parse candidate/cov/unit.xml, e2e.xml and junit.xml. Both suite reports must contain cases, without failure, error or unfinished-worker records. The combined case multiset and skipped count must equal the two suite reports together. Crapkit's junitparse.suite_summary supplies the actual admission and failure-ID rules. Keep combined JUnit bytes unchanged so IDs and its recorded digest remain intact.
5. Require coverage meta.branch_coverage=true. Validate every files key, not only one key that overlaps src. Each admitted file must resolve to a src/crapkit path present in the source SHA map. Keep the entire per-file record unchanged, including functions, branches, classes, summaries and contexts. Reject duplicate destination keys and unknown or escaping paths. Run covstream.parse_coveragepy_both_file with path_prefix='' against the admitted JSON before copying.
6. Record raw coverage and JUnit hashes plus any rewritten coverage hash in a separate workspace receipt. Keep the original attempt immutable. Compare copied destination bytes against the validated receipt before invoking Crapkit.

## Coverage paths

The driver already writes a coverage [paths] rule with the candidate checkout's src/crapkit first and the proved wheel package second. The runner combines and emits JSON from that candidate checkout. The existing real-wheel test confirms emitted keys such as src/crapkit/__init__.py. Relative keys need no rewrite and allow byte-identical copying even after scratch cleanup.

Do not assume all keys are relative until the final file has been checked. If any key is absolute, rewrite only a proved root prefix to src/crapkit/. The allowed wheel prefix is candidate.package from the same attempt's proof. A candidate checkout prefix must be established from that attempt's generated wheel.coveragerc or the exact scratch layout created by tools/testing/ci.py, not by searching for a coincidental /src/crapkit/ suffix. Reject paths outside those roots. Normalize separators, preserve relative suffixes, verify those suffixes against source_sha256, and reject collisions.

Only the top-level files keys need rewriting for Crapkit. Absolute names inside JUnit messages or coverage metadata do not participate in its source join. Do not rewrite arbitrary strings or embedded function data. Deterministic JSON output can use sorted keys, fixed separators and one trailing newline. Record that this changes the artifact hash; the root's fresh run will record the rewritten hash, while the retained CI ledger continues to attest to the original hash.

The SHA map establishes that the installed wheel and root package have the same complete Python contents. It justifies moving line and branch locations between those proved roots. It does not justify accepting unrelated measured paths merely because a basename matches.

## Baseline and command order

Root's latest trusted run is 72 at 499d9db4f9ff4d212fb94ea3975c7477b6b1c968. The merge-base of that commit and review baseline 47629ea14ddea38e55ce2332d08297c31888acb9 is 499d9db. The only intervening commit is 47629ea, which adds 49 review-document/evidence files and changes no production source, tests or configuration.

| Option | Stored baseline | Diff basis |
|---|---|---|
| --baseline 72 | Exactly run 72 | 499d9db |
| --base 47629ea | Newest trusted run at or behind 47629ea, currently 72 | 47629ea |

Use --base 47629ea for the root verdict of all implementation changes after the review. The isolated CI pair remains the comparison against a newly measured 47629ea baseline. The root command uses run 72's existing lane history, so it is a separate validation with the same production diff and older measured failure/count provenance.

Run verification before adding a coverage run. Plain default verify after coverage would choose the new HEAD baseline and lose the implementation diff. Explicit --baseline 72 remains safe after coverage. Explicit --base 47629ea remains safe too because a new HEAD run is beyond the requested basis and cannot replace run 72 there.

After artifact admission and the two-file copy, the proposed root commands are:

```powershell
Set-Location -LiteralPath C:\Users\jfgag\crapkit
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
python -B -m crapkit verify --reuse-artifacts --no-tighten --base 47629ea --json
```

Read the emitted run_id back from the root ledger and require kind=verify, the current commit, verdict_ok and findings to agree with JSON. Require its stored coverage/JUnit hashes to match the admitted destination hashes. Check pre-existing run records are unchanged and remain present. --no-tighten preserves the marks file; successful verification can still close resolved claims through its normal command behavior.

If a separate coverage snapshot is wanted after successful verification:

```powershell
python -B -m crapkit coverage --reuse-artifacts --json
python -B -m crapkit verify --reuse-artifacts --no-tighten --base 47629ea --json
```

Using --baseline 72 on both verify commands is also valid. Do not supply --baseline and --base together; the parser makes them mutually exclusive.

## Existing root stamps

Root .crapkit/artifacts.json still holds an old py stamp at 20f00e1 and an old refused_mtime_ns. Reuse writes no fresh measurement stamp. A newly copied file normally has a different mtime and does not match that old refusal, but check it before invocation. An old-stamp warning can still name stale coverage even when the imported artifact has been independently proved against c205602. Record this as imported evidence provenance; do not forge a current execution-input stamp or promise that --reuse-unchanged will use it.

The requested commands explicitly use --reuse-artifacts and do not need new stamps. Avoid copying the CI stamp file or changing source configuration to suppress the warning.

## Code checked

| Owner | Current lines | Fact |
|---|---|---|
| tools/testing/ci.py | 44-67 | Proves complete wheel source bytes and records candidate commit |
| tools/testing/ci.py | 71-81 | Maps wheel source to candidate checkout for measurement |
| tools/testing/ci.py | 109-125 | Copies baseline only inside isolated CI and verifies ledger receipt |
| tools/testing/ci.py | 136-157 | Retains per-attempt coverage and read-back ledger before cleanup |
| tools/testing/run.py | 68-75 | Combines suite databases and emits JSON from checkout cwd |
| src/crapkit/cli/scoring.py | 495-517 | Reuse scoring appends a coverage run to the existing store |
| src/crapkit/cli/verifying.py | 138-189 | --base limits eligible stored baselines and fixes the diff basis |
| src/crapkit/cli/verifying.py | 591-665 | Verify reads then appends to the existing store |
| src/crapkit/lanes.py | 497-530, 632-645, 1092-1165 | Reuse keeps stamps, parses actual files, records their digests |
| src/crapkit/junitparse.py | 27-29, 91-105 | Stable failure IDs and unfinished/empty-suite refusal |
| tests/unit/test_ci_verdict.py | 86-109 | Real installed-package measurement yields repository-relative keys |
