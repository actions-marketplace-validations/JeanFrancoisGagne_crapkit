# Release recovery review

Read-only review of the working RT3 implementation in `work/implementation/analysis-rerun/tools/release/release.py`, its new recovery tests and the release guard tests. No source files were changed. All publication responses in the probe use the existing in-memory adapter; Git writes stay inside disposable local repositories and their local bare remote.

## New confirmed finding

**A completed push becomes incomplete when remote main advances.** At the reviewed `_pushed` implementation, `release.py:687-694`, confirmation requires both remote `main` and the release tag to equal the receipt's HEAD. After the push and first PyPI upload succeeded, the probe advanced remote main by one ordinary descendant commit. The immutable tag and local release checkout stayed unchanged. Retrying stage 2b attempted another push, failed non-fast-forward, recorded `pending=["push"]`, and stopped before the source archive upload.

Evidence: `release-main-advance.py` and `release-main-advance.txt`. The probe calls the public `release.run("stage2b", ...)` twice and proves remote main still contains the release with `git merge-base --is-ancestor`. It records two push attempts and one of the two expected package files. The first attempt's error follows an upload whose digest readback already confirmed success.

Sent to root and `analysis_performance`. The owner proposed preserving proof of the originally confirmed push and requiring the immutable tag to keep matching on retry, while allowing main to advance. First publication would retain its exact branch/tag checks. Policy and implementation remain with that owner.

## Retained checks

| Area | Result |
|---|---|
| Source and receipt preflight | Clean main, exact local tag/HEAD, version surfaces, contract receipt and a newer passing full verify are checked before publication. Build completion rechecks the proof. |
| Artifact order and identity | Wheel and sdist build/check precede push. Their names and hashes enter the receipt; retries reject missing, altered, extra or redirected local files and reuse confirmed bytes. |
| Partial file publication | Each expected file has its own readback and pending action. Known matching bytes skip upload. Any known conflicting expected digest refuses before another upload. |
| Unknown outcomes | Pending is recorded before the command. Command failure and unknown readback do not trigger an automatic duplicate upload. The new README gives the manual recovery procedure already requested by root. |
| Wrong or malformed remote data | Wrong versions, draft/wrong-tag releases, invalid digest formats, duplicate filenames, nonobject JSON, malformed file lists and read failures stop confirmation. Older GitHub assets can be hashed from their downloaded bytes. |
| Pages | Queued/building waits and definitive errored recovery were already under repair. They are excluded from the new finding. |
| Local plugin update | Successful updates are recorded; an interrupted local update can repeat under the documented policy. |

No additional substantiated findings in the assigned area. This review did not publish to PyPI, GitHub, Pages or the registry, and did not run the complete release suite. Existing recovery tests were inspected; the new main-advance case was independently replayed.
