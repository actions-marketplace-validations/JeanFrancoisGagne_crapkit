# State fixes, ST1 through ST6

Checkout: `work/implementation/state`, branch `architecture/state-fixes-20260906`, parent `47629ea14ddea38e55ce2332d08297c31888acb9`.

Completed in commit `30d3a5f`. Both the explicit pre-commit run and the commit's active hook passed. The only remaining untracked source is the byte-identical execution-owned `locks.py` dependency; it is not part of this commit.

| Item | Change | Regression evidence |
|---|---|---|
| ST1 | Audit insertion and prune take short SQLite write transactions. Prune rechecks audit ownership while deleting. An alert can run without a SQL lock; if prune wins, audit insertion refuses before any grant. | `ST1-red.txt`, `ST1-green.txt`, `test_override_prune_concurrency.py` |
| ST2 | Packet age uses the ratchet report replay. An updated mark retains its entry date. | `ST2-red.txt`, `ST2-green.txt`, `test_packet_history_updates.py` |
| ST3 | Worklist and brief defer inventory rows until legacy ratchet admission asks for proof. Absent marks and current key versions skip that scan. | `ST3-red.txt`, `ST3-green.txt`, `test_worklist_optional_ratchet.py` |
| ST4 | Every ratchet writer captures one input, checks that input, then compares its raw-byte digest under a short OS lock before atomic replacement. A stale command refuses and leaves the intervening file intact. | `ST4-red.txt`, `ST4-admission-red.txt`, `ST4-override-admission-red.txt`, `ST4-final-regressions-green.txt`, `test_ratchet_publication_concurrency.py` |
| ST5 | Trend and HTML history read run metadata, totals and scope totals from one SQLite snapshot. Cache publication occurs afterward and skips runs deleted in the meantime. | `ST5-red.txt`, `ST5-green.txt`, `ST5-publication-red.txt`, `ST5-publication-green.txt`, `test_trend_snapshot_concurrency.py` |
| ST6 | GitHub annotation properties escape percent signs, line breaks, colons and commas. Message encoding keeps ordinary colons and commas. | `ST6-red.txt`, `ST6-green.txt`, `test_github_annotation_properties.py` |

## Decisions

ST1 uses the existing runs and overrides tables. A pending-operation table would need its own recovery and expiry policy. A lock held across the alert would block pruning for arbitrary external work. The existing grant-last rule needs neither: a failed alert writes no audit; a vanished run refuses its audit; an inserted audit protects its run before the grant can land. A failed later file publication can leave an audit without a grant, which is safe and visible. No successful override is reported in that case.

ST4 uses optimistic concurrency rather than holding a lock across lanes or alerts. Automatic minimum merging would destroy explicit grants and misinterpret deletions. The shared OS lock handles competing current writers without stale PID files; a digest check detects changes made since admission. The temporary file is flushed before replacement, preserves the existing mode and is removed on failure. Seed, prune, move, merge, standalone overrides, verify overrides and hook overrides use this owner. Verify captures before lanes, and the receipt hashes those exact bytes, including an initial BOM and CRLF. Publication must succeed before its run becomes trusted.

The shared `locks.py` comes from execution commit `837b115` and is excluded from the state commit. Root must integrate that dependency first. `repotext.py` gained a byte-input decoder with root's approval; its existing file reader uses the same decoder. The change removes verify's separate hash read and override's repeated file reads.

ST5 keeps cache writes outside the read snapshot. Holding a write lock around history formatting would delay measurement writers. Combining totals in one SQL query without capturing metadata would leave the demonstrated race. The new collector owns both reads and uses the existing cache format. No schema migration is needed.

## Validation and limits

- `owned-unit.txt` and `owned-unit.xml`: 536 tests passed. Tests cover store retention, trust, current and legacy identity, finite marks, reports, packet, worklist, SARIF, ratchet operations and verify assembly.
- `ST4-byte-receipt-green.txt`: the additional BOM/CRLF receipt test passed.
- `owned-e2e.txt` and `owned-e2e.xml`: 164 affected CLI tests passed with eight workers, including ratchet merge/move/seed/prune, verify basis, hook marks, same-line identity, reports, worklist, packet, encoding and claim competition.
- `complexity.tsv`: all 436 functions in changed production modules have CCN at or below 6.
- Concurrency regressions launch real subprocesses and pause at actual command operations. The SQLite history test enables WAL in its disposable fixture so the competing writer can commit during the read snapshot. No production journal mode changes.
- File replacement is atomic for cooperative current writers on the local filesystem. A manual editor or older writer that ignores the lock can still change a file after the final check. This patch does not claim cross-process atomicity with nonparticipating writers or power-loss durability for a directory entry.
- The shared lock is nonblocking and reports contention. Stale ratchet publication is a configuration refusal with a rerun instruction; file I/O failure names the ratchet and operation. Lanes and alerts run outside file and SQL locks.
- The broader integrated suites and self-verification belong to root. No source, tests or configuration were changed in root by this task.

Replay from the state checkout with `PYTHONPATH` set to its `src` directory. Use the committed regression files, not the older review probes that called retired helpers. Exact commands and red/green logs remain beside this note; `decisions.tsv` records each choice.
