"""Reject coverage entries outside the package whose source was measured."""
import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("artifact", type=Path)
    parser.add_argument("--repo", type=Path, required=True)
    args = parser.parse_args()
    root = args.repo.resolve()
    data = args.artifact.read_bytes()
    files = json.loads(data)["files"]
    foreign = [name for name in files
               if not (root / name).resolve().is_relative_to(root / "src/crapkit")]
    print(json.dumps({"artifact_sha256": hashlib.sha256(data).hexdigest(),
                      "files": len(files), "foreign_source": foreign}, indent=2))
    return int(bool(foreign))


if __name__ == "__main__":
    raise SystemExit(main())
