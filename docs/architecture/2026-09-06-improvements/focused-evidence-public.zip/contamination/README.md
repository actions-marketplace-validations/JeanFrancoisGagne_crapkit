# Synthetic coverage isolation

The first clean-wheel candidate run could not emit coverage JSON. Its outer
database contained a temporary miniature `crapkit` package that pytest had
already deleted. The empty-suite fixture replaced PYTHONPATH but inherited
COVERAGE_PROCESS_CONFIG, so the automatic subprocess tracer measured the
miniature package as part of the real one.

The red replay ran the existing empty-suite regression beneath real branch
coverage. Pytest passed, but check-source.py found the miniature package in
red.json and exited 1. This distinguishes a passing fixture assertion from
valid outer measurement evidence.

One fixture_env helper now removes coverage settings before selecting the
miniature package. The fixture's own runner still measures its branches and
contexts. The three schedule, nested-coverage and output-ownership test modules
passed together under outer branch coverage: 11 tests, no foreign source
entries, and 69 admitted real package files in green.json.

Run the checks from any directory:

```powershell
python check-source.py red.json --repo C:/Users/jfgag/crapkit
python check-source.py green.json --repo C:/Users/jfgag/crapkit
```

For a fresh replay, set PYTHONPATH to the checkout's src and COVERAGE_FILE to
an isolated evidence file, then run:

```powershell
python -m pytest tests/unit/test_suite_schedule.py tests/unit/test_suite_nested_coverage.py tests/unit/test_suite_output_ownership.py -q -p no:randomly --cov=crapkit --cov-branch --cov-report=json:green.json
```
