"""Summarize retained full-suite evidence without using a command's exit as proof."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


def case_id(case):
    return case.get("classname", "") + "::" + case.get("name", "")


def failed(case):
    return case.find("failure") is not None or case.find("error") is not None


def suite(path):
    raw = path.read_bytes()
    root = ET.fromstring(raw)
    cases = list(root.iter("testcase"))
    failures = [case_id(case) for case in cases if failed(case)]
    skips = Counter(node.get("message", "") for node in root.iter("skipped"))
    return {"tests": len(cases), "passed": len(cases) - len(failures) - sum(skips.values()),
            "failed": len(failures), "skipped": sum(skips.values()), "skip_reasons": dict(skips),
            "seconds": sum(float(node.get("time", "0")) for node in root.findall("testsuite")),
            "failures": failures, "junit_sha256": hashlib.sha256(raw).hexdigest()}


def summarize(path):
    saved = json.loads(path.read_text(encoding="utf-8"))
    retained = path.parent / saved["evidence_dir"]
    suites = {revision: {name: suite(retained / revision / "cov" / (name + ".xml"))
                         for name in ("unit", "e2e")} for revision in ("base", "candidate")}
    return {"phase": saved["phase"], "suite_exits": saved["suite_exits"],
            "base_commit": saved["base"]["commit"], "candidate_commit": saved["candidate"]["commit"],
            "suites": suites, "verdict": saved["verdict"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("verdict", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.write_text(json.dumps(summarize(args.verdict), indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
