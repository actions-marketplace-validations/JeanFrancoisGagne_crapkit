$ErrorActionPreference = 'Continue'
$taskRepo = 'C:\Users\jfgag\crapkit'
$taskWork = 'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\implementation'
$taskSelf = Join-Path $taskWork 'self-final'
$taskPython = Join-Path $taskWork 'configured-runtime\venv\Scripts\python.exe'
$taskGlobalPython = 'C:\Users\jfgag\AppData\Local\Programs\Python\Python311\python.exe'
$taskOriginalPath = $env:PATH
$taskExpectedCommit = '802257c8796070f6a6be72e99cf284f6afd13362'

function Assert-NativeSuccess([string]$Step) {
    $taskStepExit = $LASTEXITCODE
    if ($taskStepExit -ne 0) {
        Write-Output "$Step failed (exit $taskStepExit)"
        exit $taskStepExit
    }
}

Set-Location -LiteralPath $taskRepo -ErrorAction Stop
if ((git rev-parse HEAD) -ne $taskExpectedCommit) { throw 'The expected test-repair commit changed.' }
git diff --exit-code
Assert-NativeSuccess 'Tracked input check'
$env:PYTHONPATH = Join-Path $taskRepo 'src'
$env:PATH = (Split-Path $taskPython) + [IO.Path]::PathSeparator + $taskOriginalPath

& $taskPython -c "import json,sys; from importlib.metadata import version; print(json.dumps(dict(python=sys.version,executable=sys.executable,packages={name:version(name) for name in ['pytest','pytest-cov','coverage','pytest-xdist']}),indent=2))" > (Join-Path $taskSelf 'environment.json')
Assert-NativeSuccess 'Environment record'
& $taskPython (Join-Path $taskSelf 'configured_audit.py') snapshot --repo $taskRepo --output $taskSelf
Assert-NativeSuccess 'Input and ledger snapshot'

& $taskPython -m crapkit coverage --json 1> (Join-Path $taskSelf 'coverage.json') 2> (Join-Path $taskSelf 'coverage.stderr.log')
Assert-NativeSuccess 'Configured coverage'
& $taskPython -m crapkit verify --reuse-artifacts --no-tighten --base 47629ea14ddea38e55ce2332d08297c31888acb9 --json 1> (Join-Path $taskSelf 'verify.json') 2> (Join-Path $taskSelf 'verify.stderr.log')
Assert-NativeSuccess 'Configured verification'
& $taskPython (Join-Path $taskSelf 'configured_audit.py') audit --repo $taskRepo --output $taskSelf
Assert-NativeSuccess 'Input and ledger preservation audit'

Get-ChildItem -LiteralPath (Join-Path $taskRepo '.crapkit\cov') -File | Copy-Item -Destination $taskSelf -ErrorAction Stop
foreach ($taskName in @('lane-py.log', 'artifacts.json', 'stat-stamps.json')) {
    Copy-Item -LiteralPath (Join-Path $taskRepo ".crapkit\$taskName") -Destination $taskSelf -ErrorAction Stop
}
& $taskPython -c "import sqlite3; original=sqlite3.connect(r'C:\Users\jfgag\crapkit\.crapkit\crap.sqlite'); copied=sqlite3.connect(r'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\implementation\self-final\configured-after.sqlite'); original.backup(copied); copied.close(); original.close()"
Assert-NativeSuccess 'Verified ledger backup'
Write-Output 'CONFIGURED_VERIFICATION_PASSED'

$env:PATH = $taskOriginalPath
& $taskGlobalPython tools/testing/ci.py --base 47629ea14ddea38e55ce2332d08297c31888acb9 --output (Join-Path $taskWork 'final-ci-complete') 1> (Join-Path $taskWork 'final-ci-complete.log') 2>&1
Assert-NativeSuccess 'Isolated wheel comparison'
Write-Output 'FINAL_WHEEL_COMPARISON_PASSED'
