# Configured-run collector follow-up

Only the untracked `docs/architecture/2026-09-06-improvements/collect-evidence.py` changed in root. Tracked source remains frozen; no commit or final archive was created.

- Added the top-level files in `state-evidence/review/wheel-contract`. All 27 files present at inspection are selected; nested checkouts, environments and fixture directories remain excluded. A later top-level final-acceptance.md will be selected automatically.
- Excluded the three abandoned self-final importer drafts by exact relative path: admit_ci_artifacts.py, test_artifact_import.py and IMPORTER-DRAFT.md. These drafts are not executed verification evidence.
- Added self-final *.xml and *.coverage patterns for the actual configured run, including a bare .coverage file. Existing configured audit scripts, JSON, logs and historical SQLite backup selection remain intact.

`collector-configured-red.txt` records the five missing required files and three wrongly retained drafts. `collector-configured-green.txt` records a disposable archive created under this evidence directory: 21 required files retained, 10 forbidden files excluded, and every archived manifest hash and size matched. The fixture was removed after checking.

`collector-configured-selection.json` records actual path-selection checks without reading or archiving active run artifacts. It confirms all wheel-contract files are selected, importer drafts are excluded and the configured audit/backup files are selected. Collector CCN remains 5, 2 and 1. No final result was inferred from active logs or progress.

No collection gap remains for the named evidence. Final XML/coverage files and the acceptance note are still being produced; their absence now is pending work, not a passing result. Root owns the configured-run verdict and final report wording.
