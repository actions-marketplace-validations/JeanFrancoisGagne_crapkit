# Verification report update at frozen 802257c

Changed only the untracked root report `docs/architecture/2026-09-06-improvements/implementation.md`. No tracked file, threshold, collector or artifact changed, and no commit or test command ran.

The report now records the actual outcomes separately from test counts:

- Frozen 9e08454 clean-wheel candidate: 4,397 passes and three skips, but CI verify run 2 refused two gates. Both functions had CCN 6, coverage 0.5 and CRAP 10.5.
- Normal configured measurement run 73: 4,396 passes, one failure and three skips. Unit and CLI counts and durations match self-refused/lane-py.log. Root verify 74 against baseline 72 refused the two gates plus the ownership test failure.
- self-refused/refused-audit.json proves all original 72 runs and 737 tracked inputs survived unchanged. Historical artifacts and backups remain retained as refused evidence.
- Integrated test-only commits a0d84fb and 802257c add the missing merge/cancellation checks and remove the ownership test's incidental deadline. Both functions now measure coverage 1.0, CCN 6 and CRAP 6 in focused checks. Existing timing budgets remain unchanged; quiet.log records two unchanged checks passing in 7.84 seconds.
- Final source 802257c8796070f6a6be72e99cf284f6afd13362 uses the isolated declared runtime. Its configured run and fresh CI pair execute sequentially. The snapshot records 74 existing runs and 739 tracked inputs; final verdicts and preservation audit remain pending.

The older c205602 failure chronology was shortened to its retained summary and repair categories. All 18 candidate mappings remain present exactly once in the integration table. Performance sample limits, measured costs, strict startup refusal and valid UTF-8/Windows/POSIX limits remain intact. The report describes simulated release publication and exception injection without claiming live publication or Windows signal-delivery coverage.

verification-update-checks.json records the mapping count, both preservation snapshots, pending status and final report digest. The report has no trailing whitespace. Root owns the eventual acceptance update after the active runs finish.
