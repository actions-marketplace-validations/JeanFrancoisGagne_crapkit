# Final implementation report audit

Updated only the root report's `implementation.md` and `collect-evidence.py` under `docs/architecture/2026-09-06-improvements/`. No commit, source/test/config change, benchmark, full suite or live archive capture ran.

## Report corrections

- Retained the explicit pending verdict for the final clean-wheel pair at frozen source `9e08454`. No current-run success or count was inferred from progress.
- Added the exact first-attempt baseline/candidate per-suite pass, failure and skip counts from `final-ci/summary.json`. Distinguished missing YAML/Pillow, POSIX and opt-in strict timing skips.
- Recorded 87 passing focused release destination checks, their simulated publication boundary and real disposable local Git operations.
- Qualified output isolation as the direct runner's default. Explicit --output remains caller-owned replacement.
- Recorded analysis sample sizes, the one-pair schedule sample and the 20-pair owner-cost probe. Kept the unique-input cost and unchanged large-reader memory visible.
- Added both minimum-above-floor startup figures and the mixed path/bytecode control limit. The strict budget remains unmet and unchanged.
- Kept valid UTF-8 and Windows/POSIX path limits explicit. Added the retained Git-proof, cooperating-writer and single-release-stage limits from completed handoffs.

## Collector corrections

The former recursive selection admitted a private lock-test virtual environment, disposable Git test repositories and any checkout placed inside a CI attempt. It omitted later root repair logs, the CONTRIBUTING correction note and final import receipts.

Selection now uses named top-level evidence groups and explicit retained subdirectories. It preserves the exact compared startup Python inputs, per-attempt verdicts, source/install proof files, JUnit, SQLite and coverage data. It also preserves nested incomplete suite data from failed attempts. Empty measurement lock files are omitted. No complete checkout or virtual environment is selected.

Added `summarize-ci.py` and both final-ci groups' derived summary files. Added later fixture/configuration logs, the CONTRIBUTING correction evidence and the collector's own checks. Final import selection admits only top-level helper scripts, Markdown, receipts/audit JSON, logs/text and SQLite/DB backup files under `self-final`; nested helper-check environments and unrelated wheel files are excluded.

## Checks

`collector-red.txt` records the original missing evidence and extra scratch files. `collector-green.txt` records a disposable archive with 14 required files retained, seven forbidden inputs excluded and every manifest digest/size checked against its archived bytes. The check makes no requests and does not read active measurement artifacts.

`collector-selection.json` records an inventory of the real selected paths at audit time. All 19 non-lock files from the failed first CI attempt were retained, including incomplete coverage data. The compared startup inputs include 64 baseline and 69 candidate Python files. The difference is in modules outside the seven identical imported startup modules and the entry file.

The selection inventory is a checkpoint, not a final archive manifest. New final-run records will appear when root completes the run and regenerates the archive. The collector's three functions have CCN 4, 2 and 1. The edited report/helper have no trailing whitespace. Workspace replay evidence stays in `work/implementation/report-evidence/`.

## Reviewed evidence

Read the completed analysis, execution, read-side, finite-number, state, release, destination, startup, nested-coverage and contamination notes. Checked the raw paired analysis figures, schedule sample, ownership-cost sample and first-CI summary. Historical red notes remain unchanged and are paired with their later green notes or logs. Root owns final artifact import and ledger verification.
