"""Check archived evidence hashes and required final acceptance records."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile


def check(archive, work):
    with zipfile.ZipFile(archive) as bundle:
        names = bundle.namelist()
        assert len(names) == len(set(names)), "Duplicate ZIP names"
        manifest = json.loads(bundle.read("manifest.json"))
        paths = [entry["path"] for entry in manifest]
        assert len(paths) == len(set(paths)), "Duplicate manifest paths"
        assert set(names) == set(paths) | {"manifest.json"}
        for entry in manifest:
            data = bundle.read(entry["path"])
            assert len(data) == entry["bytes"], entry["path"]
            assert hashlib.sha256(data).hexdigest() == entry["sha256"], entry["path"]
            assert data == (work / entry["path"]).read_bytes(), entry["path"]
        required = {
            "self-final/verify.json", "self-final/configured-audit.json",
            "self-final/independent-acceptance.json", "self-final/configured-after.sqlite",
            "self-refused/refused-audit.json", "configured-runtime/source-mode-proof.json",
            "state-evidence/review/wheel-contract/acceptance-802257c-source-check.json",
            "state-evidence/review/wheel-contract/acceptance-802257c.json",
            "state-evidence/review/wheel-contract/acceptance-802257c-base.whl",
            "state-evidence/review/wheel-contract/acceptance-802257c-candidate.whl",
            "state-evidence/review/wheel-contract/acceptance-802257c-wheel-artifacts.json",
            "state-evidence/review/wheel-contract/ratchet-merge-measured.txt",
            "evidence-execution-rerun/final-cancellation/function-coverage.json",
            "final-ci-complete/attempt-8975pq86/verdict.json",
            "final-ci-complete/attempt-yi62o7o2/verdict.json",
            "final-ci-complete/attempt-yi62o7o2/summary.json",
        }
        for side in ("base", "candidate"):
            prefix = f"final-ci-complete/attempt-yi62o7o2/{side}"
            required.add(f"{prefix}/crap.sqlite")
            required.update(f"{prefix}/cov/{name}" for name in
                            ("unit.xml", "e2e.xml", "junit.xml", "py.json", "unit.coverage", "e2e.coverage"))
        assert required <= set(paths), sorted(required - set(paths))
        excluded = {"venv", "site-packages", "clone", ".git", "__pycache__"}
        assert not [path for path in paths if set(Path(path).parts) & excluded]
        assert not any(path.endswith(("admit_ci_artifacts.py", "test_artifact_import.py", "IMPORTER-DRAFT.md")) for path in paths)
    return {"files": len(manifest), "uncompressed_bytes": sum(entry["bytes"] for entry in manifest),
            "archive_bytes": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
            "required_inputs": len(required), "hashes_and_source_bytes_match": True}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--work", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(check(args.archive, args.work), indent=2))
