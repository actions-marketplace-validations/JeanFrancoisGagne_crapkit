# Final evidence selection audit

No selector gap was found for the requested evidence. The collector selected
588 existing files, all unique, at this inspection. No archive was built.
`collector-final-selection.json` records the selected paths and the retained
run-76 artifact hashes. Later audit outputs and completed CI files will increase
the count.

## Required delivery follow-up

The fresh `final-ci-complete/attempt-yi62o7o2` directory is still empty while its
wheel pair runs. Every expected verdict, base/candidate ledger, coverage JSON,
JUnit report and raw suite coverage file matches the current selection patterns.
Its absence now is pending evidence, not an exclusion.

Before building the archive, wait for that attempt's own completed verdict and
final audit. Confirm its candidate is `802257c8796070f6a6be72e99cf284f6afd13362`.
Regenerate `final-ci-complete/summary.json` afterward: it currently describes the
refused `9e08454` attempt. The collector includes that summary unchanged and has
no completion check of its own. The final report must also replace its pending
configured-run wording with the now-proved run 76 result.

The existing summary command supports the needed update:

```powershell
$env:PYTHONPATH = 'C:/Users/jfgag/crapkit/src'
python -B work/implementation/summarize-ci.py work/implementation/final-ci-complete/verdict.json --output work/implementation/final-ci-complete/summary.json
```

This command was inspected, not executed. The older attempt's own verdict and
its refused audit remain selected after the summary is updated.

## Confirmed selection

| Evidence | Selected inputs and checks |
|---|---|
| Configured passing run 76 | `self-final/verify.json`, both ledger backups, before-input/run hashes, configured and independent audits, source environment, measurement stamp, full log, unit/e2e/combined XML, coverage JSON and both raw coverage files |
| Run 76 artifact binding | Read retained `configured-after.sqlite` in SQLite read-only mode. Run 76 is `verify`, `verdict_ok=1`, `findings=0`, at `802257c`. Both stored lane hashes equal the retained raw coverage/JUnit hashes. Run 72 remains present |
| Prior configured refusal | All 19 top-level `self-refused` files, including run 73/74 results, artifacts, old environment, preservation audit and ledger backups |
| Prior wheel attempts | Both `attempt-rrbo3jsq` and `attempt-8975pq86`, their own verdicts, ledgers, JUnit, coverage and any retained incomplete-suite data |
| Runtime and source proof | All 14 top-level `configured-runtime` files, including the actual wheel, dependency/install records, source-mode proof, full package hashes and CRLF diagnostics. The frozen clone and venv are excluded |
| Fresh wheel source proof | `acceptance-802257c-installed-proof.json`, `acceptance-802257c-source-check.json`, capture/audit helpers and future top-level acceptance outputs in `state-evidence/review/wheel-contract` |
| Ratchet merge test repair | Refused gate evidence, four-case admission proof, installed-wheel check, coverage JSON, measured score, active-hook commit log and follow-up note in `wheel-contract` |
| Cancellation and ownership test repair | All 15 top-level files in `evidence-execution-rerun/final-cancellation`, including original failure, deliberate-mutation failures, passing coverage, CRAP result, contended failures, quiet recheck and commit/hook logs |
| Final command sequence | `run-final-verification.ps1`, `final-ci-complete.log`, `summarize-ci.py` and collector/report audit files |

The selected independent configured audit reports 3,644 unit passes and 759 CLI
passes, with three skips. It records both repaired functions at coverage 1.0,
CCN 6 and CRAP 6. The preservation audit records 74 prior run rows and 739 tracked
inputs unchanged. These are configured-run facts; the fresh wheel verdict remains
pending.

## Exclusions and archive limits

The three unused importer drafts are explicitly excluded. No selected path
contains a venv, site-packages, clone, `.git`, `__pycache__`, lock-test environment
or the disposable package with cancellation cleanup removed. Runtime wheels are
intentional proof artifacts, not accidental environment copies.

The collector keeps historical failure evidence with its original result. The
old `wheel-contract/final-acceptance.md` documents a refusal despite its filename;
the new acceptance output must remain clearly tied to `802257c`.

| Collector source | Rule checked |
|---|---|
| `collect-evidence.py:11` | Top-level evidence groups include refused runs and configured-runtime proofs |
| `collect-evidence.py:15` | Nested proof folders include both test-only repair groups |
| `collect-evidence.py:18` | Retained CI patterns cover both revisions and incomplete suite data |
| `collect-evidence.py:20` | Configured-run patterns include SQLite, XML and raw coverage |
| `collect-evidence.py:21` | Explicit unused-importer exclusions |
| `collect-evidence.py:47` | Enumeration filters to files and applies the exclusions |
| `collect-evidence.py:54` | Archive reads current bytes and hashes them without asserting attempt completion |

No tracked files, root data or test state were changed. No tests or archive build
were run. Reads of configured verification state used retained copies only.
