"""Check the report collector against disposable retained and scratch inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import tempfile
import zipfile

ALLOWED = (
    'evidence-execution-rerun/completion.md',
    'evidence-advisory-startup/source-A/src/crapkit/__init__.py',
    'evidence-advisory-startup/source-B/src/crapkit/__init__.py',
    'evidence-advisory-startup/path-control/results.json',
    'state-evidence/review/RT5-isolation.md',
    'state-evidence/review/wheel-contract/notes.md',
    'state-evidence/review/wheel-contract/clean-wheel-green.txt',
    'final-ci/attempt-case/verdict.json',
    'final-ci/attempt-case/candidate/crap.sqlite',
    'final-ci/attempt-case/candidate/cov/.coverage',
    'final-ci/attempt-case/candidate/cov/junit.xml',
    'final-ci/attempt-case/candidate/cov/incomplete/suites-case/.coverage',
    'final-ci/attempt-case/candidate/proof.json',
    'self-final/configured-before.json',
    'self-final/configured_audit.py',
    'self-final/configured-before.sqlite',
    'self-final/junit.xml',
    'self-final/unit.coverage',
    'self-final/.coverage',
    'pytest-config-red.log',
    'contributing-doc-fix/notes.md',
)
FORBIDDEN = (
    'evidence-execution-rerun/lock-venv/Lib/site-packages/huge.py',
    'evidence-execution-rerun/read-side-red-fixtures/project/.git/config',
    'final-ci/attempt-case/checkout/src/crapkit/__init__.py',
    'final-ci/attempt-case/venv/Lib/site-packages/huge.py',
    'evidence-advisory-startup/source-A/src/crapkit/__pycache__/ignored.pyc',
    'self-final/disposable-venv/Lib/site-packages/huge.py',
    'self-final/accidental.whl',
    'self-final/admit_ci_artifacts.py',
    'self-final/test_artifact_import.py',
    'self-final/IMPORTER-DRAFT.md',
)


def check(collector, directory):
    work = directory / 'work'
    for name in (*ALLOWED, *FORBIDDEN):
        path = work / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(name.encode())
    output = directory / 'evidence.zip'
    collector['archive'](work, output)
    with zipfile.ZipFile(output) as bundle:
        names = set(bundle.namelist()) - {'manifest.json'}
        assert names == set(ALLOWED), {'missing': sorted(set(ALLOWED) - names), 'extra': sorted(names - set(ALLOWED))}
        manifest = json.loads(bundle.read('manifest.json'))
        for row in manifest:
            raw = bundle.read(row['path'])
            assert row['bytes'] == len(raw) and row['sha256'] == hashlib.sha256(raw).hexdigest()
    return {'retained': len(names), 'excluded': len(FORBIDDEN), 'manifest_hashes_match': True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    root = parser.parse_args().repo.resolve()
    import crapkit
    assert Path(crapkit.__file__).resolve() == root / 'src/crapkit/__init__.py'
    collector = runpy.run_path(str(root / 'docs/architecture/2026-09-06-improvements/collect-evidence.py'))
    with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
        print(json.dumps(check(collector, Path(directory)), indent=2))


if __name__ == '__main__':
    main()
