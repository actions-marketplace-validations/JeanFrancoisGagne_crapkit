# RT3 completion

RT3 keeps the existing stage CLI and guards, and makes stage2b resume from checked artifact bytes and current publication responses. The source changes are limited to `tools/release/release.py`, its README, and release tests. AN1 through AN4 have a separate commit and evidence directory.

## What changed

- Build one wheel and one source archive under `.crapkit/release-dist/` before pushing. Hash them before and after `twine check`; a change during the check refuses. Store the filenames and digests in the existing receipt. A retry verifies and reuses that pair.
- Record an action as pending before sending it. Read back after success or failure. Confirmed files are skipped on retry. Missing files are uploaded individually; mismatched bytes are never overwritten. An unknown prior result stays pending and blocks another attempt.
- Confirm the first push only when remote main and tag both equal the release HEAD. Record that proof. Later retries retain the exact tag check while allowing normal main advancement.
- Read PyPI's version-specific filename/digest list. Read GitHub asset digests, or download and hash older assets without a digest. Malformed metadata and read failures refuse uploads.
- Check Pages commit and status. Queued/building waits, built completes, and errored at the exact commit permits one fresh request on the next invocation.
- Document manual recovery for a provider-confirmed absent upload. A 404 or timeout alone never clears pending state. Registry stays separate; Glama sync stays manual.
- Remove the retired @remove-dist and ordinary dist/* execution branches, and the duplicate notes-writing branch. The current artifact path retains literal argv and redirected-directory tests. Close the disposable test ledger connection explicitly.

## Evidence

| Replay | Result |
|---|---|
| `build-red.txt` -> `build-green.txt` | A failed check used to follow a push. It now stops before any push. |
| `resume-red.txt` -> `publication-matrix.txt` | A retry repeated push and upload. Each confirmed publication now occurs once. |
| `pages-retry-red.txt` -> `pages-retry-green.txt` | A known failed build used to remain blocked as unknown. Its exact failed result now permits a fresh request. |
| `http-red.txt` -> `final-focused-release.txt` | An object in place of the PyPI file list was treated as empty. Admission now refuses it before uploading. |
| `main-advance-red.txt` -> `final-focused-release.txt` | A later ordinary main commit blocked retry. Recorded push proof plus exact remote tag permits it. |
| `artifact-check-red.txt` -> `final-focused-release.txt` | A replacement during twine check was accepted. Before/after digest equality now refuses it. |
| `tag-proof.txt` | A conflicting remote tag refuses before push or uploads. |
| `real-build-final.txt` | Actual installed build and Twine tools built and checked a disposable package offline. Its second stage2b invocation issued no further commands. |

The focused release suite passed 72 tests in 56.167 seconds, then the independent remote-tag case passed. JUnit records are `junit.xml` and `tag-junit.xml`. `_prepare_artifacts`, `_publish_action`, `_publish_files`, `_publish_pages`, `_pushed`, and `_remote_json` have 100% measured statements and branches after the tag check. See `critical-function-coverage.json`. All 86 functions in the release tool and all three functions in the real-build replay are at CCN 6 or below.

The real-build replay used `--no-isolation` to use installed dependencies without network access. It inspected the produced wheel metadata and confirmed both digests. Publication commands used in-memory adapters; Git writes used disposable local bare repositories. No live package upload, GitHub write, root tag, push, version bump or release occurred. Root owns full integration verification.

Replay from the analysis checkout with PYTHONPATH set to its src directory:

```
python -m pytest tests/unit/test_release_recovery.py tests/unit/test_release_guards.py tests/unit/test_release_tool.py tests/unit/test_release_repo_root.py -n 4 -p no:randomly
python ../evidence-release-rerun/real-build.py --repo .
```

## Costs and limits

A normal release now performs per-file readbacks and digest checks, and sends each archive separately. This costs more small API calls and local hashes. After partial failure it builds zero additional archives and sends zero commands for already confirmed files. These are measured command counts, not a latency claim.

The receipt and artifact directory must stay together. Missing or changed confirmed local bytes require restoring the original pair. Unknown requests need provider confirmation before the documented manual receipt repair. Only one release stage should run per checkout. Registry device flow and Glama remain outside automatic stage2b recovery. The readbacks cover the recorded wheel and source archive, not unrelated remote assets.

The initial `real-build.txt` preserves a successful build followed by disposable fixture cleanup failure due to an open SQLite connection. The paired `real-build-final.txt` closes cleanly. The test ledger helper now closes its connection explicitly.

Commit: `db6906f`. Actual hooks ran; working tree and diff checks are clean.
