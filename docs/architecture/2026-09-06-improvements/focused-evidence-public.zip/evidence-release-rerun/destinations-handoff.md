# RT3 destination repair handoff

Completed in commit `db14f89` on `architecture/analysis-fixes-20260906`. Root owns integration and full verification. This repair changed only `tools/release/release.py`, `tools/release/README.md`, `tests/unit/test_release_recovery.py` and the new `tests/unit/test_release_destinations.py`.

## Defect and repair

Release recovery read PyPI and the canonical GitHub repository, but upload commands inherited their destination from Twine and gh configuration. A successful write to another destination left canonical readback empty and the action pending. Git also allowed a different push URL from the origin used for readback.

The repair passes PyPI's upload URL, gh's repository and Pages hostname explicitly. The printed plan and uploads share their command prefixes. Before publication, Git's resolved fetch and push URLs must each identify `github.com/JeanFrancoisGagne/crapkit`. Multiple destinations and URL rewrites to another repository refuse before any command. HTTPS, scp-style SSH and ssh://git@github.com URLs remain supported. Host aliases refuse with a message naming the required repository. The admitted Git transport remains in use.

The focused public-stage tests first failed for all three redirected services and for foreign fetch, push and multiple-push destinations. Green checks cover these paths, resolved insteadOf/pushInsteadOf rewrites, accepted HTTPS/SSH forms, the printed plan and the final verify readback.

## Verification

Exactly **87 focused tests passed**, with zero failures, errors or skips:

| Evidence | Tests | Result |
|---|---:|---|
| `destinations-junit.xml` | 85 | Release tool, guards, recovery and destination cases passed |
| `destinations-extra-junit.xml` | 2 | Explicit repository verification and canonical gh readback passed |

`destinations-red.txt` records four initial failures. `destinations-git-red.txt` records three destination-admission failures. `destinations-focused.txt` and `destinations-extra.txt` are the paired green logs. The early `destinations-green.txt` records the first 11 destination cases before the two rewrite cases and final verify case were added.

`destinations-coverage.json` and `destinations-checks.json` record complete line and branch coverage for the new origin guard, shared upload prefix, upload loop and printed plan. This is not a claim of complete release-module coverage. `destinations-complexity.json` records all 88 release functions at CCN 6 or below. `destinations-commit.txt` records the commit with configured `git-hooks` active; the staged diff check passed. No hook was bypassed.

Replay from the analysis checkout, with PYTHONPATH set to that checkout's src and COVERAGE_FILE pointing outside any root measurement artifacts:

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:COVERAGE_FILE = [IO.Path]::GetFullPath('../evidence-release-rerun/.coverage-destinations-replay')
python -c "import pathlib, crapkit, pytest; assert pathlib.Path(crapkit.__file__).resolve() == pathlib.Path.cwd() / 'src/crapkit/__init__.py'; raise SystemExit(pytest.main(['-q', '-n', '0', '-p', 'no:randomly', 'tests/unit/test_release_tool.py', 'tests/unit/test_release_guards.py', 'tests/unit/test_release_recovery.py', 'tests/unit/test_release_repo_root.py', 'tests/unit/test_release_destinations.py']))"
```

The original coverage command used the isolated checkout's default coverage file after a PowerShell path expression failed. Its coverage JSON was written to this evidence directory. Root's coverage data and configured artifacts were untouched. The replay command above sets an explicit evidence path.

## Offline provenance and limits

Tests created disposable working repositories and local bare origins. Git commits, local tags, ref reads and pushes were real operations against those fixtures. The publication adapter supplied the canonical repository identity for admission while keeping actual Git transport inside the local fixtures. Wrong-origin tests used real Git URL configuration and blocked all release commands before any network-capable operation.

Twine, gh, plugin and Pages publication commands were simulated. Canonical API responses were in memory, and the redirected-service adapter left those responses empty after accepting a write at another simulated destination. `destinations-twine-parser.txt` separately confirms that the installed Twine argument parser honors the explicit upload URL over an inherited alternate URL, without making a request. No PyPI upload, GitHub write, real release tag, root push or external publication occurred.

The earlier `real-build-final.txt` remains the evidence for installed build and Twine-check tools producing real disposable archives. It predates this destination repair; this repair did not rerun that build or claim a new one. Unknown-outcome refusal, receipt digests and partial retry behavior remain covered by the complete offline recovery matrix. One release stage per checkout remains the documented operational limit.

The CLI destination contracts are documented by [gh environment variables](https://cli.github.com/manual/gh_help_environment), [gh release repository selection](https://cli.github.com/manual/gh_release_create) and [Twine options](https://twine.readthedocs.io/en/stable/).

## Final AN and startup report checks

The bounded integrated AN1-AN4/RT3 review found this destination defect and no other unclosed AN issue. The analysis measurements in `implementation.md` match the raw evidence:

| Synthetic workload | Baseline seconds | Final seconds | Retained qualification |
|---|---:|---:|---|
| 12 identical files | 0.1498732 | 0.0168458 | Parser calls fall from 12 to 1; full results equal |
| 12 unique files | 0.1262866 | 0.1450189 | Digest verification adds 0.0187323 seconds |
| 16,777,460-byte coverage artifact | 0.4919352 | 0.3718218 | Output equal; traced peak stays about 43.3 MB |
| 5,000 small members | 0.0823952 | 0.0782893 | Output equal; traced peak stays about 4.66 MB |

These are warm medians from five samples after the first sample, with alternating baseline/candidate blocks on a host running other work. Tracemalloc is not process RSS. The small-member 4 ms difference does not establish a general speedup. No benchmark was rerun for this destination repair.

The Git path claim applies to valid UTF-8. Windows fixtures exercised leading whitespace, non-ASCII names and U+2028. Filesystem cases requiring tab, newline, carriage return, trailing space or a literal backslash name run only on POSIX and were not executed on this Windows host.

The strict opt-in no-toml startup budget remains unmet on this host. In 50 paired comparisons, baseline/current minimum-above-Python-floor times were 53.5486/49.2894 ms against 40 ms. Seven imported project modules and the entry file were byte-identical. Median paired change was -0.0812 ms, with a paired bootstrap 95% interval from -4.5083 to +6.0484 ms. This does not show a code regression. The separate 15-pair identical-source control combined path and bytecode-cache differences; its +11.1209 ms paired result is not a pure path estimate. No budget changed. Root reports ordinary hard budgets and full verification separately.

Exact raw measurements and source hashes remain in `../evidence-analysis-rerun/paired-final.json` and `../evidence-advisory-startup/`. `../evidence-analysis-rerun/final-integrated-review.md` records the reviewed module scope and the limits retained by AN1-AN4.
