"""Build and check a disposable release pair with installed build tools, offline."""
import argparse
import gc
import json
import pathlib
import sys
import tempfile
import zipfile


def main():
    args = argparse.ArgumentParser()
    args.add_argument('--repo', type=pathlib.Path, required=True)
    root = args.parse_args().repo.resolve()
    import crapkit
    assert pathlib.Path(crapkit.__file__).resolve() == root / 'src/crapkit/__init__.py'
    sys.path.insert(0, str(root / 'tests/unit'))
    import pytest
    from test_release_guards import repo, git, verified
    from test_release_recovery import publish_adapter
    from test_release_tool import release
    with tempfile.TemporaryDirectory() as directory, pytest.MonkeyPatch.context() as patch:
        target = repo(pathlib.Path(directory), bumped=True)
        (target / '.gitignore').write_text('.crapkit/\ndist/\nbuild/\n*.egg-info/\n')
        git(target, 'add', '.gitignore')
        git(target, 'commit', '-qm', 'ignore build products')
        verified(target, patch)
        adapter = publish_adapter(target, patch)
        run_local_build(target, release, adapter, patch)
        files = target / '.crapkit/release-dist'
        wheel = next(files.glob('*.whl'))
        with zipfile.ZipFile(wheel) as archive:
            metadata = archive.read('crapkit-0.5.2.dist-info/METADATA').decode()
        assert 'Name: crapkit' in metadata and 'Version: 0.5.2' in metadata
        print(json.dumps({'artifacts': json.loads((target / '.crapkit/release-receipt.json').read_text())['artifacts'],
                          'events': adapter.events, 'real_build_and_twine_check': True}, indent=2))
        gc.collect()


def run_local_build(target, release, adapter, patch):
    import subprocess
    def execute(command, root, dry_run):
        if 'build' in command or 'check' in command:
            words = [*command, *(['--no-isolation'] if 'build' in command else [])]
            subprocess.run(release._arguments(tuple(words), root), cwd=root, check=True)
            adapter.events.append('build' if 'build' in command else 'check')
        else:
            adapter.execute(command, root, dry_run)
    patch.setattr(release, '_execute', execute)
    release.run('stage2b', '0.5.2', target)
    before = list(adapter.events)
    release.run('stage2b', '0.5.2', target)
    assert adapter.events == before


if __name__ == '__main__':
    main()

