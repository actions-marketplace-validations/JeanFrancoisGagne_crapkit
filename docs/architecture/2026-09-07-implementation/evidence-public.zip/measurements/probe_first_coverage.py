"""Read the preserved first wheel measurement without opening a writable store."""
import ast
import json
import sqlite3
import subprocess
from pathlib import Path

from crapkit.ratchet import load_ratchet

R = Path(__file__).parent.parent
REPO = Path("C:/Users/jfgag/crapkit")
COMMIT = "e99403f9865a0c6b5fece928696a0afa029e91ea"
WHEEL = R / "wheels/attempt-t3vh2liu"


def source(path, commit=COMMIT):
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=REPO).decode("utf-8")


def function_at(path, line):
    body = source(path)
    matches = [node for node in ast.walk(ast.parse(body))
               if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
               and node.lineno <= line <= node.end_lineno]
    node = min(matches, key=lambda item: item.end_lineno - item.lineno)
    lines = body.splitlines()
    return {"name": node.name, "start": node.lineno, "end": node.end_lineno,
            "source": "\n".join(f"{i}: {lines[i-1]}" for i in range(node.lineno, node.end_lineno + 1))}


database = WHEEL / "candidate/crap.sqlite"
db = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)
db.row_factory = sqlite3.Row
proof = {"commit": COMMIT, "sqlite": str(database), "mode": "read-only",
         "runs": [dict(row) for row in db.execute("select id, commit_sha, kind, verdict_ok, findings from runs")]}
rows = [dict(row) for row in db.execute(
    "select i.path, i.long_name, f.start, f.end, f.ccn, f.crap, f.cov from functions f join identities i on i.id=f.identity_id where run_id=2 and crap>6 order by crap desc")]
marks = {(row.path, row.long_name) for row in load_ratchet(source("crapkit-ratchet.tsv"))}
base_db = sqlite3.connect((WHEEL / "base/crap.sqlite").as_uri() + "?mode=ro", uri=True)
windows_db = sqlite3.connect((R / "source-attempt1/crap.sqlite").as_uri() + "?mode=ro", uri=True)
base_db.row_factory = windows_db.row_factory = sqlite3.Row
query = "select f.start, f.end, f.ccn, f.cov, f.crap from functions f join identities i on i.id=f.identity_id where f.run_id=? and i.path=? and i.long_name=?"
for row in rows:
    row["has_ratchet_mark"] = (row["path"], row["long_name"]) in marks
    row["base_linux"] = dict(base_db.execute(query, (1, row["path"], row["long_name"])).fetchone())
    row["first_windows"] = dict(windows_db.execute(query, (78, row["path"], row["long_name"])).fetchone())
    fn_name = row["long_name"].split("(")[0]
    old_fn = next(node for node in ast.walk(ast.parse(source(row["path"], "c2d3515")))
                  if isinstance(node, ast.FunctionDef) and node.name == fn_name)
    new_fn = next(node for node in ast.walk(ast.parse(source(row["path"])))
                  if isinstance(node, ast.FunctionDef) and node.name == fn_name)
    row["function_ast_unchanged_from_base"] = ast.dump(old_fn) == ast.dump(new_fn)
proof["over_target_rows"] = rows
verdict = json.loads((WHEEL / "verdict.json").read_text())["verdict"]
coverage = json.loads((WHEEL / "candidate/cov/py.json").read_text())
windows_coverage = json.loads((R / "source-attempt1/py.json").read_text())
proof["uncovered"] = []
for item in verdict["diff_uncovered"]:
    path, line = item["path"], item["line"]
    match = next((key for key in coverage["files"] if key.endswith(path)), None)
    file = coverage["files"].get(match, {})
    windows_key = next((key for key in windows_coverage["files"] if key.replace("\\", "/").endswith(path)), None)
    detail = {**item, "function": function_at(path, line), "coverage_path": match,
              "recorded_missing": line in file.get("missing_lines", []),
              "executed_on_first_windows": line in windows_coverage["files"].get(windows_key, {}).get("executed_lines", []),
              "missing_branches": file.get("missing_branches", [])}
    proof["uncovered"].append(detail)
proof["windows_only_uncovered"] = [item for item in json.loads((R / "full-source-verdict.json").read_text())["diff_uncovered"]
                                     if item not in verdict["diff_uncovered"]]
for row in rows:
    for host, report in (("linux", coverage), ("windows", windows_coverage)):
        key = next(key for key in report["files"] if key.replace("\\", "/").endswith(row["path"]))
        row[host + "_missing_lines"] = [line for line in report["files"][key]["missing_lines"]
                                       if row["start"] <= line <= row["end"]]
(R / "measurements/first-coverage-facts.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
print(json.dumps(proof, indent=2))
db.close()
base_db.close()
windows_db.close()
