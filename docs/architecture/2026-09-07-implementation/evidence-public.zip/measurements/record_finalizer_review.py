"""Record the packaging repair and the current incomplete Windows attempt."""
import difflib
import hashlib
import json
from pathlib import Path

import lizard

ROOT = Path(__file__).resolve().parents[1]
REPO = Path("C:/Users/jfgag/crapkit")
HERE = ROOT / "measurements/manifest-finalizer"


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


before = (HERE / "before.py").read_text(encoding="utf-8")
after = (ROOT / "finalize_evidence.py").read_text(encoding="utf-8")
(HERE / "finalizer-admission.patch").write_text("".join(difflib.unified_diff(
    before.splitlines(keepends=True), after.splitlines(keepends=True),
    fromfile="a/finalize_evidence.py", tofile="b/finalize_evidence.py")), encoding="utf-8")
red = read("measurements/manifest-finalizer/red.json")
green = read("measurements/manifest-finalizer/green.json")
assert red["failed"] == 15 and red["passed"] == 2
assert green["failed"] == 0 and green["passed"] == 17
assert all(not row["output_created"] for row in green["cases"] if not row["expected_accept"])
complexity = {item.name: dict(line=item.start_line, ccn=item.cyclomatic_complexity)
              for item in lizard.analyze_file(str(ROOT / "finalize_evidence.py")).function_list}
assert max(item["ccn"] for item in complexity.values()) <= 6
receipt = dict(
    status="closed; scratch packaging admission repaired", source="finalize_evidence.py",
    problem="Successful source/wheel validation could package a stale manifest commit or an incomplete completion matrix because package() checked only listed file hashes.",
    fix="Before creating output, require one measured commit across manifest, matrix and final verification. Require all 17 audited candidates plus the CI row implemented and passing on both platforms. Reject duplicate or omitted rows. Preserve the independent source Git-blob and saved-verdict validation.",
    evidence=dict(red="measurements/manifest-finalizer/red.json", green="measurements/manifest-finalizer/green.json",
                  replay="measurements/probe_finalizer_metadata.py", before="measurements/manifest-finalizer/before.py",
                  patch="measurements/manifest-finalizer/finalizer-admission.patch"),
    outcomes=dict(red="15 invalid metadata cases accepted; two valid controls accepted", green="17 expected outcomes pass; all 15 refusals happen before output creation"),
    finalizer_sha256=digest(ROOT / "finalize_evidence.py"), before_sha256=digest(HERE / "before.py"),
    complexity=complexity,
    replay=["python measurements/probe_finalizer_metadata.py red.json measurements/manifest-finalizer/before.py",
            "python measurements/probe_finalizer_metadata.py green.json"],
    compatibility=["Measured source and wheel commits must match each other. A later documentation commit and the earlier production-byte lineage may differ; both are accepted by the positive control.",
                   "Completion rows now carry an explicit implemented boolean. The current rows are implemented but their final complete-suite status remains pending.",
                   "Full validation still checks exact canonical Git source bytes, clean package source, source verdict/exit, candidate wheel verdict/exit, ratchet hash and source ledger agreement."],
    limits=["The probe uses private synthetic metadata at the real package() seam. It does not claim a complete source/wheel run or exercise Git/process behavior.",
            "Actual packaging remains refused until a complete Windows pass and final matrix/manifest update exist.",
            "No main repository source, test, deadline, baseline or ratchet was edited."])
save("measurements/manifest-finalizer/result.json", receipt)

matrix = read("completion-matrix.json")
for row in matrix["candidates"] + matrix["extra_work"]:
    row["implemented"] = True
windows = matrix["integration_verification"]["windows_full_source_verify"]
windows["note"] = "72b Windows unit suite completed with two failures; E2E is still running. Do not finalize this candidate. Linux passed at the same commit."
windows["current_progress"] = dict(
    commit=matrix["implementation_commit"], status="unit suite failed; E2E pending",
    source="Root's completed unit-phase receipt; final copied artifacts and ledger are not yet available.",
    unit=dict(passed=3906, failed=2, skipped=3, seconds=588.17),
    symptoms=["No-progress cleanup case missed its first startup marker.",
              "The chatty-command case raised NoProgress with interval 1."],
    repair="Isolated test repair is in progress with independent execution review; main remains frozen.")
matrix["integration_verification"]["final_artifacts"]["note"] = "72b Linux passed; Windows has two unit failures and E2E remains active. Packaging stays pending. Production bytes equal 0082379."
matrix["finalizer_review"] = dict(status=receipt["status"], evidence="measurements/manifest-finalizer/result.json")
save("completion-matrix.json", matrix)

review = read("integration-review.json")
review["status"] = "Implementation and packaging review complete; current Windows no-progress fixture repair and full verification remain pending."
closed = [
    dict(problem="Binary source attributes could hide source hunks and advisory reads did not share the owned patch protocol",
         fix="Use exact binary metadata and literal supported-source fallback at the shared Git source-patch boundary; preserve ordinary binary handling and lossless admitted source bodies",
         evidence=["measurements/git-followup-result.json", "git-source-posix.xml"]),
    dict(problem="Historical patch framing could collide with control bytes in paths and record fields",
         fix="Recognize owned Git history headers at record boundaries while retaining codec-produced field bytes and leading-hash paths",
         evidence=["measurements/git-followup-result.json", "history-green.txt"]),
    dict(problem="Public packet commands required final Windows and POSIX shell admission",
         fix="Completed the packet formatter and real launcher checks, including literal percent/backslash/LF names and exit status",
         evidence=["execution/packet-result.json", "execution/packet-final-windows.xml", "execution/packet-final-posix.xml"]),
    dict(problem="CI fixture and schedule changes required final admission and incomplete-JUnit follow-up",
         fix="Integrated worker-private fixture seeds, preserved schedule owners and complete-report checks; runner and parser reject collection and worker-crash evidence",
         evidence=["tests-ci/result.json", "tests-ci/collection-followup.json", "execution/ci-review.json", "tests-ci/miniature-workers.json"]),
    dict(problem=receipt["problem"], fix=receipt["fix"], evidence=["measurements/manifest-finalizer/result.json"]),
]
existing = {item["problem"] for item in review["findings_closed"]}
review["findings_closed"] += [item for item in closed if item["problem"] not in existing]
review["manifest_finalizer_review"] = dict(
    status="complete; metadata admission gap reproduced and closed",
    evidence="measurements/manifest-finalizer/result.json",
    sound=["Current wheel proof counts actual base failures and does not assume all attempts have the same historical failures.",
           "Exact candidate Git blobs establish installed source identity; local line endings are diagnostic only.",
           "Historical 0009 evidence moves preserve bytes and hashes, with explicit path aliases.",
           "The report distinguishes local baseline-77 Windows reproduction from the portable fresh-wheel comparison.",
           "The report keeps Linux, Windows, macOS and hosted-dispatch limits separate."])
review["current_verification"] = dict(commit=matrix["implementation_commit"], linux="passed", windows=windows["current_progress"])
review["pending"] = [
    "Finish and independently review the current Windows no-progress fixture repair. Two unit cases failed; E2E is still active.",
    "Preserve the complete Windows attempt and its ledger, then run complete source/wheel verification at the next measured candidate if a test repair is committed. Final packaging remains blocked until matching passing evidence and complete metadata exist.",
]
save("integration-review.json", review)

manifest = read("evidence-manifest.json")
refresh = {"finalize_evidence.py", "integration-review.json", "decisions.tsv"}
for entry in manifest["entries"]:
    path = REPO / entry["path"][5:] if entry["path"].startswith("repo:") else ROOT / entry["path"]
    if entry["path"] not in refresh:
        assert digest(path) == entry["sha256"], f"Preserved evidence changed: {entry['path']}"


def include(name, kind, purpose):
    path = ROOT / name
    entry = dict(path=name, candidates=["ALL"], kind=kind, purpose=purpose,
                 bytes=path.stat().st_size, sha256=digest(path))
    manifest["entries"] = [item for item in manifest["entries"] if item["path"] != name] + [entry]


include("finalize_evidence.py", "replay", "Admit matching successful source/wheel measurements and complete matching report metadata before packaging")
include("integration-review.json", "independent integration review", "Closed Git, packet, CI and packaging items; current Windows progress repair remains pending")
for name in ("red.json", "green.json", "before.py", "result.json", "finalizer-admission.patch"):
    include("measurements/manifest-finalizer/" + name, "packaging admission repair", "Synthetic package-seam red/green with exact source hashes and complexity receipt")
include("measurements/probe_finalizer_metadata.py", "replay", "Check valid metadata, stale commits and incomplete rows without full runs or repository edits")
include("measurements/record_finalizer_review.py", "replay", "Record packaging repair and current failed-unit/incomplete Windows status")
if any(item["path"] == "decisions.tsv" for item in manifest["entries"]):
    include("decisions.tsv", "decision log", "Root-owned implementation and verification chronology; refresh after later append")
manifest["integration_verification"] = "72b Linux passed; Windows has two unit failures and E2E remains active. Do not finalize this candidate. Historical attempts remain preserved."
manifest["entries"].sort(key=lambda item: item["path"])
manifest["curation"].update(file_count=len(manifest["entries"]), total_bytes=sum(item["bytes"] for item in manifest["entries"]))
save("evidence-manifest.json", manifest)
print(json.dumps(dict(packaging_probe=receipt["outcomes"], max_finalizer_ccn=max(item["ccn"] for item in complexity.values()),
                      entries=len(manifest["entries"]), bytes=manifest["curation"]["total_bytes"])))
