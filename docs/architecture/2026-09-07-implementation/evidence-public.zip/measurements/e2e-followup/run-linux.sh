#!/bin/sh
set -u
task_repo=/mnt/c/Users/jfgag/Documents/Codex/worktrees/ck-r2-measurements
task_out=/mnt/c/Users/jfgag/Documents/Codex/2026-09-06/c-users-jfgag-appdata-local-temp/work/implementation-round2/measurements/e2e-followup
export PYTHONPATH="$task_repo/src"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/tmp/ck-r2-tests-ci-runtime-20260907/venv/bin:$PATH"
cd "$task_repo" || exit 2
python -c 'import crapkit; print(crapkit.__file__)'
python -m pytest --no-cov -o addopts= -q "$@" --basetemp="/tmp/ck-r2-core-e2e-$TASK_RUN-20260907" --junitxml="$task_out/$TASK_RUN-linux.xml" > "$task_out/$TASK_RUN-linux.log" 2>&1
task_status=$?
cat "$task_out/$TASK_RUN-linux.log"
exit "$task_status"
