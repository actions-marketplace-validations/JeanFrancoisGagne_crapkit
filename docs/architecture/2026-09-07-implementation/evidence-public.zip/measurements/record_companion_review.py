"""Record standalone archive admission while final report companions remain pending."""
import difflib
import hashlib
import json
from pathlib import Path

import lizard

ROOT = Path(__file__).resolve().parents[1]
REPO = Path("C:/Users/jfgag/crapkit")
HERE = ROOT / "measurements/manifest-finalizer"


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


before = (HERE / "before-companions.py").read_text(encoding="utf-8")
after = (ROOT / "finalize_evidence.py").read_text(encoding="utf-8")
(HERE / "companions.patch").write_text("".join(difflib.unified_diff(
    before.splitlines(keepends=True), after.splitlines(keepends=True),
    fromfile="a/finalize_evidence.py", tofile="b/finalize_evidence.py")), encoding="utf-8")
red = read("measurements/manifest-finalizer/companions-red.json")
green = read("measurements/manifest-finalizer/companions-green.json")
metadata = read("measurements/manifest-finalizer/metadata-with-companions-green.json")
index = read("measurements/manifest-finalizer/index-replay.json")
assert red["failed"] == 4 and green["passed"] == 4 and green["failed"] == 0
assert metadata["passed"] == 17 and metadata["failed"] == 0
assert index["passed"] == 2
complexity = {name: {item.name: item.cyclomatic_complexity
                     for item in lizard.analyze_file(str(ROOT / name)).function_list}
              for name in ("finalize_evidence.py", "add_report_companions.py")}
assert all(ccn <= 6 for file in complexity.values() for ccn in file.values())
receipt = dict(
    status="closed; standalone archive admission repaired",
    problem="The curated entries omitted the report, matrix and decision log. The ZIP also omitted the manifest itself. An earlier statement that decisions.tsv was included was incorrect.",
    fix="Require report-draft.md, completion-matrix.json and decisions.tsv as hashed entries. Copy evidence-manifest.json into the ZIP separately, alongside verification.json, without putting the manifest in its own hash list.",
    source="finalize_evidence.py", source_sha256=digest(ROOT / "finalize_evidence.py"),
    before_sha256=digest(HERE / "before-companions.py"), complexity=complexity,
    outcomes=dict(red="Four cases fail: complete archive lacks the manifest, and each missing companion is accepted.",
                  green="Four expected outcomes pass: exact complete archive bytes and three refusals before output creation.",
                  metadata="All 17 previous metadata-admission cases pass with hashed companions.",
                  indexing="Pending metadata refuses without changing the manifest; complete metadata adds all three actual file hashes and repeats without changing bytes."),
    evidence=["measurements/manifest-finalizer/companions-red.json", "measurements/manifest-finalizer/companions-green.json",
              "measurements/manifest-finalizer/metadata-with-companions-green.json", "measurements/manifest-finalizer/index-replay.json",
              "measurements/manifest-finalizer/index-pending.json", "measurements/manifest-finalizer/companions.patch"],
    replay=["python measurements/probe_finalizer_companions.py companions-red.json measurements/manifest-finalizer/before-companions.py",
            "python measurements/probe_finalizer_companions.py companions-green.json",
            "python measurements/probe_finalizer_metadata.py metadata-with-companions-green.json",
            "python measurements/probe_companion_index.py"],
    final_index_command="python add_report_companions.py <evidence-directory> <repository>",
    final_index_precondition="Finish final report and completion metadata after matching passing source and wheel results. Then index companions and run the full finalizer.",
    limits=["Synthetic package/index probes do not establish a full-suite result.",
            "Report, matrix and decision-log entries remain intentionally absent while Windows E2E is pending. The guarded index script adds them after metadata is complete.",
            "Historical metadata-probe source and both finalizer before versions remain preserved. No main repository edit occurred."])
save("measurements/manifest-finalizer/companions-result.json", receipt)

matrix = read("completion-matrix.json")
matrix["finalizer_review"]["standalone_archive"] = "measurements/manifest-finalizer/companions-result.json"
matrix["integration_verification"]["windows_full_source_verify"]["current_progress"] = dict(
    commit=matrix["implementation_commit"], status="unit passed; E2E running",
    unit=dict(passed=3912, failed=0, skipped=3, seconds=820.06),
    source="Root's completed unit-phase receipt; final copied artifacts and saved ledger remain pending.")
save("completion-matrix.json", matrix)

integration = read("integration-review.json")
problem = receipt["problem"]
integration["findings_closed"] = [item for item in integration["findings_closed"] if item["problem"] != problem] + [dict(
    problem=problem, fix=receipt["fix"], evidence=["measurements/manifest-finalizer/companions-result.json"])]
integration["manifest_finalizer_review"]["standalone_archive"] = "measurements/manifest-finalizer/companions-result.json"
save("integration-review.json", integration)

manifest = read("evidence-manifest.json")
refresh = {"finalize_evidence.py", "integration-review.json", "measurements/probe_finalizer_metadata.py"}
for entry in manifest["entries"]:
    path = REPO / entry["path"][5:] if entry["path"].startswith("repo:") else ROOT / entry["path"]
    if entry["path"] not in refresh:
        assert digest(path) == entry["sha256"], f"Preserved evidence changed: {entry['path']}"


def include(name, kind, purpose):
    path = ROOT / name
    entry = dict(path=name, candidates=["ALL"], kind=kind, purpose=purpose,
                 bytes=path.stat().st_size, sha256=digest(path))
    manifest["entries"] = [item for item in manifest["entries"] if item["path"] != name] + [entry]


include("finalize_evidence.py", "replay", "Require complete matching metadata and report companions; archive the manifest separately without self-hashing")
include("add_report_companions.py", "replay", "Add final report, matrix and decision-log hashes only after complete metadata passes admission")
include("integration-review.json", "independent integration review", "Closed standalone archive gap; current Windows E2E and final verification remain pending")
for name in ("before-companions.py", "companions-red.json", "companions-green.json", "metadata-with-companions-green.json",
             "index-pending.json", "index-replay.json", "companions.patch", "companions-result.json", "metadata-probe-before-companions.py"):
    include("measurements/manifest-finalizer/" + name, "standalone archive evidence", "Exact ZIP contents, missing-companion refusal, preserved metadata admission and guarded indexing")
for name in ("probe_finalizer_metadata.py", "probe_finalizer_companions.py", "probe_companion_index.py", "record_companion_review.py"):
    include("measurements/" + name, "replay", "Private synthetic admission and archive probes without full runs or repository edits")
manifest["required_companions"] = ["report-draft.md", "completion-matrix.json", "decisions.tsv"]
manifest["companion_status"] = "Intentionally pending until final completion metadata is ready. Run add_report_companions.py before finalization."
manifest["entries"].sort(key=lambda item: item["path"])
manifest["curation"].update(file_count=len(manifest["entries"]), total_bytes=sum(item["bytes"] for item in manifest["entries"]))
save("evidence-manifest.json", manifest)
print(json.dumps(dict(companions_green=4, metadata_green=17, index_green=2,
                      max_finalizer_ccn=max(complexity["finalize_evidence.py"].values()),
                      max_index_ccn=max(complexity["add_report_companions.py"].values()),
                      manifest_entries=len(manifest["entries"]), manifest_bytes=manifest["curation"]["total_bytes"])))
