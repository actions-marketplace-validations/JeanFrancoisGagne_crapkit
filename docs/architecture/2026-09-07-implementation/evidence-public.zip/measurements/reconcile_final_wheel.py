"""Reconcile the completed wheel run using preserved files and read-only SQLite."""
import hashlib
import io
import json
import sqlite3
import subprocess
from pathlib import Path
import xml.etree.ElementTree as ET

from crapkit.ratchet import load_ratchet

R = Path(__file__).parent.parent
REPO = Path("C:/Users/jfgag/crapkit")


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def committed_sources(commit, names):
    requests = "".join(f"{commit}:src/crapkit/{name}\n" for name in names).encode()
    stream = io.BytesIO(subprocess.check_output(["git", "cat-file", "--batch"], input=requests, cwd=REPO))
    result = {}
    for name in names:
        _, kind, length = stream.readline().split()
        assert kind == b"blob"
        result[name] = hashlib.sha256(stream.read(int(length))).hexdigest()
        assert stream.read(1) == b"\n"
    return result


def counts(path):
    cases = ET.parse(path).findall(".//testcase")
    failed = [f"{row.get('classname')}::{row.get('name')}" for row in cases
              if row.find("failure") is not None or row.find("error") is not None]
    skipped = sum(row.find("skipped") is not None for row in cases)
    return {"tests": len(cases), "passed": len(cases) - len(failed) - skipped,
            "skipped": skipped, "failures": failed}


wheel = read(R / "wheels-final/verdict.json")
attempt = R / "wheels-final" / wheel["evidence_dir"]
verdict = wheel["verdict"]
assert wheel["phase"] == "complete" and verdict["ok"]
assert wheel["suite_exits"][1] == 0
assert (R / "full-wheels-final.exit").read_text().strip() == "0"
proof = {
    "status": "Linux wheel verification passed; Windows source verification pending",
    "candidate_commit": wheel["candidate"]["commit"],
    "base_commit": wheel["base"]["commit"],
    "verdict": "wheels-final/verdict.json", "attempt": attempt.relative_to(R).as_posix(),
    "process_exit": 0, "suite_exits": wheel["suite_exits"],
    "candidate_ok": verdict["ok"], "source_proofs": {}, "revisions": {},
}
for revision in ("base", "candidate"):
    package = wheel[revision]
    source_map = package["source_sha256"]
    package_proof = {
        "commit": package["commit"], "package": package["package"],
        "wheel_sha256": package["wheel_sha256"], "python_source_files": len(source_map),
        "source_map_sha256": hashlib.sha256(json.dumps(source_map, sort_keys=True).encode()).hexdigest(),
    }
    if revision == "candidate":
        current = {path.relative_to(REPO / "src/crapkit").as_posix(): digest(path)
                   for path in (REPO / "src/crapkit").rglob("*.py")}
        mismatches = [name for name in sorted(current.keys() | source_map.keys())
                      if current.get(name) != source_map.get(name)]
        differences = [{"path": name,
                "current": current.get(name), "wheel": source_map.get(name),
                "current_crlf": (REPO / "src/crapkit" / name).read_bytes().count(b"\r\n"),
                "lf_normalized_matches": hashlib.sha256((REPO / "src/crapkit" / name).read_bytes().replace(b"\r\n", b"\n")).hexdigest() == source_map.get(name)}
                for name in mismatches]
        assert current.keys() == source_map.keys()
        canonical = committed_sources(package["commit"], sorted(source_map))
        assert canonical == source_map, "committed Git source bytes differ from installed wheel"
        source_state = subprocess.check_output(
            ["git", "status", "--porcelain=v1", "-z", "--untracked-files=all", "--", "src/crapkit"], cwd=REPO)
        assert not source_state, "local package source is not clean"
        clean = subprocess.run(["git", "diff", "--quiet", package["commit"], "--", "src/crapkit"], cwd=REPO).returncode == 0
        assert clean, "local tracked package source differs from the measured candidate"
        package_proof.update(committed_git_blob_bytes_equal=True, current_source_names_equal=True,
                             local_tracked_source_git_diff_empty=clean,
                             local_raw_byte_mismatches=differences)
    proof["source_proofs"][revision] = package_proof
    with sqlite3.connect((attempt / revision / "crap.sqlite").as_uri() + "?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        runs = [dict(row) for row in db.execute("select id,commit_sha,kind,verdict_ok,findings from runs order by id")]
        if revision == "candidate":
            ledger = runs[-1]
            assert ledger == verdict["ledger"]
            assert ledger["commit_sha"] == wheel["candidate"]["commit"]
            assert ledger["verdict_ok"] == 1 and ledger["findings"] == 0
            rows = [dict(row) for row in db.execute(
                "select i.path,i.long_name,f.start,f.end,f.ccn,f.cov,f.crap from functions f join identities i on i.id=f.identity_id where run_id=? and crap>6 order by crap desc",
                (verdict["run_id"],))]
    measured = read(attempt / revision / "cov/py.json")
    file_keys = list(measured["files"])
    suite_results = {name: counts(attempt / revision / "cov" / f"{name}.xml") for name in ("unit", "e2e")}
    assert sum(row["tests"] for row in suite_results.values()) == verdict["tests"][revision]["tests"]
    proof["revisions"][revision] = {
        "suites": suite_results, "ledger": runs,
        "coverage_sha256": digest(attempt / revision / "cov/py.json"),
        "coverage_totals": measured["totals"], "coverage_files": len(file_keys),
        "unexpected_coverage_paths": [key for key in file_keys if not key.startswith("src/crapkit/")],
    }
    if revision == "candidate":
        assert not proof["revisions"][revision]["unexpected_coverage_paths"]
        assert all(not suite["failures"] for suite in suite_results.values())
        coverage = measured

ratchet_text = subprocess.check_output(
    ["git", "show", f"{wheel['candidate']['commit']}:crapkit-ratchet.tsv"], cwd=REPO).decode("utf-8")
marks = {(row.path, row.long_name) for row in load_ratchet(ratchet_text)}
unmarked = [row for row in rows if (row["path"], row["long_name"]) not in marks]
assert len(unmarked) == verdict["unmarked_over_target"] == 3
proof["unmarked_over_target"] = unmarked
proof["diff_uncovered"] = verdict["diff_uncovered"]
proof["diff_uncovered_max"] = verdict["diff_uncovered_max"]
proof["gate_violations"] = verdict["gate_violations"]
proof["ratchet_regressions"] = verdict["ratchet_regressions"]
proof["new_failures"] = verdict["new_failures"]
proof["ratchet_sha256"] = verdict["ratchet_sha256"]
base_failed = sum(len(suite["failures"]) for suite in proof["revisions"]["base"]["suites"].values())
proof["limits"] = [
    f"Base suite exit {wheel['suite_exits'][0]} retains {base_failed} historical failures in this attempt; the exact IDs are recorded above. Candidate unit and E2E have no failures; comparison and matching candidate ledger pass.",
    "All 71 installed source hashes equal exact Git blobs at the measured commit. Local tracked source has no Git diff. Local config.py and doctor.py use CRLF; their raw Windows bytes differ from Linux wheel bytes. Normalization is recorded as a diagnostic, not used to establish canonical identity.",
    "Coverage JSON and SQLite remain in the preserved attempt and are read-only inputs. They are not duplicated in the curated archive; compact counts, exact rows and hashes are retained here.",
    "Windows source verification remains pending; no complete cross-platform pass is claimed.",
]
(R / "final-wheel-proof.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")

disposition = read(R / "coverage-disposition.json")
groups = []
for group in disposition["changed_line_groups"]:
    expected = group["linux_missing_lines"]
    function = group["function"]
    if group["path"] == "src/crapkit/procs.py":
        expected, function = [327, 328, 329], "_complete_command"
    actual = [row["line"] for row in verdict["diff_uncovered"]
              if row["path"] == group["path"] and row["line"] in expected]
    assert actual == expected, (group["path"], actual, expected)
    groups.append({"path": group["path"], "function": function,
                   "linux_missing_lines": actual, "classification": group["classification"]})
new_line = {"path": "src/crapkit/procs.py", "line": 317}
assert new_line in verdict["diff_uncovered"]
disposition["status"] = "final Linux reconciled; final Windows pending"
disposition["final_reconciliation"] = {
    "status": "Linux complete and passed; Windows pending",
    "commit": wheel["candidate"]["commit"], "proof": "final-wheel-proof.json",
    "linux": {"unmarked_over_target": unmarked, "uncovered_count": 12, "groups": groups},
    "new_launch_error_line": {
        "path": "src/crapkit/procs.py", "line": 317, "function": "_raise_launch_error",
        "statement": "raise OSError(*arguments)",
        "classification": "host-specific regression trigger; final Windows evidence pending",
        "reason": "The missing-COMSPEC shell-launch regression is Windows-only. Linux uses fixed /bin/sh. The rethrow itself is cross-platform and remains reachable for native launch failures, so it is not classified as globally unreachable.",
        "test": "tests/unit/test_process_launch.py::test_shell_launch_os_error_reaches_caller_after_cleanup",
    },
    "conclusion": "The nine shared guard/API/cleanup lines remain missing in final Linux coverage. The two Windows Job lines remain Linux-only gaps. OSError rethrow adds one line to reconcile with final Windows coverage. The three unmarked functions retain their earlier Linux measurements.",
    "rules": disposition["final_reconciliation"]["rules"],
}
(R / "coverage-disposition.json").write_text(json.dumps(disposition, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"commit": proof["candidate_commit"], "source_files": proof["source_proofs"]["candidate"]["python_source_files"],
                  "suites": proof["revisions"]["candidate"]["suites"], "ledger": verdict["ledger"],
                  "unmarked": len(unmarked), "uncovered": len(verdict["diff_uncovered"])}))
