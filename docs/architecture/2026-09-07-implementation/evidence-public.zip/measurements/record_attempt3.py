"""Record preserved 0009 results while the 72b source and wheel runs are pending."""
import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
REPO = Path("C:/Users/jfgag/crapkit")
CURRENT = "72b1125d07904f8f41c465e4fe79aba2a1db5fa7"
PRIOR = "0009a6776f7e260046589954d98e035918f89439"
PRODUCTION = "0082379e350aa0eed44eeec50514023a573f61df"
ALIASES = {
    "wheels-final/": "wheels-attempt3/",
    "full-wheels-final.": "full-wheels-attempt3.",
    "final-wheel-proof.json": "wheel-attempt3-proof.json",
}


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def remap(value):
    if isinstance(value, dict):
        return {key: remap(item) for key, item in value.items()}
    if isinstance(value, list):
        return [remap(item) for item in value]
    if isinstance(value, str):
        for before, after in ALIASES.items():
            value = value.replace(before, after)
    return value


def suite(name):
    root = ET.parse(ROOT / "source-attempt3" / f"{name}.xml").getroot()
    cases = list(root.iter("testcase"))
    failed = [f"{case.get('classname')}::{case.get('name')}" for case in cases
              if case.find("failure") is not None or case.find("error") is not None]
    skipped = sum(case.find("skipped") is not None for case in cases)
    return dict(tests=len(cases), passed=len(cases) - len(failed) - skipped,
                skipped=skipped, failures=failed,
                seconds=sum(float(node.get("time", 0)) for node in root.iter("testsuite")))


result = read("source-attempt3/result.json")
verdict = read("source-attempt3/verdict.json")
assert result["commit"] == verdict["commit"] == PRIOR
assert result["exit"] == 8 and verdict["ok"] is False
assert len(verdict["new_failures"]) == 1 and verdict["committed_findings"] == 1
assert not verdict["gate_violations"] and not verdict["ratchet_regressions"]
with sqlite3.connect((ROOT / "source-attempt3/crap.sqlite").as_uri() + "?mode=ro", uri=True) as db:
    db.row_factory = sqlite3.Row
    ledger = [dict(row) for row in db.execute(
        "SELECT id,commit_sha,kind,verdict_ok,findings FROM runs WHERE id IN (77,79) ORDER BY id")]
assert ledger[-1] == dict(id=79, commit_sha=PRIOR, kind="verify", verdict_ok=0, findings=1)
assert ledger[0]["verdict_ok"] == 1 and ledger[0]["findings"] == 0
coverage = read("source-attempt3/py.json")
source_files = {path.replace("\\", "/"): facts for path, facts in coverage["files"].items()
                if path.replace("\\", "/").startswith("src/crapkit/")}
assert 317 in source_files["src/crapkit/procs.py"]["executed_lines"]
assert {54, 55}.issubset(source_files["src/crapkit/_process_owner.py"]["executed_lines"])
linux = remap(read("wheel-attempt3-proof.json"))
assert linux["candidate_commit"] == PRIOR and linux["candidate_ok"] is True
linux["status"] = "Historical 0009 Linux wheel verification passed; Windows run 79 refused one startup fixture."
linux["limits"][-1] = "The same-commit Windows run 79 refused one startup fixture. Both new 72b full runs remain pending."
linux_missing = {(row["path"], row["line"]) for row in linux["diff_uncovered"]}
windows_missing = {(row["path"], row["line"]) for row in verdict["diff_uncovered"]}
shared = [dict(path=path, line=line) for path, line in sorted(linux_missing & windows_missing)]
assert len(shared) == 9
source_proof = dict(
    schema=1, status="completed; refused one startup fixture", candidate_commit=PRIOR,
    result=result, verdict=verdict, ledger=ledger,
    suites={name: suite(name) for name in ("unit", "e2e")},
    coverage=dict(sha256=digest(ROOT / "source-attempt3/py.json"),
                  total_report_files=len(coverage["files"]), selected_source_files=len(source_files),
                  selection="Exact src/crapkit/ prefix after host path-separator conversion.",
                  source_executed_lines=sum(len(item["executed_lines"]) for item in source_files.values()),
                  source_missing_lines=sum(len(item["missing_lines"]) for item in source_files.values()),
                  procs_317_executed=True, windows_job_lines_54_55_executed=True),
    cross_host=dict(linux_proof="wheel-attempt3-proof.json", shared_uncovered=shared,
                    windows_only_missing=[dict(path=p, line=n) for p, n in sorted(windows_missing - linux_missing)],
                    linux_only_missing=[dict(path=p, line=n) for p, n in sorted(linux_missing - windows_missing)]),
    inputs={name: dict(sha256=digest(ROOT / "source-attempt3" / name),
                       bytes=(ROOT / "source-attempt3" / name).stat().st_size)
            for name in ("result.json", "verdict.json", "unit.xml", "e2e.xml", "junit.xml", "crap.sqlite", "py.json")},
    limits=["Coverage is retained from a refusing run and does not turn that verdict into a pass.",
            "The nine shared guard/API/cleanup lines remain unmeasured; no wrong behavior was observed.",
            "The NUL history and named public API compatibility rules remain unchanged.",
            "Large coverage JSON and SQLite inputs remain preserved in scratch; this proof records their hashes and relevant rows."])
save("source-attempt3-proof.json", source_proof)

matrix = read("completion-matrix.json")
matrix["implementation_commit"] = CURRENT
matrix["final_verified_commit"] = None
matrix["production_commit"] = PRODUCTION
verification = matrix["integration_verification"]
windows = verification["windows_full_source_verify"]
windows.update(status="pending", note="72b complete source run pending; 0009 run 79 completed and refused one startup fixture.",
               third_attempt=dict(status=source_proof["status"], result=result, verdict=verdict, ledger=ledger,
                                  suites=source_proof["suites"], evidence="source-attempt3-proof.json"))
wheels = verification["linux_installed_wheel_base_candidate"]
wheels.pop("final_attempt", None)
wheels.update(status="pending", note="72b complete wheel comparison pending; 0009 comparison passed and remains historical proof.",
              third_attempt=linux)
verification["final_artifacts"].update(
    commit=CURRENT, status="pending", last_committed_candidate=CURRENT,
    linux_wheels_status="pending", windows_source_status="pending",
    windows_source="source-final/", linux_wheels="wheels-final/", pending_test_changes=[],
    note="Both 72b full runs are pending. Prior 0009 Linux passed; Windows run 79 refused one startup fixture. Production bytes equal 0082379.")
readiness = read("tests-ci/probe-readiness/result.json")
assert len(readiness["green"]) == len(readiness["posix"]) == 5
assert all(not item["failed"] and not item["error"] and not item["skipped"]
           for label in ("green", "posix") for item in readiness[label])
repair = dict(id="INTEGRATION-PROBE-READINESS", candidates=["EX1", "CI-OPT"], commit=CURRENT,
              status="committed; five focused cases pass on each host; complete reruns pending",
              behavior="Wait for bounded fixture readiness before starting the unchanged two-second adapter wait. Capture the real TimeoutExpired value 2, re-raise it, and retain started/gone checks. Exercise ready and synthetic three-second delayed startup. The separate unwrapped probe retains its five-second wall-clock ceiling.",
              files=["tests/unit/test_init_probe.py"],
              evidence=["tests-ci/probe-readiness/result.json", "execution/probe-readiness-review.json"],
              production_changed=False, max_changed_function_ccn=4,
              measured_tradeoff="No performance claim; the delayed variant deliberately adds three seconds of fixture startup.")
matrix["integration_followups"] = [item for item in matrix["integration_followups"]
                                   if item["id"] != repair["id"]] + [repair]
matrix["probe_readiness_review"] = dict(status="complete; no findings", evidence=repair["evidence"][-1])
matrix["artifact_path_aliases"] = dict(policy="Preserved attempt files moved without changing their bytes. Internal locators in the original wheel proof identify their original paths.", aliases=ALIASES)
save("completion-matrix.json", matrix)

disposition = read("coverage-disposition.json")
prior = disposition.get("prior_0009_reconciliation") or remap(copy.deepcopy(disposition["final_reconciliation"]))
prior.update(status="Historical 0009 coverage reconciled: Linux passed; Windows refused one startup fixture.",
             proof="wheel-attempt3-proof.json", windows_proof="source-attempt3-proof.json",
             windows=dict(verdict_ok=False, run_id=79, findings=1, unmarked_over_target=0,
                          uncovered_count=len(windows_missing), diff_uncovered=verdict["diff_uncovered"]),
             shared_uncovered=shared)
prior["new_launch_error_line"].update(
    classification="host-specific regression trigger; executed by preserved Windows run 79",
    windows_executed=True, windows_evidence="source-attempt3-proof.json",
    reason="The Windows missing-COMSPEC regression executes line 317. Linux uses fixed /bin/sh and leaves it unmeasured. The OSError rethrow itself is cross-platform, not globally unreachable.")
disposition.update(status="Historical 0009 cross-host coverage reconciled; both 72b full runs pending",
                   latest_committed_candidate_commit=CURRENT, prior_0009_reconciliation=prior,
                   final_reconciliation=dict(status="pending", commit=CURRENT, linux_status="pending", windows_status="pending",
                                             historical_proof="source-attempt3-proof.json", rules=prior.get("rules", [])))
save("coverage-disposition.json", disposition)

manifest = read("evidence-manifest.json")
for entry in manifest["entries"]:
    entry["path"] = remap(entry["path"])
    path = REPO / entry["path"][5:] if entry["path"].startswith("repo:") else ROOT / entry["path"]
    if entry["path"] != "coverage-disposition.json":
        assert digest(path) == entry["sha256"], f"Preserved evidence changed: {entry['path']}"


def include(name, kind, purpose, candidates=None):
    path = ROOT / name
    entry = dict(path=name, candidates=candidates or ["EX1", "CI-OPT"], kind=kind,
                 purpose=purpose, bytes=path.stat().st_size, sha256=digest(path))
    manifest["entries"] = [item for item in manifest["entries"] if item["path"] != name] + [entry]


include("coverage-disposition.json", "coverage disposition", "Historical cross-host gaps and current pending status", ["EX1", "CORE-01", "STATE-02"])
include("source-attempt3-proof.json", "historical source proof", "Run 79 refusal, baseline 77 trust, full JUnit counts and compact cross-host coverage reconciliation")
for name in ("unit.xml", "e2e.xml", "junit.xml", "result.json", "verdict.json", "lane-py.log", "stderr.txt"):
    include("source-attempt3/" + name, "historical full source run", "0009 source run 79: one startup-fixture failure; retained original bytes")
for name in ("result.json", "red.xml", "red.log", "green.xml", "green.log", "posix.xml", "posix.log",
             "before.py", "red-test.py", "green-test.py", "probe-readiness.patch", "posix-check.sh", "record.py", "README.md", "precommit.log"):
    include("tests-ci/probe-readiness/" + name, "readiness repair", "Deterministic startup red and five focused green cases on each host; actual deadline unchanged")
include("execution/probe-readiness-review.json", "independent review", "Read-only review finds no defect in the readiness repair")
include("snapshot_ledger.py", "replay", "Preserve SQLite through its backup API without overwriting an earlier snapshot")
include("finalize_evidence.py", "replay", "Admit successful source and wheel verdicts, canonical Git source identity and matching source ledger before packaging")
include("measurements/record_attempt3.py", "replay", "Reconcile preserved 0009 artifacts without reading active 72b outputs")
manifest.update(implementation_commit=CURRENT,
                integration_verification="Both 72b full runs pending. Historical 0009 Linux wheels passed; Windows source run 79 refused one startup fixture.",
                artifact_path_aliases=matrix["artifact_path_aliases"])
manifest["curation"].update(
    included="Focused red/green logs and JUnit, owner results, compact summaries, repeatable probes, immutable duplication input, all earlier refusing/incomplete attempts, historical passing 0009 Linux JUnit/provenance, and reviewed readiness repair.",
    excluded=["Temporary Git repositories, worktrees and runtime environments",
              "Raw .coverage databases, SQLite snapshots and large source coverage JSON files; compact proofs retain input hashes and relevant rows",
              "tests-ci/unit-workers-short/results.json repeats full coverage; unit-worker-summary.json is retained",
              "Obsolete scratch patches and transient setup files",
              "Active 72b source and wheel artifacts; both require final results"])
manifest["entries"].sort(key=lambda item: item["path"])
manifest["curation"]["file_count"] = len(manifest["entries"])
manifest["curation"]["total_bytes"] = sum(item["bytes"] for item in manifest["entries"])
save("evidence-manifest.json", manifest)
print(json.dumps(dict(commit=CURRENT, full_runs="pending", prior_windows=source_proof["suites"],
                      prior_linux="passed", shared_uncovered=len(shared), manifest_files=len(manifest["entries"]),
                      manifest_bytes=manifest["curation"]["total_bytes"]), indent=2))
