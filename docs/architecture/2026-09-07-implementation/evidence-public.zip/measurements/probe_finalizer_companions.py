"""Check standalone archive contents and missing companion admission."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "measurements/manifest-finalizer"
FINALIZER = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "finalize_evidence.py"
spec = importlib.util.spec_from_file_location("companion_finalizer", FINALIZER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
MEASURED = "a" * 40
baseline = json.loads((ROOT / "completion-matrix.json").read_text(encoding="utf-8-sig"))
baseline.update(implementation_commit=MEASURED, final_verified_commit=MEASURED)
verification = baseline["integration_verification"]
verification["windows_full_source_verify"]["status"] = "passed"
verification["linux_installed_wheel_base_candidate"]["status"] = "passed"
verification["final_artifacts"].update(commit=MEASURED, status="complete",
                                        linux_wheels_status="passed", windows_source_status="passed")
for row in baseline["candidates"] + baseline["extra_work"]:
    row.update(implemented=True, complete_suite_status="passed",
               complete_suite_platforms=dict(linux_installed_wheels="passed", windows_source="passed"))
companions = ("report-draft.md", "completion-matrix.json", "decisions.tsv")
expected_members = set(companions) | {"evidence-manifest.json", "verification.json"}
cases = [("complete_archive", None)] + [("missing_" + name, name) for name in companions]
results = []
with tempfile.TemporaryDirectory(prefix="companions-", dir=OUTPUT) as temporary:
    private = Path(temporary)
    for name, omitted in cases:
        case = private / name
        case.mkdir()
        (case / "report-draft.md").write_text("Measured report\n", encoding="utf-8")
        (case / "completion-matrix.json").write_text(json.dumps(copy.deepcopy(baseline)), encoding="utf-8")
        (case / "decisions.tsv").write_text("date\tdecision\n2026-09-07\tverify\n", encoding="utf-8")
        manifest = dict(implementation_commit=MEASURED, entries=[dict(
            path=path, sha256=hashlib.sha256((case / path).read_bytes()).hexdigest())
            for path in companions if path != omitted])
        (case / "evidence-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        refusal = None
        members = []
        copied_bytes_match = False
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                module.package(case, private, case / "output", {"source_verdict": {"commit": MEASURED}})
            accepted = True
            with zipfile.ZipFile(case / "output/evidence.zip") as archive:
                members = archive.namelist()
                copied_bytes_match = set(members) == expected_members and all(
                    archive.read(path) == (case / path).read_bytes()
                    for path in companions + ("evidence-manifest.json",))
        except (AssertionError, KeyError, ValueError) as error:
            accepted, refusal = False, f"{type(error).__name__}: {error}"
        output_created = (case / "output").exists()
        passed = (accepted and copied_bytes_match) if omitted is None else (not accepted and not output_created)
        results.append(dict(case=name, passed=passed, accepted=accepted, refusal=refusal,
                            output_created=output_created, archive_members=members,
                            copied_bytes_match=copied_bytes_match))
receipt = dict(method="Call real scratch package() with complete synthetic matrix and hashed companion files; inspect ZIP members and exact copied bytes.",
               finalizer=str(FINALIZER), finalizer_sha256=hashlib.sha256(FINALIZER.read_bytes()).hexdigest(),
               cases=results, passed=sum(row["passed"] for row in results), failed=sum(not row["passed"] for row in results))
destination = OUTPUT / sys.argv[1]
destination.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(receipt=str(destination), passed=receipt["passed"], failed=receipt["failed"])))
raise SystemExit(bool(receipt["failed"]))
