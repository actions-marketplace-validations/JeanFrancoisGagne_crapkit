"""A binary display attribute must not hide changed source from the gate."""
import json
from pathlib import Path
import subprocess
import tempfile

from crapkit.config import load_config_text
from crapkit.diffparse import changed_ranges
from crapkit.gitio import staged_diff, staged_reads
from crapkit.hook import gate_staged

HERE = Path(__file__).resolve().parent
root = Path(tempfile.mkdtemp(prefix="review-git-binary-", dir=HERE))
(root / "src").mkdir(exist_ok=True)


def git(*args):
    return subprocess.check_output(["git", "-c", "user.name=Review", "-c", "user.email=review@example.invalid", *args], cwd=root)


path = root / "src/app.py"
path.write_text("def work(x):\n    return x\n", encoding="utf-8")
git("init", "-q")
git("add", "src/app.py")
git("commit", "-qm", "clean source")
path.write_text("def work(x):\n" + "".join(f"    if x == {i}: return {i}\n" for i in range(7)) + "    return 0\n", encoding="utf-8")
git("add", "src/app.py")
cfg = load_config_text('[crapkit]\ntarget=6\n[[scope]]\nname="src"\npaths=["src"]\nlanguages=["python"]\ncoverage_optional=true\n')
result = {}
for key, attribute in [("control", ""), ("binary_display_attribute", "src/app.py -diff\n")]:
    (root / ".gitattributes").write_text(attribute, encoding="utf-8")
    patch = staged_diff(root)
    plain = gate_staged(root, cfg)
    with staged_reads(root) as reads:
        started = gate_staged(root, cfg, reads)
    result[key] = {"attribute": attribute, "patch": patch, "ranges": changed_ranges(patch),
                   "gate_violations": [[v.path, v.long_name, v.ccn] for v in plain.violations],
                   "prestarted_violations": [[v.path, v.long_name, v.ccn] for v in started.violations]}
(HERE / "review-git-binary-result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
