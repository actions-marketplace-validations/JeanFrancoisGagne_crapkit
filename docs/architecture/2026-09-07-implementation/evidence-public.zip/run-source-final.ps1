$ErrorActionPreference = 'Stop'
$repo = 'C:\Users\jfgag\crapkit'
$evidence = 'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\implementation-round2\source-final'
$python = 'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\implementation\configured-runtime\venv\Scripts\python.exe'
New-Item -ItemType Directory -Force -Path $evidence | Out-Null
Set-Location -LiteralPath $repo
$env:PYTHONPATH = Join-Path $repo 'src'
$env:PATH = (Split-Path -Parent $python) + [IO.Path]::PathSeparator + $env:PATH
$revision = (git rev-parse HEAD).Trim()
$started = [DateTime]::UtcNow.ToString('o')
$elapsed = [Diagnostics.Stopwatch]::StartNew()
& $python -m crapkit verify --no-tighten --base c2d3515581d410d8c14849063dac27af843a3729 --json 1> (Join-Path $evidence 'verdict.json') 2> (Join-Path $evidence 'stderr.txt')
$result = $LASTEXITCODE
$elapsed.Stop()
@{ commit = $revision; started_utc = $started; seconds = $elapsed.Elapsed.TotalSeconds; exit = $result; python = $python } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $evidence 'result.json') -Encoding utf8
Copy-Item -LiteralPath '.crapkit\lane-py.log','.crapkit\cov\unit.xml','.crapkit\cov\e2e.xml','.crapkit\cov\junit.xml','.crapkit\cov\py.json' -Destination $evidence
Write-Output "Source verification finished: exit $result, $($elapsed.Elapsed.TotalSeconds) seconds"
exit $result
