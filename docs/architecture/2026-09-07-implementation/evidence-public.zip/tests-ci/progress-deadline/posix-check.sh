#!/bin/bash
set -u
cd /mnt/c/Users/jfgag/Documents/Codex/worktrees/ck-r2-progress-deadline || exit 1
export PYTHONPATH="$PWD/src"
export PATH="/tmp/ck-r2-tests-ci-runtime-20260907/venv/bin:$PATH"
export COVERAGE_FILE=.crapkit/progress-deadline-posix.coverage
evidence=/mnt/c/Users/jfgag/Documents/Codex/2026-09-06/c-users-jfgag-appdata-local-temp/work/implementation-round2/tests-ci/progress-deadline
python -c 'import crapkit, sys; print(sys.version); print(sys.executable); print(crapkit.__file__)' > "$evidence/posix-import.txt" || exit 1
python -m pytest tests/unit/test_procs.py tests/unit/test_init_probe.py::test_a_timed_out_mutant_takes_its_whole_process_tree_with_it tests/unit/test_init_probe.py::test_the_probe_kills_the_interpreter_it_stopped_waiting_for tests/unit/test_init_probe.py::test_the_probe_gives_up_when_its_timeout_expires tests/unit/test_init_probe.py::test_a_mutant_that_outlives_its_timeout_dies_at_the_timeout --cov=crapkit --cov-branch --cov-context=test --cov-report= "--junitxml=$evidence/posix.xml" --basetemp=/tmp/ck-r2-progress-deadline-green > "$evidence/posix.log" 2>&1
result=$?
tail -35 "$evidence/posix.log"
exit "$result"
