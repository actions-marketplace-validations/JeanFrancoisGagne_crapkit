"""Capture real miniature-suite commands and their JUnit/coverage contracts."""
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

import crapkit
import pytest

ROOT = Path(os.environ["PYTHONPATH"]).parent.resolve()
assert Path(crapkit.__file__).resolve() == ROOT / "src/crapkit/__init__.py"
HERE = Path(__file__).resolve().parent
HOST, PHASE, TEMP = sys.argv[1:]
OUTPUT = HERE / f"miniature-{HOST}-{PHASE}"
OUTPUT.mkdir(exist_ok=True)
FILES = ["test_suite_nested_coverage.py", "test_suite_config_ownership.py"]
SELECTED = HERE / "miniature-workers-before" if PHASE == "before" else ROOT
sys.path.insert(0, str(ROOT / "tests/unit"))

TRACE = '''import json, os, subprocess
_original = subprocess.Popen
class _ObservedPopen(_original):
    def __init__(self, args, *rest, **options):
        with open(TRACE_PATH, 'a', encoding='utf-8') as stream:
            stream.write(json.dumps({'pid': os.getpid(), 'args': args}) + '\\n')
        super().__init__(args, *rest, **options)
subprocess.Popen = _ObservedPopen
'''


def case_ids(path):
    return sorted(case.get("classname", "") + "::" + case.get("name", "")
                  for case in ET.parse(path).iter("testcase"))


def capture(root, result, command):
    destination = OUTPUT / root.name
    destination.mkdir(exist_ok=True)
    data = json.loads((root / ".crapkit/cov/py.json").read_text())
    records = {name.replace("\\", "/"): {field: row[field] for field in ("executed_lines", "executed_branches")}
               for name, row in data["files"].items()}
    record = {"command": list(map(str, command)), "exit": result.returncode,
              "unit_ids": case_ids(root / ".crapkit/cov/unit.xml"),
              "e2e_ids": case_ids(root / ".crapkit/cov/e2e.xml"), "coverage": records}
    (destination / "record.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
    (destination / "runner.log").write_text(result.stdout + result.stderr, encoding="utf-8")
    for name in ("unit.xml", "e2e.xml", "py.json"):
        (destination / name).write_bytes((root / ".crapkit/cov" / name).read_bytes())


class Capture:
    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_call(self, item):
        original = subprocess.run

        def run(command, *arguments, **options):
            if str(command[1]).endswith("run.py"):
                root = Path(command[command.index("--repo") + 1])
                trace = OUTPUT / (root.name + "-processes.jsonl")
                source = "TRACE_PATH = " + repr(str(trace)) + "\n" + TRACE
                (root / "src/sitecustomize.py").write_text(source, encoding="utf-8")
                result = original(command, *arguments, **options)
                capture(root, result, command)
                return result
            return original(command, *arguments, **options)

        subprocess.run = run
        try:
            yield
        finally:
            subprocess.run = original


arguments = [str(SELECTED / "tests/unit" / name) for name in FILES]
arguments += ["--rootdir=" + str(SELECTED), "--basetemp=" + TEMP, "-p", "no:randomly", "-q",
              "--junitxml=" + str(OUTPUT / "outer.xml")]
raise SystemExit(pytest.main(arguments, plugins=[Capture()]))
