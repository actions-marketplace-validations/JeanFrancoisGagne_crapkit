"""Compare recorded child commands, test IDs and coverage for two fixtures."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import crapkit

ROOT = Path(r"C:\Users\jfgag\Documents\Codex\worktrees\ck-r2-tests-ci")
HERE = Path(__file__).resolve().parent
assert Path(crapkit.__file__).resolve() == ROOT / "src/crapkit/__init__.py"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def outer(path):
    cases = list(ET.parse(path).iter("testcase"))
    assert len(cases) == 2
    assert all(case.find("failure") is None and case.find("error") is None for case in cases)
    return sorted(case.get("classname", "") + "::" + case.get("name", "") for case in cases)


def launches(path):
    commands = [json.loads(line)["args"] for line in path.read_text(encoding="utf-8").splitlines()]
    return {suite: next(command for command in commands if f"tests/{suite}" in command)
            for suite in ("unit", "e2e")}


hosts = {}
for host in ("windows", "posix"):
    before, after = [HERE / f"miniature-{host}-{phase}" for phase in ("before", "after")]
    assert outer(before / "outer.xml") == outer(after / "outer.xml")
    host_cases = {}
    for path in before.glob("*/record.json"):
        name = path.parent.name
        old, new = read(path), read(after / name / "record.json")
        assert old["exit"] == new["exit"] == 0
        for key in ("unit_ids", "e2e_ids", "coverage"):
            assert old[key] == new[key], (host, name, key)
        old_args = launches(before / (name + "-processes.jsonl"))
        new_args = launches(after / (name + "-processes.jsonl"))
        assert old_args["unit"][old_args["unit"].index("-n") + 1] == "4"
        assert "-n" not in new_args["unit"]
        assert all(args["e2e"][args["e2e"].index("-n") + 1] == "2" for args in (old_args, new_args))
        host_cases[name] = {"unit_ids": new["unit_ids"], "e2e_ids": new["e2e_ids"],
                            "coverage": new["coverage"], "before_argv": old_args, "after_argv": new_args}
    assert len(host_cases) == 2
    hosts[host] = {"outer_ids": outer(after / "outer.xml"), "before_passed": 2, "after_passed": 2,
                   "cases": host_cases}

files = ["tests/unit/test_suite_nested_coverage.py", "tests/unit/test_suite_config_ownership.py"]
patch = []
proof = {}
for name in files:
    before = HERE / "miniature-workers-before" / name
    after = ROOT / name
    old, new = before.read_text(), after.read_text()
    old_assertions = [ast.dump(node) for node in ast.walk(ast.parse(old)) if isinstance(node, ast.Assert)]
    new_assertions = [ast.dump(node) for node in ast.walk(ast.parse(new)) if isinstance(node, ast.Assert)]
    assert old_assertions == new_assertions
    proof[name] = {"before": hashlib.sha256(before.read_bytes()).hexdigest(),
                   "after": hashlib.sha256(after.read_bytes()).hexdigest(),
                   "assertions_unchanged": len(old_assertions)}
    patch.extend(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                     fromfile="a/" + name, tofile="b/" + name))
(HERE / "miniature-workers.patch").write_text("".join(patch), encoding="utf-8", newline="")
result = {"files": files, "proof": proof, "hosts": hosts,
          "limits": ["This checks process selection and behavior, not elapsed-time improvement.",
                     "A temporary sitecustomize in each private fixture records subprocess argv and delegates unchanged to Popen.",
                     "Each child coverage result still has the same four lines and two branches. Both E2E cases and their concurrency stay intact.",
                     "The unit maxschedchunk and six-commit fixture-prefix ideas remain unproven candidates; neither was implemented."]}
(HERE / "miniature-workers.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"files": proof, "hosts": {host: {"before": data["before_passed"],
                                                   "after": data["after_passed"]} for host, data in hosts.items()}}, indent=2))
