# Test and CI optimization

Source base: c2d3515581d410d8c14849063dac27af843a3729.

## First measured cost

Retained candidate unit JUnit reports 999.219 seconds. Release recovery, destination and guard tests account for 284.784 seconds. One fresh retry profile spends 10.114 of 10.607 seconds in 74 subprocess calls; fixture creation takes 1.750 seconds and release proof takes 8.468 seconds.

The first change removes repeated fixture preparation. Keep release proof, local publication and retry execution real. Build a pristine tiny fixture once under the pytest temporary parent, then copy its checkout and bare remote into each case and point origin at that case's remote. Both fixture states, before and after the version bump, have separate seeds.

The first slice kept scheduling unchanged while measuring fixture costs. Later paired worker measurements support four unit workers. Replacing Git proof with a fake loses source identity evidence; caching production proof weakens release admission. Both were rejected.

Compatibility: case identities and assertions stay intact. Every case receives independent source bytes, index, local refs and remote refs. The seed contains no release receipt or run ledger. Tests must prove isolation after a branch, source edit and remote push. A structural regression records fixture initialization, not an absolute timing threshold.

## Hosted schedule

Ubuntu/Python 3.12 currently runs the candidate source suites twice: the matrix and the dogfood action. The isolated verdict job also runs a separate candidate wheel, which tests a different installation contract and stays.

Move the Ubuntu/Python 3.12 source owner to dogfood. Keep its editable dev installation and the same `tools/testing/run.py` schedule selected by crapkit.toml. Move the console smoke and event-base staged gate with it. Preserve the other five matrix entries and both wheel revisions.

The action is advisory, so its exit code alone cannot replace a test job. Clear the old JUnit before invoking the action, then read the newly produced JUnit through the existing report admission function and fail for any test failures. Missing, malformed, empty and failed reports fail this step. This avoids adding a runner mode or changing the action's user-facing gate contract.

The workflow regression executes the exact admission command against disposable reports and checks all six platform/interpreter owners. Hosted wall time cannot be measured without a dispatch. Retained run 34064274233 reports 101 seconds of unit tests plus 69 seconds of E2E for the duplicate Ubuntu/Python 3.12 matrix owner; deleting that work reduces runner work, not the already-longer dogfood critical path by 170 seconds.

## Inventory fixture

The committed mini repository is copied, initialized and committed once per test. Reuse a pristine committed copy under the worker's pytest temporary parent, then copy it into each test directory. No analysis cache, coverage artifact or store enters the seed. Keep every real CLI invocation and every nested pytest lane, including its subprocess coverage and xdist behavior. The isolation test edits and measures the first copy, then verifies the second still has its original index, ref, four functions and cold cache.

## Retained costs

The full baseline and candidate wheel runs judge different source bytes. Reusing one revision's coverage or editable package for the other would invalidate the comparison, so both remain. The installed-source byte proof and environment cleanup stay unchanged.

The runner now uses four unit workers and eight E2E workers. Bare pytest stays serial, and the runner accepts --unit-workers 1 for reproduction. A fixed 32-case subset ran once cold and five warm rounds at one, two and four unit workers. Warm medians were 46.932, 39.321 and 33.915 seconds. Case IDs and the union of 3,467 executed lines and 466 branches were identical. The child-only branch assertion passed in every round. These measurements establish a 27.7% improvement on this subset, not the full suite. Small correctness probes overlapped some samples; no competing full suite ran.

Fresh miniature-runner tests explicitly select serial units unless they test worker selection. The scoped source command uses the shared four-worker schedule. No timeout, test selection, assertion or coverage requirement was relaxed.

## Final fixture measurements

Seven interleaved warm samples on Windows Python 3.11.2 measured release setup at 2.6973 seconds before and 0.1569 seconds after. The separate first setup rose from 1.9341 to 2.2617 seconds. Inventory setup fell from 0.6506 to 0.0468 seconds warm; its first setup rose from 0.3039 to 0.7558 seconds. These are fixture costs only, with no CLI or lane time included. Each pytest worker builds its own seed.

Publish a seed only after complete preparation by renaming a temporary sibling. Injected Git initialization failures prove the next test can retry rather than inherit incomplete input. Copies retain private source, index, local refs, remote refs and measurement state.

## Final integration schedule

Run normal Windows source coverage and actual verify against the preserved ledger. In parallel, run the full noneditable base/candidate wheel comparison in the task-local POSIX runtime. Each wheel must retain its own source tree, installed-byte proof, JUnit and coverage. The existing comparison tool measures both revisions unconditionally and has no verified prior-baseline reuse path, so a fresh base run remains required. No whole-suite timeout changed. Parallel validation can add host contention; the subset result does not promise either full run's duration.

The first full inventory invocation used a Git-owned basetemp and an absolute shared coverage database. It produced 43 passes and 13 setup-related failures. The corrected replay ran exactly those 13 cases with the shared runner's relative COVERAGE_FILE convention and a short directory outside Git; all 13 passed. Both attempts remain in evidence. Final integrated suites remain the overall acceptance check.

## Runtime

Windows uses the configured-runtime Python 3.11.2 environment with PYTHONPATH selecting this checkout. WSL Ubuntu's system Python 3.10 lacks the required dependencies, so an isolated CPython 3.11.16 environment was prepared under /tmp/ck-r2-tests-ci-runtime-20260907. System Python, shell profiles and shared environments remain unchanged.

The setup uses the official uv standalone release and managed-Python instructions: https://docs.astral.sh/uv/getting-started/installation/ and https://docs.astral.sh/uv/guides/install-python/. setup-posix.sh and posix-setup.log retain the exact download and setup commands; posix-dependencies.txt records the installed versions.
