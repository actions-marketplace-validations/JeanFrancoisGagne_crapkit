"""Keep parent and owner coverage while excluding only a fake target package."""
import json
import os
from pathlib import Path
import subprocess
import sys

from coverage import CoverageData

HERE = Path(__file__).resolve().parent
source = Path(sys.argv[1])
host = sys.argv[2]
outcomes = []
for mode in ('plain', 'no-site'):
    base = HERE / ('.coverage.fake-target-' + host + '-' + mode)
    report = HERE / ('fake-target-' + host + '-' + mode + '-coverage.json')
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith(('COVERAGE_', 'COV_CORE_'))}
    environment.update(PYTHONPATH=str(source / 'src'), PYTHONDONTWRITEBYTECODE='1', COVERAGE_FILE=str(base))
    common = [sys.executable, '-B', '-m', 'coverage']
    subprocess.run([*common, 'erase'], env=environment, cwd=source, capture_output=True,
                   text=True, encoding='utf-8', timeout=30, check=True)
    commands = [
        [*common, 'run', '--branch', '--source=crapkit', '--rcfile=' + str(source / 'pyproject.toml'),
         str(HERE / 'probe_fake_target.py'), mode],
        [*common, 'combine', '--keep'],
        [*common, 'json', '-o', str(report)],
    ]
    outputs = []
    for command in commands:
        done = subprocess.run(command, env=environment, cwd=source, capture_output=True,
                              text=True, encoding='utf-8', timeout=30)
        outputs.append({'argv': command, 'exit': done.returncode, 'stdout': done.stdout, 'stderr': done.stderr})
    assert outputs[0]['exit'] == 0, outputs
    assert outputs[1]['exit'] == 0, outputs
    data = CoverageData(basename=str(base))
    data.read()
    files = {path: len(data.lines(path) or []) for path in sorted(data.measured_files())}
    fake_files = {path: count for path, count in files.items() if 'ck-fake-target-' in path}
    real_files = {path: count for path, count in files.items()
                  if Path(path).is_relative_to(source / 'src')
                  and path.replace('\\', '/').endswith(('/crapkit/procs.py', '/crapkit/_process_owner.py'))}
    assert len(real_files) == 2 and min(real_files.values()) > 0, real_files
    if mode == 'no-site':
        assert outputs[2]['exit'] == 0 and not fake_files, outputs
    else:
        assert outputs[2]['exit'] != 0 and fake_files, outputs
    outcomes.append({'mode': mode, 'commands': outputs, 'fake_files': fake_files, 'real_files': real_files})
result = {'python': sys.executable, 'source': str(source), 'outcomes': outcomes}
(HERE / ('fake-target-' + host + '-result.json')).write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'python': sys.executable, 'outcomes': [
    {'mode': row['mode'], 'export_exit': row['commands'][2]['exit'],
     'fake_files': row['fake_files'], 'real_files': row['real_files']} for row in outcomes]}, indent=2))
