"""Compare launcher error transport with interleaved same-host commands."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys

CASE = '''import json,sys,time
import crapkit
from crapkit.procs import run_bounded,own_processes
command = f'"{sys._base_executable}" -I -S -c "pass"'
start = time.perf_counter()
if sys.argv[1] == 'shared':
    with own_processes([]) as owner:
        start = time.perf_counter()
        assert run_bounded(command, None, owner=owner) == 0
        seconds = time.perf_counter() - start
else:
    assert run_bounded(command, None) == 0
    seconds = time.perf_counter() - start
print(json.dumps({'seconds': seconds, 'source': crapkit.__file__}))
'''


def sample(source, mode):
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith(('COVERAGE_', 'COV_CORE_'))}
    environment.update(PYTHONPATH=str(source), PYTHONDONTWRITEBYTECODE='1')
    done = subprocess.run([sys.executable, '-B', '-c', CASE, mode], env=environment,
                          capture_output=True, text=True, check=True, timeout=15)
    return json.loads(done.stdout)


root, output = map(Path, sys.argv[1:])
sources = {'base': root / 'ck-r2-execution/src', 'candidate': root / 'ck-r2-integration-fix/src'}
result = {'interpreter': sys.executable, 'modes': {}, 'sources': {
    name: {'path': str(path), 'sha256': hashlib.sha256((path / 'crapkit/procs.py').read_bytes()).hexdigest()}
    for name, path in sources.items()}}
for mode in ('standalone', 'shared'):
    pairs = []
    for round_number in range(6):
        order = list(sources) if round_number % 2 == 0 else list(reversed(sources))
        pairs.append({name: sample(sources[name], mode) for name in order})
    medians = {name: statistics.median(pair[name]['seconds'] for pair in pairs[1:]) for name in sources}
    result['modes'][mode] = {'cold': pairs[0], 'warm': pairs[1:], 'warm_medians': medians,
                             'delta_seconds': medians['candidate'] - medians['base']}
output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({name: {'medians': values['warm_medians'], 'delta_seconds': values['delta_seconds']}
                  for name, values in result['modes'].items()}, indent=2))
