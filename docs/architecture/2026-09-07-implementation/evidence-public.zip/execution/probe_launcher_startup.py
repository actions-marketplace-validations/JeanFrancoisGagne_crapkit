"""Observe launcher diagnostics under a child-only POSIX descriptor limit."""
import json
from pathlib import Path
import resource
import sys

import crapkit
from crapkit.procs import run_bounded

rows = []
for maximum in (3, 4):
    def constrain():
        resource.setrlimit(resource.RLIMIT_NOFILE, (maximum, maximum))

    try:
        result = run_bounded('exit 0', 5, preexec_fn=constrain)
        rows.append({'limit': maximum, 'result': result})
    except Exception as error:
        rows.append({'limit': maximum, 'exception': type(error).__name__, 'message': str(error)})
result = {'python': sys.executable, 'source': crapkit.__file__, 'observations': rows}
Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
