"""Replay a deliberately fake target package and then remove its source."""
import json
import os
from pathlib import Path
import sys
import tempfile

from crapkit import procs

with tempfile.TemporaryDirectory(prefix='ck-fake-target-') as directory:
    root = Path(directory)
    package = root / 'crapkit'
    package.mkdir()
    (package / '__init__.py').write_text("origin = 'target package'\n", encoding='utf-8')
    (package / '_process_owner.py').write_text("raise RuntimeError('wrong owner')\n", encoding='utf-8')
    script = root / 'target.py'
    script.write_text('import crapkit; print(crapkit.origin)\n', encoding='utf-8')
    os.environ['PYTHONPATH'] = str(root)
    flag = ' -S' if sys.argv[1] == 'no-site' else ''
    with (root / 'output.log').open('w+b') as output:
        assert procs.run_bounded(f'"{sys.executable}"{flag} "{script}"', 10, stream=output) == 0
        output.seek(0)
        assert output.read().strip() == b'target package'
    print(json.dumps({'fake': str(package), 'mode': sys.argv[1], 'target_output': 'target package'}))
