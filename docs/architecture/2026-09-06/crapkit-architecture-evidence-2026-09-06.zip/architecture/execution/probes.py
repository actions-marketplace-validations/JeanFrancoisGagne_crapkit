"""Read-only review probes. All files stay under this script's scratch directory."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
from unittest.mock import patch

from crapkit.config import Lane, load_config_text
from crapkit.cli.scoring import _collect_lanes
from crapkit.lanes import LaneOutcome, build_retest_command, retest_lane
from crapkit.mutate import file_mutants
from crapkit.mutate_pool import _seed, _pool_lock, drop_pool
from crapkit.verify import evaluate

BASE = Path(__file__).resolve().parent
SCRATCH = BASE / 'scratch'
SCRATCH.mkdir(exist_ok=True)
results = {}

cfg = load_config_text('''
[[scope]]
name = "src"
paths = ["src"]
languages = ["python"]
[[lane]]
name = "unit"
command = "echo first"
artifact = "first.json"
parser = "coveragepy"
scopes = ["src"]
[[lane]]
name = "unit"
command = "echo second"
artifact = "second.json"
parser = "coveragepy"
scopes = ["src"]
''')
first, second = cfg.lanes
outcomes = {
    first: (LaneOutcome({}, {'failures': ['test_math::fails'], 'scopes': ['src']}, {}), ''),
    second: (LaneOutcome({}, {'failures': [], 'scopes': ['src']}, {}), ''),
}
_, provenance, errors, succeeded = _collect_lanes(SCRATCH, cfg.lanes, outcomes)
failures = {f for prov in provenance.values() for f in prov.get('failures', ())}
verdict = evaluate(fresh=[], changed_ranges={}, ratchet=[], baseline_failures=set(),
                   fresh_failures=failures, target=6)
results['duplicate_lanes'] = {
    'accepted_names': [lane.name for lane in cfg.lanes],
    'input_failure': 'test_math::fails', 'retained_failures': sorted(failures),
    'verdict_ok': verdict.ok, 'lane_errors': errors,
}

retest = SCRATCH / 'empty_retest.py'
retest.write_text("from pathlib import Path\nPath('junit.xml').write_text('<testsuite tests=\"0\"/>')\nraise SystemExit(5)\n", encoding='utf-8')
lane = Lane('unit', 'unused', 'unused.json', 'coveragepy', ('src',),
            results_artifact='junit.xml', timeout_seconds=5,
            retest_command=f'"{sys.executable}" "{retest}"')
flakes = retest_lane(SCRATCH, lane, {'test_math::fails'})
results['zero_test_retest'] = {'runner_exit': 5, 'tests_reported': 0, 'failures_forgiven': sorted(flakes)}
retest.write_text("from pathlib import Path\nPath('junit.xml').write_text('<testsuite tests=\"1\"><testcase classname=\"other\" name=\"passes\"/></testsuite>')\nraise SystemExit(2)\n", encoding='utf-8')
flakes = retest_lane(SCRATCH, lane, {'test_math::fails'})
results['unrelated_test_retest'] = {'runner_exit': 2, 'reported_pass': 'other::passes',
                                   'requested_test': 'test_math::fails', 'failures_forgiven': sorted(flakes)}

echo_args = SCRATCH / 'echo_args.py'
echo_args.write_text('import json,sys\nprint(json.dumps(sys.argv[1:]))\n', encoding='utf-8')
template = f'"{sys.executable}" "{echo_args}" {{tests}}'
identifier = 'tests/test_math.py::test_value[%CRAPKIT_REVIEW_TOKEN%]'
command = build_retest_command(template, {identifier})
done = subprocess.run(command, shell=True, capture_output=True, text=True,
                      env={**os.environ, 'CRAPKIT_REVIEW_TOKEN': 'EXPANDED_BY_SHELL'})
results['windows_retest_shell_expansion'] = {'test_id': identifier, 'received_argv': json.loads(done.stdout)}

root, tree = SCRATCH / 'main', SCRATCH / 'worker'
for folder in (root, tree):
    (folder / 'src').mkdir(parents=True, exist_ok=True)
    (folder / 'tests').mkdir(exist_ok=True)
    (folder / 'src' / 'math.py').write_text('def enabled(): return True\n', encoding='utf-8')
(root / 'tests' / 'test_math.py').write_text('assert enabled() is True\n', encoding='utf-8')
(tree / 'tests' / 'test_math.py').write_text('assert True\n', encoding='utf-8')
_seed(root, tree, ['src/math.py'])
results['mutation_seed'] = {
    'main_test': (root / 'tests' / 'test_math.py').read_text(),
    'worker_test': (tree / 'tests' / 'test_math.py').read_text(),
    'source_matches': (root / 'src' / 'math.py').read_bytes() == (tree / 'src' / 'math.py').read_bytes(),
}

pool_root = SCRATCH / 'locked_pool'
pool_tree = pool_root / '.crapkit' / 'mutate-pool' / 'w0'
pool_tree.mkdir(parents=True, exist_ok=True)
attempts = []
with _pool_lock(pool_root) as held:
    with patch('crapkit.mutate_pool._drop', side_effect=lambda root, base, trees: attempts.extend(str(p) for p in trees)):
        with patch('crapkit.mutate_pool.shutil.rmtree'):
            drop_pool(pool_root)
results['pool_drop_under_lock'] = {'pool_lock_held': held, 'drop_attempted_paths': attempts}

sources = {
    'identifier': 'def f():\n    isTrue = 1\n    return isTrue\n',
    'inline_comment': 'def f():\n    return 1  # true == false\n',
    'docstring': 'def f():\n    """\n    True means enabled\n    """\n    return 1\n',
}
results['nonsemantic_mutants'] = {name: [m.mutated for m in file_mutants(source, None, 'python')]
                                  for name, source in sources.items()}
from crapkit.cli import admin
admin._runner_report.cache_clear()
with patch.object(admin, '_PROBE_TIMEOUT_SECONDS', 0.1):
    with patch.object(admin, '_VERSION_PROBE', '-c "import time; time.sleep(0.7)"'):
        started = time.perf_counter()
        answer = admin._runner_report(sys.executable)
        results['doctor_probe_timeout'] = {'deadline_seconds': 0.1, 'child_sleep_seconds': 0.7,
                                           'returned_after_seconds': round(time.perf_counter() - started, 3),
                                           'answer': answer}
out = BASE / 'probe-results.json'
out.write_text(json.dumps(results, indent=2), encoding='utf-8')
print(json.dumps(results, indent=2))
