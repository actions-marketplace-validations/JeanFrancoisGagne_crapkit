# Execution and delivery review

Reviewed clean HEAD `20f00e1371334f84aa70bba6f7b23bfc4bdae0f6`. Repository files remain unchanged. The highest-value changes prevent successful verdicts from incomplete test evidence and make mutation workers measure the same checkout.

| Rank | Candidate | Evidence class | Cost and risk |
|---|---|---|---|
| E1 | Reject duplicate lane identities before executing lanes | Demonstrated lost failure and passing verdict | Small change; configurations with duplicate names must rename lanes |
| E2 | Forgive a retry only when its artifact records that requested test passing | Demonstrated false forgiveness | Small to medium change; keep test ID conventions compatible |
| E3 | Give every mutation worker the same source and test snapshot | Demonstrated input mismatch; score difference not measured | Medium change; copying dependencies and preserving ignored build inputs need deliberate rules |
| E4 | Stop generating mutants from identifier fragments and non-code text | Demonstrated spurious mutants | Medium change; language-aware reading must preserve intended operator coverage |
| E5 | Route the remaining shell probe deadline through the existing process owner | Measured 0.753s return against 0.1s deadline | Small change; preserve captured output and lazy imports |

## E1. One lane name must identify one lane

The configuration loader accepts two lanes named `unit`. The lane executor retains them separately, but the result fold overwrites the first lane's provenance with the second's. Fresh test failures are then derived from that overwritten map. The probe supplied one failed test in the first successful coverage lane and no failures in the second. The result contained no failures and `Verdict.ok` was true.

| Evidence | Location |
|---|---|
| Loader builds lanes without rejecting duplicate names | `src/crapkit/config.py:763` |
| Shared artifact refusal exempts lanes whose names match | `src/crapkit/config.py:750` |
| Execution uses Lane objects because names are not unique | `src/crapkit/cli/scoring.py:174` |
| Fold overwrites provenance by name | `src/crapkit/cli/scoring.py:217` |
| Failure union reads only retained provenance | `src/crapkit/cli/scoring.py:288` |
| Verify supplies these failures to the verdict | `src/crapkit/cli/verifying.py:622` and `:631` |

Caller flow: `coverage/verify -> _scored_run -> _run_lanes -> _collect_lanes -> run.test_failures -> evaluate`.

Proposed change: require unique lane names while reading configuration. Also reject collisions across the artifact paths a lane can write. Remove the downstream duplicate-name accommodations once this invariant holds.

Deletion test: removing support for duplicate names removes bookkeeping and ambiguous overwrite behavior. The complexity does not need to move into callers. The normal configuration and JSON formats already use the lane name as the identity.

Diagram description: before, two lanes flow into one named result slot and the later result replaces the earlier one. After, configuration admits one lane per result slot, and every executed lane reaches the verdict once.

Retain declaration-order folding, per-lane logs, failed-lane refusal, and parallel execution. Validate duplicate names with distinct artifacts, duplicate names with shared artifacts, cross-lane coverage/results path collisions, and ordinary parallel lanes with distinct names. The failing test should drive the configuration loader and verify failure aggregation, not copy the dict assignment into a test.

## E2. Retest evidence must name the test that passed

`retest_lane` computes the forgiven failures as requested IDs minus failed IDs. That is insufficient evidence that a requested test ran. The probe rerun exited 2 and wrote a valid report containing one unrelated passing test. Crapkit forgave `test_math::fails`, which was absent from the report.

| Evidence | Location |
|---|---|
| Retry command receives requested failure IDs | `src/crapkit/lanes.py:975` |
| Only timeout status prevents reading the report | `src/crapkit/lanes.py:985` |
| Forgiveness is requested minus failed | `src/crapkit/lanes.py:987` through `:990` |
| Reader discards passed and skipped test identities | `src/crapkit/junitparse.py:43` through `:53` |
| Forgiven IDs are removed from the verdict | `src/crapkit/cli/verifying.py:673` and `:685` |

Caller flow: `cmd_verify -> _maybe_flake_retry -> _flake_retry -> retest_lane -> failed_test_ids -> survivors subtraction`.

Proposed change: keep the requested failure unless a newly written, completed retry report explicitly records that ID passing. A skipped, missing, stale, or interrupted test should retain its failure. Concentrate this determination in the existing JUnit and retry code rather than making each caller infer passes from absence.

Deletion test: delete the subtraction rule that equates missing failures with passing tests. Callers can still consume the returned set of proven flakes; they need no new knowledge about XML or runner exits.

Diagram description: before, retry report failures are subtracted from requested IDs and absence becomes a pass. After, a retry must supply fresh passing evidence for each requested ID before the verdict drops it.

Retain the current refusal of zero-test and crashed-worker reports. The probe explicitly confirmed zero-test refusal. Validate a real pass, continuing failure, skipped requested case, unrelated passing case, stale report, partial report and failed retry command. Existing `tests/unit/test_retest_template.py` tests formatting only; `tests/unit/test_lane_abort.py:193` covers reported crashes but not a missing requested ID.

## E3. Mutation concurrency must preserve the tree being measured

The single-worker path runs in the live checkout. Parallel workers start at HEAD and copy only files that actually contain mutants. Tests are deliberately excluded from mutation targets, so new or modified tests remain at HEAD in those workers. Changes to supporting source with no generated operator, configuration, fixtures and deleted files also need attention. The probe used the production `_seed` function and confirmed that matching source files coexisted with different tests in the main and worker trees.

| Evidence | Location |
|---|---|
| Diff is against the working tree | `src/crapkit/cli/analyses.py:80` |
| Test files are removed from mutation targets | `src/crapkit/cli/analyses.py:86` through `:99` |
| Seed copies only supplied targets | `src/crapkit/mutate_pool.py:140` through `:146` |
| Targets are derived from actual mutants, not the full diff | `src/crapkit/mutate_pool.py:320` |
| Parallel baseline runs in only the first prepared tree | `src/crapkit/mutate_pool.py:327` |
| Single-worker branch runs at the live root | `src/crapkit/mutate_pool.py:347` through `:348` |

Caller flow: `cmd_mutate -> diff targets -> corpus filter -> generated mutants -> run_mutants -> live tree or seeded HEAD worktrees`.

Proposed change: capture the working-tree inputs once, including test and supporting-file changes, and prepare every worker from that same content. Use the same preparation rule at every worker count. Keep the restriction against mutating tests; measuring tests and mutating tests are separate decisions.

Deletion test: removing the live-tree special case and source-only seed rule eliminates two definitions of the tree under test. Preparation belongs once in mutation execution instead of becoming an obligation every caller must remember.

Diagram description: before, one worker uses dirty source plus dirty tests while several workers use dirty mutated source plus committed tests. After, every worker receives the same source, test, configuration and deletion snapshot, then applies one mutant privately.

Retain the live-suite preflight, bounded process tree termination, deterministic result order, byte restoration, retained worktree speedup and scratch-tree `.git` guard. Validate identical outcomes with one and several workers while adding tests, modifying a nonmutated dependency, changing configuration and deleting files. An interrupted mutation must leave the user's checkout unchanged. The score delta for the demonstrated mismatch has not been measured.

Related demonstrated ownership gap: `drop_pool` does not acquire `_pool_lock`. The probe held the real pool lock and observed a deletion attempt through a patched `_drop`; it deleted no worktree. `src/crapkit/mutate_pool.py:235` through `:243` conflicts with the ownership established at `:168` and `:270`. Pool cleanup should participate in the existing ownership rule and refuse or wait when a run owns it. Keep the lock identity stable while doing so. Validate this with two processes and disposable trees before any implementation is declared complete.

## E4. Mutation generation needs code tokens

The generator finds operator strings by substring search after masking strings on each individual line. It skips only lines that start with a comment marker. The probe produced four spurious mutants across three short Python functions: two `isTrue` identifier fragments, an inline comment comparison, and a line inside a multiline docstring.

| Evidence | Location |
|---|---|
| Boolean literals are raw string entries | `src/crapkit/mutate.py:38` through `:44` |
| String mask reads one line and has no multiline state | `src/crapkit/mutate.py:52` and `:117` |
| Operator search uses substring occurrences | `src/crapkit/mutate.py:141` through `:152` |
| Only whole comment lines are skipped | `src/crapkit/mutate.py:167` through `:175` |
| Any nonzero suite result is a kill | `src/crapkit/mutate_pool.py:114` |

Caller flow: `cmd_mutate -> _collect_mutants -> file_mutants -> raw substring mutations -> run_one -> boolean killed result`.

Proposed change: generate mutations only from operator or boolean tokens in executable code. Remove the generic substring treatment of boolean words and the per-line assumption about strings and comments. Decline unsupported forms explicitly until the reader can identify them correctly.

Deletion test: deleting invalid mutation candidates removes both false measurements and unnecessary suite executions. No complexity returns to callers. Avoid introducing a language registry solely to relocate the same substring tables.

Diagram description: before, text fragments become mutants and syntax or name errors count as test kills. After, only eligible code tokens become mutants; comments and identifiers never enter execution.

Retain changed-line selection, deterministic ordering, corpus selection and the explicit Shell/PowerShell refusal. Validate escaped strings, multiline strings, inline comments, identifier fragments, existing comparison operators and a true semantic survivor. Existing mutation tests passed; they cover simple strings and full comment lines but do not cover these examples. Four unnecessary mutants were measured, not their full-suite runtime cost.

## E5. The doctor shell probe bypasses the process owner

The existing `run_bounded` module owns timeout cleanup for lanes and mutations. The doctor environment probe uses `subprocess.run` with `shell=True`, captured output and a timeout. On Windows, a 0.1-second configured deadline returned after 0.753 seconds when its interpreter child slept for 0.7 seconds. The child self-exited, and no process remained after the probe.

| Evidence | Location |
|---|---|
| Doctor probe spawns a shell with captured pipes | `src/crapkit/cli/admin.py:851` |
| Timeout is applied to subprocess.run | `src/crapkit/cli/admin.py:852` |
| Existing process owner kills the whole child tree | `src/crapkit/procs.py:56` |
| Bounded spawn uses file output to avoid pipe-drain waits | `src/crapkit/procs.py:119` through `:137` |

Caller flow: `doctor -> lane environment probes -> _runner_report -> shell -> interpreter`. The timeout kills the shell while inherited output handles keep the call waiting for the interpreter.

Proposed change: use the existing bounded process owner and a temporary output file for this small report. Keep output parsing in the doctor code. Remove the local timeout implementation.

Deletion test: deleting this second timeout implementation concentrates process cleanup in `procs.py`. The doctor still asks for the same executable and version report.

Diagram description: before, doctor and lane execution own different timeout paths. After, both ask the same process owner to run and reap the tree, with doctor reading its small captured report afterward.

Retain memoization by interpreter word and lazy loading. Validate a normal report, absent pytest, a child that outlives its shell deadline, and no surviving descendant. Root reviewer supplied this lead and should own the final admin finding.

## Other evidence and limits

- Shell templates alter test IDs. The Windows probe passed `tests/test_math.py::test_value[%CRAPKIT_REVIEW_TOKEN%]` to `build_retest_command` and the actual child received `tests/test_math.py::test_value[EXPANDED_BY_SHELL]`. `src/crapkit/lanes.py:966` through `:968` wraps text in quotes without shell escaping; scoped tests repeat that logic at `src/crapkit/cli/verifying.py:804`. This is demonstrated wrong argument delivery. Arbitrary command execution was not attempted. Treat test IDs and file paths as argument data and keep quoting in one place if these templates remain.
- CI starts the full unit/e2e pair on six OS/Python combinations, then dogfood runs the configured suite again. This is a static count, not a billed-time measurement. No CI timing recommendation is ranked without current run data.
- CI calls `hook-precommit` on an unstaged checkout. The workflow itself explains the command is a startup smoke test. `gate_staged` returns immediately on no staged ranges at `src/crapkit/hook.py:147`; dogfood sets gate false and delta false. The check name and the comment claiming this is the repository's gate overstate what runs. No disposable staged-diff CI simulation was performed.
- Action base state uses fixed `RUNNER_TEMP` files. Its cleanup removes the base directory and reason but leaves an earlier base SHA. This matters if an action runs twice in one job. The sequential-action scenario was not executed and is not ranked.
- Release planning puts clean-tree and pushed-main requirements in a note at `tools/release/release.py:301`; `run` does not enforce them and stage1 includes `git add -A`. Stage2b can run independently of verify. This is code inspection, not a release attempt. Existing table-driven version surfaces and exact-count checks are worth retaining. A future release change should enforce documented stage prerequisites and make the Python-owned execution portable on Windows, where `rm -rf dist` in a cmd.exe shell is not portable.

## Coverage inventory

| Area | Inspected |
|---|---|
| Context | Contributing section of AGENTS.md, CONTEXT.md, both accepted ADRs, codebase-design skill, recent commit subjects for assigned paths |
| Lane execution | `lanes.py` function inventory, reuse/stamp path, parser dispatch, artifact scope checks by function inventory, JUnit evidence, retry flow; `procs.py` complete |
| Scoring and verdict | `cli/scoring.py` inventory path, lane scheduling/folding and scored run flow; `cli/verifying.py` baseline, override, ratchet settlement, main verdict flow, retry, scoped tests and hook; `verify.py` complete |
| Mutation | `mutate.py`, `mutate_pool.py` complete; caller path in `cli/analyses.py`; relevant pool, generator and e2e tests |
| Git and snapshot | `gitio.py` process, staged-read, worktree and HEAD/GitFacts paths; `hook.py` and `snapshot.py` complete; corresponding test inventories |
| Delivery | `action.yml`, `.github/workflows/ci.yml`, `tools/release/release.py` complete; `tools/action/comment.py` input/base-state/output and rendering roles; Action and release test contracts |
| Focused tests run | `tests/unit/test_retest_template.py`, `tests/unit/test_mutate.py`, `tests/unit/test_snapshot.py`: 18 passed |

This is a targeted execution review, not a claim that every branch in every assigned file was exercised. No coverage or verify command ran against the real repository, and no release or outward action ran.

## Replay

Run the probe script with the existing editable installation:

```powershell
python C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\architecture\execution\probes.py
```

All generated files live under that script's `scratch` directory. The pool deletion probe replaces deletion with an observer. The doctor sleep lasts 0.7 seconds and exits itself. Results are saved beside the script in `probe-results.json`.

```powershell
python -m pytest tests/unit/test_retest_template.py tests/unit/test_mutate.py tests/unit/test_snapshot.py -q -p no:randomly
```

The focused test run emitted an environment-level pytest-asyncio fixture-loop deprecation warning and passed all 18 tests. A final `git status --short` returned no changes.
