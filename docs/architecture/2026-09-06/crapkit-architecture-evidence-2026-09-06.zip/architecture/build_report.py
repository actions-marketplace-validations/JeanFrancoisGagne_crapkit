import datetime
import html
import json
import os
from pathlib import Path
import shutil
import zipfile

WORK = Path(__file__).parent
OUT = WORK.parents[1] / 'outputs'
SHA = '20f00e1371334f84aa70bba6f7b23bfc4bdae0f6'
REPO = 'https://github.com/JeanFrancoisGagne/crapkit/blob/' + SHA + '/'
OUT.mkdir(exist_ok=True)

def candidate(id, title, priority, strength, effort, evidence, problem, solution, before, after, files, validation, risk, deletion):
    return dict(id=id,title=title,priority=priority,strength=strength,effort=effort,evidence=evidence,problem=problem,solution=solution,before=before,after=after,files=files,validation=validation,risk=risk,deletion=deletion)

C = [
candidate('trust','Keep trust evidence when pruning runs','P1','Strong','Small to medium',
'Four-run fixture: baseline 1 becomes baseline 4 after prune; failed verify 2 disappears.',
'Retention and baseline selection apply separate rules. Deleting an outstanding failed verify lets later coverage become trusted without a successful verify.',
'Keep the selected baseline and outstanding refusal through the existing store module. Make retention use the same trust decision as verification.',
['Coverage 1 trusted','Verify 2 fails','Coverage 3 + 4','Prune deletes 1 + 2','Coverage 4 becomes trusted'],
['Run history','One trust decision','Preserve baseline + refusal','Prune other eligible runs','Refusal still blocks coverage'],
['src/crapkit/store.py:1268','src/crapkit/store.py:1162','src/crapkit/cli/reports.py:252'],
'Compare baseline, blocker and verdict before and after repeated pruning. Cover failed, crashed and later passing verifies, explicit baselines and no earlier trusted run.',
'Retention may keep more rows. Preserve audit references and digest pairs. During this work, replace repeated baseline scans with one walk only after proving equivalent decisions.',
'Delete retention\'s independent trust assumptions. The existing transactional store remains valuable.'),
candidate('lane-evidence','Make every verdict account for its test evidence','P1','Strong','Small to medium',
'Duplicate lane names lost a failure and produced ok=true. A retry exiting 2 with only an unrelated pass forgave the requested failure.',
'Lane names identify result slots but are not unique. Retry code treats absence from failed IDs as proof of a pass.',
'Reject duplicate lane names at configuration admission. Let the JUnit and retry module forgive only requested tests explicitly recorded as passing in fresh, completed results.',
['Two lanes named unit','One result overwrites another','Retry omits requested test','Missing failure becomes pass'],
['Unique admitted lane names','Every lane result retained','Requested passing ID recorded','Only proven retries forgiven'],
['src/crapkit/config.py:750','src/crapkit/config.py:763','src/crapkit/cli/scoring.py:217','src/crapkit/cli/scoring.py:288','src/crapkit/lanes.py:985','src/crapkit/junitparse.py:43'],
'Drive configuration and verdict together. Test duplicate names, artifact collisions, missing/skipped/failed requested IDs, unrelated passes, partial reports and genuine successful retries.',
'Some accepted configurations will need unique names. Keep zero-test and crashed-worker refusal. Make test ID matching consistent with the original report.',
'Delete duplicate-name accommodations and the requested-minus-failed inference. Callers should consume proven results from the existing seam.'),
candidate('claims','Reserve work atomically','P1','Strong','Medium',
'Two SQLite connections selected the same free function, then both inserted a claim. Two open claims remained.',
'The CLI checks availability, inserts ownership and emits work as separate operations. A second process can take the same path between those steps.',
'Move acquisition into a short transaction owned by the store. Emit only acquired work and continue to another candidate after a conflict.',
['Agent A reads free','Agent B reads free','A inserts claim','B inserts claim','Both receive same work'],
['Rank candidates outside lock','Store reserves exact function','A receives function 1','B receives next free function'],
['src/crapkit/cli/queue.py:59','src/crapkit/cli/queue.py:92','src/crapkit/cli/queue.py:124','src/crapkit/store.py:94','src/crapkit/store.py:875'],
'Use two actual CLI processes with synchronized acquisition. Cover batch conflicts, distinct twins, repeated releases, no-claim reads and a crash after acquisition.',
'Existing duplicate claims need deterministic treatment without losing attempt history. Keep git, ranking and packet enrichment outside the write transaction. Coordinate with ordinal identity.',
'Delete the caller-side check-then-insert protocol. One store transaction gives every process the same ownership rule.'),
candidate('identity','Finish adopting per-function identity','P1','Strong','Medium',
'A CRAP 4 twin closed a CRAP 20 twin\'s claim at ceiling 6. A 10-to-12 twin regression produced a quiet digest. One run returned two history rows for one function.',
'Gates use ordinal identity, but claims, digest, history and parts of explain still merge functions by path and long name.',
'Carry the existing keys.py ordinal through each per-function operation. Use display names when rendering. Preserve deliberately aggregated views.',
['Inventory twins #1 + #2','Gates keep ordinal','Claims drop ordinal','Digest drops ordinal','History combines both'],
['Inventory twins #1 + #2','Existing keys.py rule','Claims keep exact identity','Digest compares exact identity','History selects exact identity'],
['src/crapkit/keys.py:52','src/crapkit/worklist.py:206','src/crapkit/digest.py:134','src/crapkit/store.py:1071','src/crapkit/cli/reports.py:354'],
'Exercise named and anonymous twins across claims, digest, history and explain #2. Check mark, span and test contexts agree. Count ordinals before filtering.',
'Legacy claims lack precise identity. Keep conservative compatibility, first-twin key behavior and current rename semantics. This touches several JSON contracts.',
'Delete local bare-name maps that mean one function. Reuse the identity module already used by gates and ratchet marks.'),
candidate('cache','Include the reader in analysis-cache identity','P1','Strong','Small to medium',
'Unchanged valid .ps1/.sh files: PowerShell long_name is f on cold analysis and f() after a warm cache hit.',
'The reader and extension chain depend on the filename. Cache identity depends only on bytes, so one language can reuse another language\'s records.',
'Include every filename-dependent analysis choice in cache identity. Retain same-reader rename reuse and invalidate the old cache format. Reject malformed cache shapes once at loading.',
['Filename selects reader','Bytes select cache entry','Shell entry reused for PowerShell','Function identity changes'],
['Filename + bytes','Reader-specific cache identity','Compatible records reused','Cold and warm results agree'],
['src/crapkit/analyze.py:153','src/crapkit/analyze.py:333','src/crapkit/analyze.py:360','src/crapkit/cache.py:24','src/crapkit/cache.py:40','src/crapkit/analyze.py:529'],
'Compare complete cold/warm records, metric columns and exported bytes across identical content in different languages and suffix-changing renames. Retain same-reader rename hits and spawned-reader tests.',
'Discarding old cache entries costs one fresh analysis. This changes cache identity, not the metric definition. No real-repository ratchet failure was claimed by this probe.',
'Delete cross-reader reuse. Keep the existing cache depth and warm-run benefit; avoid checks scattered across its consumers.'),
candidate('store-open','Let current stores open without migration writes','P2','Strong','Medium',
'Opening a current store under another connection\'s writer lock failed with database is locked after 5.486 seconds.',
'Read commands run schema setup, seed inserts and migration work on every store open, before optional cache-write protection can help.',
'Give the store a current-schema read path. Keep real upgrades transactional and owned by the same module. Continue treating rollup-cache population as optional.',
['Read command','Schema + seed writes','Migration and restack','Writer lock blocks open','SELECT never starts'],
['Read command','Inspect store shape','Current: read directly','Old: transactional upgrade','Optional cache fill'],
['src/crapkit/store.py:385','src/crapkit/store.py:399','src/crapkit/store.py:496','src/crapkit/store.py:782'],
'Open current stores while a writer holds a lock; cover simultaneous first opens, every old schema fixture, mixed versions, interrupted upgrades and optional rollup fills.',
'A version shortcut must preserve compatibility with older writers. The finding concerns ordinary opens under a writer, not every SQLite workload.',
'Delete recurring setup writes from the no-upgrade path. Preserve atomic migration implementation instead of duplicating it across commands.'),
candidate('pytest-config','Read pytest configuration once, consistently','P2','Strong','Small to medium',
'Four fixtures disagree: empty pytest.ini, .pytest.ini, TOML string testpaths, and a percent character that crashes setup\'s INI reader. An independent pytest 8.3.3 check also found a runtime error for empty .pytest.ini precedence.',
'Setup and runtime each decode pytest settings. Their search order, accepted value shapes and interpolation rules have already diverged.',
'Concentrate pytest configuration precedence and decoding in one existing configuration module. Keep filesystem reading and supplied-text reading as small adapters to the same behavior.',
['Setup reads 3 config names','Runtime reads 5 config names','Different empty-file rule','Different TOML/INI decoding'],
['File adapter or text adapter','One precedence + decoding rule','Setup uses result','Runtime guard uses result'],
['src/crapkit/scaffold.py:201','src/crapkit/scaffold.py:205','src/crapkit/scaffold.py:230','src/crapkit/scaffold.py:252','src/crapkit/config.py:335','src/crapkit/config.py:392'],
'Compare both readers with installed pytest across all five failing fixtures, supported file formats, empty sections and multiple testpaths. Keep the full-suite guard behavior.',
'Setup may generate different commands for previously misread configurations. The runtime reader is not a complete correctness oracle: its empty .pytest.ini precedence also needs repair. Preserve lightweight per-edit imports and nearest-root discovery.',
'Delete the second precedence table and decoder. Two actual adapters justify the seam; another configuration framework does not.'),
candidate('mutation-inputs','Give mutation workers the same checkout','P2','Strong','Medium to large',
'The worker had the changed source but committed tests; the main checkout had changed tests. Cleanup also attempted removal while the pool lock was held.',
'One worker uses the live tree. Parallel workers start at HEAD and copy only files with mutants. Worker count therefore changes the inputs under test.',
'Capture one set of source, tests, configuration and deletions for the run, then prepare workers from that content. Make pool cleanup obey the existing ownership lock.',
['1 worker: live source + tests','Many workers: HEAD checkout','Copy mutated source only','Tests and support remain stale'],
['Capture run inputs once','Prepare isolated workers','Apply one mutant privately','Reuse pool under its lock'],
['src/crapkit/mutate_pool.py:140','src/crapkit/mutate_pool.py:235','src/crapkit/mutate_pool.py:320','src/crapkit/mutate_pool.py:347','src/crapkit/cli/analyses.py:86'],
'Compare outcomes at one and several workers with changed tests, supporting source, config, fixtures and deleted files. Race disposable pool cleanup against a running owner.',
'Input-copy rules must handle ignored build dependencies and preserve performance. Input mismatch is reproduced; its mutation-score delta was not measured. Cleanup probe observed an attempt without deleting a real worker.',
'Remove competing definitions of the measured checkout. Keep private mutants, preflight, deterministic ordering and the retained pool speedup.'),
candidate('mutation-tokens','Generate mutants from executable tokens','P2','Strong','Medium',
'Four spurious mutants came from identifier fragments, an inline comment and a multiline docstring.',
'Mutation generation searches operator strings within line text. Its line-local string mask cannot distinguish all executable code from comments, identifiers and multiline strings.',
'Use code-token eligibility for operators and boolean literals. Exclude unsupported forms until the existing reader can identify them correctly.',
['Raw text line','Substring operator search','Identifier/comment/docstring match','Unnecessary suite execution'],
['Eligible code tokens','Operator or boolean mutation','Changed-code filter','Meaningful suite execution'],
['src/crapkit/mutate.py:38','src/crapkit/mutate.py:117','src/crapkit/mutate.py:141','src/crapkit/mutate.py:167'],
'Cover identifier fragments, inline comments, multiline/escaped strings, intended comparison changes and a true semantic survivor across admitted languages.',
'Preserve intentional mutation coverage and deterministic ordering. Four invalid candidates were measured; full-suite time savings remain unmeasured.',
'Delete invalid candidates before execution. They add test cost without useful evidence. Avoid a new language framework that only relocates substring tables.'),
candidate('coverage-reader','Concentrate coverage decoding in the stream','P2','Strong','Medium',
'A one-file context request used 25.09 MiB peak allocation; selected streaming used 6.02 MiB with equal output. Both custom JSON splitters accepted missing or leading commas.',
'Functions, missing lines and contexts use overlapping decode paths. History materializes every file\'s contexts, and Python missing lines require another artifact pass.',
'Build on the existing streaming reader. Gather the needed projections during decoding, select requested contexts early, and enforce one grammar. Move independent old reader oracles into tests.',
['Artifact','Functions stream','Missing-lines second pass','All-file contexts materialized','Separate grammar implementations'],
['Artifact','One validated streaming walk','Function coverage + missing lines','Requested contexts only','Independent oracle in tests'],
['src/crapkit/cli/reports.py:437','src/crapkit/coverage_py.py:123','src/crapkit/covstream.py:343','src/crapkit/covstream.py:83','src/crapkit/coverage_istanbul.py:56'],
'Compare records, warnings, hashes, missing sets and selected contexts. Exercise malformed commas, small chunk boundaries, UTF-8 splits and path normalization. Prove Python artifact read counts.',
'Synthetic artifact: 5,000 files, 3.01 MiB. Timings under tracemalloc were 0.2243s and 0.0749s, one run each. These are not RSS or production benchmarks. Preserve missing-line intersections across lanes.',
'Delete parallel whole-document orchestration and the second Python decode. Keep streaming and pure per-file attribution; use no new parser dependency without evidence.'),
candidate('twins-cost','Filter twin candidates before building results','P2','Strong','Small',
'25,000 unrelated indexed functions created 25,000 dictionaries, returned zero twins, and used 7.27 MiB transient Python allocation.',
'Every brief constructs payloads for candidates that its similarity test immediately rejects. Batch reuse saves index construction but repeats this avoidable allocation.',
'Apply the existing similarity qualification before creating payload dictionaries. Preserve ranking, rounding and the final top cut.',
['Shared shingle index','Build 25,000 payloads','Filter similarity','Return zero twins'],
['Shared shingle index','Filter similarity','Build qualifying payloads','Same ranked results'],
['src/crapkit/dup.py:172','src/crapkit/dup.py:207','src/crapkit/cli/queue.py:510','src/crapkit/cli/queue.py:549'],
'Compare complete results near similarity rounding edges, ties, containment and top cuts. Count payload creation on unrelated candidates and repeat the allocation probe.',
'The synthetic measurement excludes index construction and source loading. It does not establish that this step dominates real brief latency.',
'Delete rejected payload construction. Keep the shared batch index and existing result interface.'),
candidate('process-owner','Use one owner for subprocess deadlines','P2','Strong','Small',
'Doctor\'s 0.1-second deadline returned after 0.753 seconds when the child slept 0.7 seconds. The probe self-exited.',
'Doctor uses shell=True with captured pipes and a separate timeout path. Killing the shell does not close the child\'s inherited output handles.',
'Use the existing bounded process module with a small temporary output file. Keep doctor\'s parsing and memoization in place.',
['Doctor creates shell','Shell creates interpreter','Deadline kills shell','Inherited pipe waits for child'],
['Doctor asks bounded module','Module owns process tree','Deadline kills descendants','Doctor reads bounded output'],
['src/crapkit/cli/admin.py:851','src/crapkit/procs.py:56','src/crapkit/procs.py:121'],
'Test normal reports, absent runners, deadline overruns and surviving descendants at the real doctor seam on both supported OS families.',
'Preserve normal captured output and lazy startup. Related argument issue: a Windows retry test ID containing %VAR% was expanded by cmd.exe; fix argument transport before interpreting retry results.',
'Delete the local timeout implementation. Reuse the process owner already shared by lanes and mutations.'),
candidate('retire','Retire obsolete production reachability','P3','Strong','Small to medium',
'CLI exports 365 names, including 336 private names. 32 test files import 67 private names. discover.py has no production importer and has 384 implementation lines plus 480 dedicated test lines.',
'A compatibility map exposes old internals mainly for tests. Retired discovery and two-pass analysis code still ship despite having no known production callers.',
'Move internal tests to their owning module or the surviving command interface, then reduce the CLI export map. Remove unwired discovery unless a concrete product need is chosen. Keep independent two-pass analysis oracles in test support.',
['365-name CLI facade','Private implementation names','Tests maintain export map','Unwired discovery ships','Old analysis oracle ships'],
['CLI entry points stay lazy','Tests use owning seam','Private export map shrinks','Unused discovery removed','Oracle stays in tests'],
['src/crapkit/cli/__init__.py:16','src/crapkit/cli/__init__.py:386','src/crapkit/cli/parser.py:26','src/crapkit/discover.py:1','src/crapkit/merge.py:1','tests/unit/test_discover.py:12'],
'Keep entry-point and lazy-load tests, independent one-pass comparison and recorded goldens. Check documented Python compatibility before removing exports. Re-run exact affected command behavior.',
'No production caller is a repository finding, not proof that no external Python consumer exists. Avoid mixing all deletions into one large change. Discovery naming is distinct from live nearest-root discovery.',
'Deleting unused reachability removes work instead of moving it. Retain lazy command dispatch and the actual FunctionRecord type.'),
]

C[2], C[3] = C[3], C[2]
inventory = json.loads((WORK/'inventory.json').read_text())
def esc(value): return html.escape(str(value), quote=True)
def refs(files):
    result=[]
    for ref in files:
        path,line = ref.rsplit(':',1)
        result.append(f'<a href="{REPO}{esc(path)}#L{line}" target="_blank" rel="noreferrer">{esc(ref)}</a>')
    return ''.join(result)
def flow(items,after=False):
    return '<div class="flow '+('after' if after else 'before')+'">' + ''.join(f'<div class="node">{esc(item)}</div>' + ('<div class="arrow" aria-hidden="true">↓</div>' if i<len(items)-1 else '') for i,item in enumerate(items)) + '</div>'
def card(c,index):
    return f'''<article id="{c['id']}" class="candidate">
      <div class="card-head"><span class="number">{index:02}</span><div><div class="badges"><span class="badge">{c['strength']}</span><span>{c['priority']}</span><span>{c['effort']} scope</span></div><h2>{esc(c['title'])}</h2></div></div>
      <p class="evidence">{esc(c['evidence'])}</p>
      <div class="diagrams"><section><h3>Before</h3>{flow(c['before'])}</section><section><h3>After</h3>{flow(c['after'],True)}</section></div>
      <div class="prose-grid"><section><h3>Problem</h3><p>{esc(c['problem'])}</p></section><section><h3>Change</h3><p>{esc(c['solution'])}</p></section></div>
      <div class="deletion"><h3>Deletion test</h3><p>{esc(c['deletion'])}</p></div>
      <details><summary>Evidence, validation and tradeoffs</summary><div class="refs">{refs(c['files'])}</div><h3>Validate through the existing interface</h3><p>{esc(c['validation'])}</p><h3>Risk and limits</h3><p>{esc(c['risk'])}</p></details>
    </article>'''

style = '''
:root{--ink:#182a30;--muted:#52666c;--line:#cedbd9;--paper:#f5f4ef;--accent:#146e5c;--dark:#153e36;--red:#a34535}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}main{max-width:1160px;margin:auto;padding:60px 38px 80px}h1,h2,h3,p{margin:0}h1{font:clamp(42px,6vw,72px)/1.04 Georgia,serif;letter-spacing:-2px;max-width:950px;margin:16px 0 24px}h2{font:30px/1.16 Georgia,serif;letter-spacing:-.5px}h3{font-size:12px;text-transform:uppercase;letter-spacing:1.1px;margin:0 0 9px;color:var(--muted)}p+p{margin-top:12px}a{color:var(--accent);text-decoration-thickness:1px;text-underline-offset:3px}.eyebrow{font-size:12px;letter-spacing:1.7px;text-transform:uppercase;color:var(--accent);font-weight:700}.lede{max-width:810px;font-size:20px;line-height:1.5}.meta{display:flex;gap:24px;flex-wrap:wrap;color:var(--muted);font-size:13px;margin-top:28px;padding:20px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin:28px 0 40px}.stat{padding:16px 0;border-bottom:3px solid var(--accent)}.stat b{font:32px/1.2 Georgia,serif;display:block}.stat span{font-size:12px;color:var(--muted)}.top{background:var(--dark);color:#fff;padding:30px;border-radius:4px;margin:32px 0}.top h2{margin:5px 0 12px}.top h3{color:#b7d9ce}.top a{color:#d1ede2}.top p{max-width:900px}.section-title{margin:44px 0 20px}table{width:100%;border-collapse:collapse;font-size:14px}th{text-align:left;font-size:11px;letter-spacing:.8px;text-transform:uppercase;color:var(--muted)}th,td{padding:13px 10px;border-bottom:1px solid var(--line);vertical-align:top}td:first-child,th:first-child{padding-left:0}.candidate{margin-top:28px;background:#fff;border:1px solid var(--line);padding:32px;scroll-margin-top:20px;border-radius:5px}.card-head{display:flex;gap:18px}.number{font:38px/1 Georgia,serif;color:#a3b6b0}.badges{display:flex;align-items:center;gap:12px;margin-bottom:10px;font-size:11px;text-transform:uppercase;letter-spacing:.7px;color:var(--muted)}.badge{background:#dcece5;color:#185542;padding:4px 8px;border-radius:3px;font-weight:700}.evidence{margin:20px 0;font-size:16px;color:#234e42;background:#edf4ef;border-left:3px solid var(--accent);padding:12px 16px}.diagrams{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin:26px 0}.diagrams>section{background:#f7f8f5;border:1px solid #e1e7e2;padding:20px;min-width:0}.flow{display:flex;flex-direction:column;align-items:center}.node{width:100%;max-width:380px;border:1px solid #bfcac6;background:white;text-align:center;padding:9px 12px;font-size:13px;line-height:1.25}.before .node:last-child{border-color:#ce8b7e;color:var(--red);background:#fdf1ed}.after{padding:10px;border:2px solid var(--accent);background:#e9f1ec}.after .node{border-color:#a7c6b8}.after .node:last-child{background:var(--dark);color:white;border-color:var(--dark)}.arrow{font-size:15px;color:#71877d;line-height:20px}.prose-grid{display:grid;grid-template-columns:1fr 1fr;gap:28px;font-size:15px}.deletion{border-left:2px dashed #80998f;padding-left:16px;margin-top:22px;font-size:14px}details{margin-top:22px;border-top:1px solid var(--line);padding-top:14px;font-size:14px}summary{cursor:pointer;color:var(--accent);font-weight:600}details h3{margin-top:18px}.refs{display:flex;gap:6px 15px;flex-wrap:wrap;margin:14px 0}.refs a{font:11px/1.7 ui-monospace,Consolas,monospace}.note{font-size:13px;color:var(--muted)}.columns{display:grid;grid-template-columns:1fr 1fr;gap:24px}.panel{background:#fff;border:1px solid var(--line);padding:24px}.panel p{font-size:14px}.mermaid{font-size:12px;overflow:auto;background:#fff;padding:18px;border:1px solid var(--line)}.coverage td{font-size:12px}.coverage td:last-child{font-family:ui-monospace,Consolas,monospace;overflow-wrap:anywhere}footer{padding-top:28px;margin-top:45px;border-top:1px solid var(--line);font-size:12px;color:var(--muted)}code{font-size:.9em;background:#e9ede7;padding:1px 4px}li{margin-bottom:8px}@media(max-width:700px){main{padding:30px 18px}.stats{grid-template-columns:1fr 1fr}.diagrams,.prose-grid,.columns{grid-template-columns:1fr}.candidate{padding:20px}h2{font-size:25px}.badges{flex-wrap:wrap;gap:7px}.meta{gap:10px}.table-wrap{overflow:auto}}@media print{body{background:white}main{max-width:none;padding:10px}.candidate{break-inside:avoid}details>summary{display:none}details>*{display:block}.candidate{margin-top:16px}.top{print-color-adjust:exact}.diagrams{break-inside:avoid}a{color:inherit}.mermaid{display:none}}
'''

style += 'body h1{font:clamp(42px,6vw,72px)/1.04 Georgia,serif;letter-spacing:-2px;max-width:950px;margin:16px 0 24px}body h2{font:30px/1.16 Georgia,serif;letter-spacing:-.5px}body h3{font-size:12px;text-transform:uppercase;letter-spacing:1.1px;margin:0 0 9px;color:var(--muted)}body .top h3{color:#b7d9ce}@media(max-width:700px){body h2{font-size:25px}}'
rows=''.join(f'<tr><td>{i:02}</td><td><a href="#{c["id"]}">{esc(c["title"])}</a></td><td>{c["priority"]}</td><td>{c["effort"]}</td></tr>' for i,c in enumerate(C,1))
coverage = [
('Analysis and coverage','Traced core flows; sampled custom language-reader internals','analyze, cache, score, universe, merge, covstream, coverage_py, coverage_istanbul, uncovered, lizard readers, _pygdefer'),
('History and ranking','Traced core flows and query contracts','churn, churn_log, churn_cache, coupling, coupling_cache, dup, worklist, packet'),
('State and verdicts','Traced trust, identity, claims, retention, migration and verdict flows','store, keys, ratchet, ratchet_report, verify, override, snapshot, diffparse, gitio'),
('Execution','Traced lane lifecycle, retry, mutation and process paths','lanes, junitparse, procs, mutate, mutate_pool, hook'),
('Commands and setup','Inspected all CLI families; traced setup, reader and probe ownership','cli/*, config, scaffold, doctor, rootfind, repotext, invocation, watch, discover, errors'),
('Output and integration','Traced payload/render paths; inspected MCP protocol/registry and docs contracts','report, digest, sarif, sarifio, mcp_server, plugin manifests/hooks/skills, server.json'),
('Delivery and tests','Inspected workflows, Action, release script and test structure; demo content sampled','action.yml, .github/workflows, tools/action, tools/release, tools/demo, pyproject.toml, Dockerfile, docs')]
coverage_rows=''.join('<tr>'+''.join(f'<td>{esc(v)}</td>' for v in row)+'</tr>' for row in coverage)
page=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>crapkit architecture review | 0.6.0</title><script src="https://cdn.tailwindcss.com"></script><style>{style}</style><script type="module">import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs';mermaid.initialize({{startOnLoad:true,theme:'neutral',securityLevel:'strict'}});</script></head><body><main>
<header><div class="eyebrow">Architecture review · 6 September 2026 · crapkit 0.6.0</div><h1>Protect the verdict.<br>Then remove the extra work.</h1><p class="lede">The strongest opportunities repair shared decisions that have split across modules. Keep the existing scoring core, lazy commands and streaming work. Concentrate trust, identity and execution evidence, then delete code that callers no longer need.</p><div class="meta"><span>Reviewed commit <code>{SHA[:12]}</code></span><span>Whole-project map, focused behavioral probes</span><span>Repository unchanged</span><span>Local review, no publication or release</span></div></header>
<div class="stats"><div class="stat"><b>64</b><span>production Python files</span></div><div class="stat"><b>23,294</b><span>production lines, including comments</span></div><div class="stat"><b>13</b><span>ranked opportunities</span></div><div class="stat"><b>3,005</b><span>unit tests passed; 1 failed; 8 skipped</span></div></div>
<section class="top"><h3>Top recommendation</h3><h2>Start with trust and test evidence.</h2><p><a href="#trust">Preserve the baseline and outstanding failed verify during pruning</a>. Follow with <a href="#lane-evidence">unique lane names and proof of retry passes</a>. Those changes stop successful verdicts from being built on missing evidence. Complete ordinal identity before enforcing exclusive claims for exact functions.</p></section>
<h2 class="section-title">A short sequence of independent changes</h2><div class="table-wrap"><table><thead><tr><th>Order</th><th>Opportunity</th><th>Priority</th><th>Relative scope</th></tr></thead><tbody>{rows}</tbody></table></div><p class="note" style="margin-top:12px">P1 affects trust, function identity or ownership. P2 addresses reliability and repeated work. P3 removes maintenance burden. Scope is a comparative judgment, not a delivery estimate. Strong means direct evidence supports doing the work; it does not mean every branch has been tested.</p>
<h2 class="section-title">Concentrate existing rules</h2><pre class="mermaid">flowchart LR
  CLI[CLI adapter] --> Decisions[Trust, identity and execution decisions]
  MCP[MCP adapter through CLI] --> Decisions
  Decisions --> Store[Snapshot store]
  Decisions --> Readers[Analysis and artifact readers]
  Decisions --> Processes[Bounded execution]
  style Decisions fill:#153e36,color:#fff,stroke:#153e36
</pre><p class="note">Direction for the review, not a proposed new interface. The candidate diagrams show responsibility changes. Solid boxes are modules or their internal steps. The dark box shows the result protected by the deepened module. Dashed rules mark the deletion test.</p>
{''.join(card(c,i) for i,c in enumerate(C,1))}
<h2 class="section-title">Keep the parts that already earn their keep</h2><div class="columns"><section class="panel"><h3>Useful depth</h3><p>The existing keys and scope-ownership modules centralize real rules. One-pass lizard analysis, streaming coverage, exact-start joins, shared batch indexes, git-fact caching and per-run rollups already remove repeated work. Retained mutation worktrees avoid rebuilding checkouts.</p></section><section class="panel"><h3>Contracts worth preserving</h3><p>Keep monotonic ratchet marks, deterministic git-anchored output, module-scope reader registration, bounded process-tree cleanup, lazy command imports and contract tests over real CLI payloads. ADR 0001 preserves tool-result errors; ADR 0002 preserves nearest-root discovery. None of these candidates requires reopening either ADR.</p></section></div>
<h2 class="section-title">Further checks, with lower confidence</h2><table><thead><tr><th>Area</th><th>What the review established</th><th>Next evidence needed</th></tr></thead><tbody>
<tr><td>Baseline history cost</td><td>500 / 1,000 / 2,000 synthetic runs took 3.898 / 15.746 / 67.538 ms. Repeated candidate scans explain the growth.</td><td>Fold into trust work, prove equivalent decisions, then measure real retained history.</td></tr>
<tr><td>MCP schemas</td><td>Active and dormant worklist item schemas contain an identical 1,964-character object. Keep the wire definition and prose stable during the planned description round.</td><td>Reuse identical internal schema fragments only. A new schema framework or direct in-process MCP executor is not justified by this review.</td></tr>
<tr><td>CLI admin</td><td>1,662 lines, 132 functions, 17 touches in 150 non-merge commits. Setup, doctor and watch share one command-family module.</td><td>Consolidate concrete duplicated pytest/probe behavior first. File size alone does not justify another split.</td></tr>
<tr><td>CI</td><td>Six OS/Python combinations run the unit/e2e pair; dogfood runs the configured suite again. Hook smoke on an unstaged tree checks startup, not a changed-code gate.</td><td>Measure current job durations and demonstrate changed-code gating before reducing matrix coverage or claiming savings.</td></tr>
<tr><td>Action re-entry</td><td>Fixed temporary filenames and an uncleared base SHA can mix state if the Action runs twice in one job.</td><td>Run a disposable sequential-invocation fixture. This scenario was inspected, not executed.</td></tr>
<tr><td>Release prerequisites</td><td>Clean/pushed-main requirements are described, while stage execution can be invoked independently. Stage 1 includes broad staging.</td><td>Use disposable release-state fixtures to enforce prerequisites. No release was attempted in this review.</td></tr>
<tr><td>Argument transport</td><td>A retry ID containing a percent-delimited variable reached Windows cmd.exe with the variable expanded. Scoped-test paths use similar quoting.</td><td>Prove literal argument preservation for both call sites on Windows and POSIX. No arbitrary-command exploit was attempted.</td></tr>
</tbody></table>
<h2 class="section-title">Validation and limits</h2><div class="columns"><section class="panel"><h3>What ran</h3><p>The complete unit suite ran against the reviewed checkout: <strong>3,005 passed, 1 failed, 8 skipped</strong> in 120.26 seconds. Eighteen additional focused tests passed. Temporary probes exercised trust, claims, identity, reader behavior, cache identity, lane evidence, mutation preparation and deadlines.</p><p>The one failing unit test hardcodes the POSIX command <code>true</code>. It failed again alone on Windows. An isolated copy passed after replacing only that command with the current Python interpreter running <code>pass</code>. The repository test remains unchanged.</p></section><section class="panel"><h3>What this does not establish</h3><p>The review did not run the full e2e suite, production coverage or verify, publish a release, or modify source code. Synthetic allocation figures are Python allocations under tracemalloc, not process RSS. Existing production performance and the full language-parser grammar were not benchmarked or exhaustively audited.</p><p>The review maps the entire project and follows high-risk caller paths. It does not claim line-by-line validation of all 434 tracked files. Scripts, raw observations, per-area reports and the decision log are in the evidence bundle.</p></section></div>
<h2 class="section-title">Review coverage</h2><table class="coverage"><thead><tr><th>Area</th><th>Depth</th><th>Modules and paths</th></tr></thead><tbody>{coverage_rows}</tbody></table>
<footer>Source checkout: C:\\Users\\jfgag\\crapkit · Pinned source links use commit {SHA}.<br>Report source and raw evidence: <a href="crapkit-architecture-evidence-2026-09-06.zip">crapkit-architecture-evidence-2026-09-06.zip</a>. Every candidate is a review recommendation; implementation is separate work.<br>Local report generated on {datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}. Diagram styling works offline; Tailwind and the overview Mermaid graph load from CDNs.</footer>
</main></body></html>'''

target=OUT/'crapkit-architecture-review-2026-09-06.html'
target.write_text(page,encoding='utf-8')
temp=Path(os.environ.get('TEMP',str(OUT)))/('architecture-review-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'.html')
shutil.copyfile(target,temp)
(OUT/'crapkit-architecture-candidates-2026-09-06.json').write_text(json.dumps(C,indent=2),encoding='utf-8')
bundle=OUT/'crapkit-architecture-evidence-2026-09-06.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as archive:
    for path in WORK.rglob('*'):
        if path.is_file() and path.suffix in ('.py','.md','.json','.tsv','.txt','.log') and not any(part in ('scratch','cache-fixture','__pycache__') for part in path.relative_to(WORK).parts) and path.name != 'synthetic-coverage.json':
            archive.write(path,'architecture/'+path.relative_to(WORK).as_posix())
    archive.write(target,target.name)
    archive.write(OUT/'crapkit-architecture-candidates-2026-09-06.json','candidates.json')
print(json.dumps({'report':str(target),'temp_copy':str(temp),'bundle':str(bundle),'candidates':len(C),'html_bytes':target.stat().st_size},indent=2))
