import csv
import datetime
import pathlib
import sys

target = pathlib.Path(__file__).parent / 'decisions.tsv'
exists = target.exists()
with target.open('a', encoding='utf-8', newline='') as handle:
    writer = csv.writer(handle, delimiter='\t', lineterminator='\n')
    if not exists:
        writer.writerow(['ts','phase','decision','why','evidence','result'])
    values = [datetime.datetime.now(datetime.timezone.utc).isoformat()] + sys.argv[1:]
    values = [value.replace('\t',' ').replace('\n',' ') for value in values]
    writer.writerow(["'" + value if value[:1] in '=+-@' else value for value in values])
