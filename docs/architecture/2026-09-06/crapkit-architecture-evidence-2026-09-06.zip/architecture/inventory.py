import ast
import collections
import json
import pathlib
import subprocess

ROOT = pathlib.Path(r'C:\Users\jfgag\crapkit')
OUT = pathlib.Path(__file__).parent
files = subprocess.check_output(['git', 'ls-files'], cwd=ROOT, text=True).splitlines()
modules = []
for rel in files:
    if not rel.endswith('.py'):
        continue
    source = (ROOT / rel).read_text(encoding='utf-8-sig')
    tree = ast.parse(source)
    functions = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            imports.append({'module': node.module, 'level': node.level, 'names': [a.name for a in node.names], 'line': node.lineno})
    modules.append({'path': rel, 'lines': len(source.splitlines()), 'functions': len(functions), 'private_functions': sum(f.name.startswith('_') for f in functions), 'imports': imports})
history = subprocess.check_output(['git','log','-150','--no-merges','--format=','--name-only'], cwd=ROOT, text=True)
churn = collections.Counter(p for p in history.splitlines() if p)
summary = {'commit': subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(), 'tracked_files': len(files), 'python_files': len(modules), 'production': {'files': sum(m['path'].startswith('src/') for m in modules), 'lines': sum(m['lines'] for m in modules if m['path'].startswith('src/')), 'functions': sum(m['functions'] for m in modules if m['path'].startswith('src/'))}, 'tests': {'files': sum(m['path'].startswith('tests/') for m in modules), 'lines': sum(m['lines'] for m in modules if m['path'].startswith('tests/'))}, 'hotspots': churn.most_common(40), 'modules': modules}
(OUT / 'inventory.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k != 'modules'}, indent=2))
print('Largest production modules:', [(m['path'],m['lines'],m['functions']) for m in sorted(modules,key=lambda m:m['lines'],reverse=True) if m['path'].startswith('src/')][:15])
