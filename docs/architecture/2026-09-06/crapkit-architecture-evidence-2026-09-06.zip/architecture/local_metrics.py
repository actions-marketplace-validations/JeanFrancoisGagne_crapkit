import ast
import collections
import json
from pathlib import Path

ROOT = Path(r'C:\Users\jfgag\crapkit')
from crapkit.cli import _OWNER
from crapkit.mcp_server import TOOLS

sources = list((ROOT / 'src').rglob('*.py'))
tests = list((ROOT / 'tests').rglob('*.py'))
facade_users = []
for path in sources + tests:
    tree = ast.parse(path.read_text(encoding='utf-8-sig'))
    names = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module == 'crapkit.cli':
            names.extend(a.name for a in node.names if a.name.startswith('_'))
    if names:
        facade_users.append({'path':str(path.relative_to(ROOT)), 'names':names})
counts = collections.Counter()
examples = {}
def walk(value, location):
    if isinstance(value, dict):
        serial = json.dumps(value, sort_keys=True)
        if 'type' in value and len(serial) >= 180:
            counts[serial] += 1
            examples.setdefault(serial, []).append(location)
        for key, item in value.items():
            walk(item, location + '/' + key)
    elif isinstance(value, (tuple,list)):
        for index,item in enumerate(value):
            walk(item, location + '/' + str(index))
for tool in TOOLS:
    walk(tool['output'], tool['name'])
duplicates = [{'copies':c,'chars':len(s),'locations':examples[s], 'prefix':s[:120]} for s,c in counts.most_common() if c > 1]
result = {'facade_export_count':len(_OWNER), 'facade_private_count':sum(n.startswith('_') for n in _OWNER), 'private_facade_import_files':len(facade_users), 'private_facade_imports':sum(len(f['names']) for f in facade_users), 'facade_users':facade_users, 'duplicated_schema_nodes':duplicates, 'discover_production_imports':[str(p.relative_to(ROOT)) for p in sources if p.name != 'discover.py' and 'discover import' in p.read_text(encoding='utf-8-sig')]}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['facade_users','duplicated_schema_nodes']}, indent=2))
print(json.dumps(duplicates[:12],indent=2))
