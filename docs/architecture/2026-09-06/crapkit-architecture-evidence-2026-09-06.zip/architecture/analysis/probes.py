import json
import sys
from pathlib import Path

sys.path.insert(0, r'C:\Users\jfgag\crapkit\src')
from crapkit.analyze import analyze_files, analyze_source

base = Path(__file__).parent
fixture = base / 'cache-fixture'
fixture.mkdir(exist_ok=True)
examples = [
    'function f() {\n    return 0\n}\n',
    'function f() {\n    # if comment\n    return 0\n}\n',
    'def f(x):\n    return x if x else 0\n',
]
for i, code in enumerate(examples):
    print('EXAMPLE', i)
    for suffix in ['.sh', '.ps1', '.js', '.py']:
        print(suffix, [r._asdict() for r in analyze_source('f' + suffix, code)])

code = examples[0]
paths = ['same.sh', 'same.ps1']
for rel in paths:
    (fixture / rel).write_text(code, encoding='utf-8')
(fixture / '.crapkit' / 'stat-stamps.json').unlink(missing_ok=True)
cold, _, cache = analyze_files(fixture, paths, cache={})
warm, hits, _ = analyze_files(fixture, paths, cache=cache)
print('COLD', cold)
print('WARM', warm)
print('EQUAL', cold == warm, 'HITS', hits)

from crapkit.coverage_istanbul import split_top_level
from crapkit.covstream import _Window, split_window
from io import BytesIO
for text in ['{"a": {} "b": {}}', '{,"a": {}}']:
    try:
        json.loads(text)
        strict = 'accepted'
    except ValueError:
        strict = 'rejected'
    print('JSON', repr(text), strict, list(split_top_level(text)), list(split_window(_Window(BytesIO(text.encode()), 4))))

stamps = fixture / '.crapkit' / 'stat-stamps.json'
stamps.parent.mkdir(exist_ok=True)
for value in [[], {'same.sh': [1]}, {'same.sh': 1}]:
    stamps.write_text(json.dumps({'v': 1, 'stamps': value}), encoding='utf-8')
    try:
        analyze_files(fixture, ['same.sh'], cache=cache)
        result = 'accepted'
    except Exception as exc:
        result = f'{type(exc).__name__}: {exc}'
    print('STAMP', value, result)

from crapkit.analyze import load_cache
cachefile = fixture / 'bad-cache.json'
for value in [[], {'fp': 'x', 'entries': []}, {'fp': 'x', 'entries': [1]}]:
    cachefile.write_text(json.dumps(value), encoding='utf-8')
    try:
        result = load_cache(cachefile)
    except Exception as exc:
        result = f'{type(exc).__name__}: {exc}'
    print('CACHE', value, result)
