import gc
import json
import sys
import time
import tracemalloc
from pathlib import Path

sys.path.insert(0, r'C:\Users\jfgag\crapkit\src')
from crapkit.coverage_py import parse_coveragepy_contexts, _line_contexts
from crapkit.covstream import _Window, walk_report
from crapkit.dup import FunctionIndex, find_twins
from crapkit.snapshot import InventoryRow
import crapkit.dup as dup

base = Path(__file__).parent
path = base / 'synthetic-coverage.json'
data = {'contexts': {str(i): [f'tests/test_a.py::test_{j}|run' for j in range(3)] for i in range(1, 7)}}
path.write_text(json.dumps({'meta': {'branch_coverage': True}, 'files': {f'src/f{i}.py': data for i in range(5000)}}), encoding='utf-8')

def current_contexts():
    return parse_coveragepy_contexts(path.read_text(encoding='utf-8'), path_prefix='').get('src/f0.py', {})

def stream_selected_contexts():
    selected = {}
    with path.open('rb') as handle:
        for key, value, kind in walk_report(_Window(handle), 'files'):
            if kind == 'sub' and key == 'src/f0.py':
                selected = _line_contexts(value.get('contexts', {}))
    return selected

def measure(work):
    gc.collect()
    tracemalloc.start()
    start = time.perf_counter()
    result = work()
    elapsed = time.perf_counter() - start
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return result, {'seconds_under_tracemalloc': round(elapsed, 4), 'peak_python_mb': round(peak / 2**20, 2)}

a, am = measure(current_contexts)
b, bm = measure(stream_selected_contexts)
print('CONTEXTS', json.dumps({'files': 5000, 'artifact_mb': path.stat().st_size / 2**20, 'same_output': a == b, 'whole': am, 'selected_stream': bm}))

source = 'def target():\n' + '\n'.join(f'    value{i} = call({i})' for i in range(10)) + '\n'
target = InventoryRow('src', 'target.py', 'target', 1, 11, 1, 1, 1, 11, 0, 0)
rows = [InventoryRow('src', f'other{i}.py', f'other{i}', 1, 11, 1, 1, 1, 11, 0, 0) for i in range(25000)]
index = FunctionIndex(8, [(r, {i}) for i, r in enumerate(rows)])
payloads = 0
original = dup._twin_payload
def counted(*args):
    global payloads
    payloads += 1
    return original(*args)
dup._twin_payload = counted
twins, tm = measure(lambda: find_twins(target, rows, {'target.py': source}, indexed=index))
print('TWINS', json.dumps({'candidate_functions': len(rows), 'payloads_created': payloads, 'returned_twins': len(twins), 'measurements': tm}))
