# Analysis and scoring architecture review

Reviewed clean HEAD `20f00e1371334f84aa70bba6f7b23bfc4bdae0f6`. No repository files changed. No coverage, verify, or full test suite ran. All measurements below use isolated synthetic fixtures under this directory.

## Ranked candidates

| Rank | Candidate | Evidence class | Expected benefit | Cost / risk |
| --- | --- | --- | --- | --- |
| 1 | Make analysis cache identity include the reader choice | Demonstrated correctness defect | Cold and warm runs keep the same function identity and metrics | Small to medium; invalidate existing cache format and preserve same-language rename hits |
| 2 | Put coverage artifact decoding and projections behind one reader implementation | Demonstrated duplicated work, measured synthetic cost, demonstrated malformed-JSON acceptance | Less memory for function history, fewer repeated artifact passes, fewer parser behaviors to maintain | Medium; preserve warnings, path rebasing, hash bytes, malformed-input refusal, and missing-line intersections |
| 3 | Build twin payloads only for candidates that qualify | Measured unnecessary allocations | Less transient allocation for every brief, multiplied across batch packets | Small; preserve rounding, ordering, ties, nested-span labels, and top cut |
| 4 | Remove the retired two-pass analysis machinery from production | Demonstrated lack of production callers | Smaller production surface and clearer ownership of analysis records | Small; retain the independent two-pass test oracle in test support |

## 1. Analysis cache identity loses the language

**Finding:** identical source bytes do not imply identical analysis. The chosen reader and extension chain depend on the filename, but cache entries depend only on the source hash. A cold run can therefore disagree with the next warm run on an unchanged tree.

| Evidence | Location |
| --- | --- |
| Analysis chooses its reader using the filename | `src/crapkit/analyze.py:333`, `src/crapkit/analyze.py:342` |
| Extension chain also depends on suffix | `src/crapkit/analyze.py:152` |
| Digest includes only bytes | `src/crapkit/analyze.py:360` |
| Lookup uses only the digest | `src/crapkit/cache.py:23` |
| Cache construction overwrites equal-digest entries in sorted path order | `src/crapkit/cache.py:40` |
| A hit only changes the stored path, retaining the other language's name and values | `src/crapkit/analyze.py:529` |
| Inventory and coverage use the cache through the same path | `src/crapkit/cli/scoring.py:61`, `src/crapkit/cli/scoring.py:83` |

The probe writes the same valid declaration to `same.ps1` and `same.sh`:

```text
function f() {
    return 0
}
```

| Run | PowerShell long_name | Shell long_name |
| --- | --- | --- |
| Cold | `f` | `f()` |
| Warm, two cache hits | `f()` | `f()` |

This changes the PowerShell function's stored identity without changing its source. Name-based coverage overlays and ratchet lookup consume that identity. The probe establishes the identity error; it does not claim a real repository's ratchet has already failed because of it.

Before diagram: `filename + bytes -> language-specific analysis -> byte-hash-only cache -> records restamped to any matching path`.

After diagram: `filename + bytes -> reader-specific cache identity -> matching records -> path restamp within that reader`.

Proposed change: make the cache distinguish every filename-dependent analysis choice. Retain sharing for renames and copies analyzed by the same reader. Retire the old cache format. This repairs cache identity; it does not change what a metric measures.

Deletion test: deleting caching entirely removes the discrepancy but forfeits the existing warm-run speedup. Deleting cross-reader cache reuse removes behavior no caller needs. Same-reader rename reuse remains useful and has direct tests.

Validation: first add a failing public `analyze_files` test for the two-file fixture, cold/warm equality, and a suffix-changing rename. Keep existing unchanged-file, same-language rename, empty-entry, partial-merge, stat-settling, and spawned-reader tests. Verify that names, counts, all metric columns, and exported bytes remain equal between cold and warm analysis.

Related cache defect worth fixing at the same ownership point: disposable cache contents are not fully shape-checked. `load_cache` raises `AttributeError` for valid JSON `[]`, and for `{"fp":"x","entries":[1]}`. A stat index with `{"v":1,"stamps":[]}` also raises `AttributeError`; `{"v":1,"stamps":{"same.sh":1}}` raises `TypeError`. Evidence: `src/crapkit/analyze.py:384`, `src/crapkit/analyze.py:445`, `src/crapkit/analyze.py:488`; reproduced in `probes-output.txt`. Existing corrupt-index coverage only supplies truncated JSON at `tests/unit/test_analyze_warm_path.py:209`. Treat malformed cache shapes as misses where they enter the system. Avoid adding guards to every downstream lookup.

## 2. Coverage decoding remains split across parallel implementations

**Finding:** the streaming reader is already the successful implementation for scoring, but function-history contexts still materialize the whole artifact and every file's contexts. Python missing lines also get a second pass after scoring. String-based score/missing readers remain in production for tests, and grammar handling differs between full JSON and the custom splitters.

| Caller flow | Source evidence |
| --- | --- |
| Function history -> `_contexts_for_path` -> read whole file -> `parse_coveragepy_contexts` -> retain only one path | `src/crapkit/cli/reports.py:437`, `src/crapkit/coverage_py.py:123` |
| Python lane -> parse functions and hash -> later missing-lines walk | `src/crapkit/lanes.py:643`, `src/crapkit/covstream.py:343`, `src/crapkit/uncovered.py:180`, `src/crapkit/covstream.py:361` |
| Istanbul lane already obtains functions, dead lines, and hash together | `src/crapkit/lanes.py:658`, `src/crapkit/covstream.py:255` |
| Production text score/missing reader declarations have no production callers | `src/crapkit/coverage_py.py:103`, `src/crapkit/coverage_py.py:148`, `src/crapkit/coverage_istanbul.py:202`, `src/crapkit/coverage_istanbul.py:214` |
| Both custom splitters inherit an optional comma before every member | `src/crapkit/coverage_istanbul.py:56`, `src/crapkit/coverage_istanbul.py:68`, `src/crapkit/covstream.py:83` |

Measured contexts probe, answering one requested file out of 5,000 files:

| Method | Artifact | Peak Python allocation | Elapsed under tracemalloc |
| --- | --- | --- | --- |
| Current whole-document context reader | 3.01 MiB | 25.09 MiB | 0.2243 s |
| Existing streaming walk, retaining requested file only | Same | 6.02 MiB | 0.0749 s |

Output was equal. These are one-run synthetic allocation measurements, not repository RSS or production timing claims. The scratch probe uses the existing `_Window`, `walk_report`, and `_line_contexts`; no dependency or parser replacement was needed.

The grammar probe demonstrates a separate defect at the same reader seam: both `split_top_level` and `split_window` accept `{"a": {} "b": {}}` and `{,"a": {}}`, while `json.loads` rejects both. Existing splitter equivalence tests primarily cover valid inputs. The malformed artifact is admitted instead of refused. This is an input-validation defect, not evidence of exploitability.

Before diagram: `artifact -> streaming functions reader`, `artifact -> streaming missing-lines reader`, `artifact -> whole-document contexts reader`, plus separate string-reader orchestration exercised by tests.

After diagram: `artifact -> one validated streaming walk -> function coverage, missing lines, and requested contexts as needed`.

Proposed change: concentrate artifact admission and decoding in the streaming reader. Extend the existing Python walk to gather the information already present in each decoded file, and let function history retain only the requested path's contexts. Move independent parser oracles into tests, or keep minimal text adapters where tests need convenience. Keep per-file attribution logic pure. Do not introduce a generic plugin framework or new parser dependency.

Deletion test: the four whole-document score/missing entrypoints above can be removed from production without changing a production caller. Their tests must move to the surviving public reader seam or keep the old code as a test oracle. After contexts use the stream, the all-files context map is also unnecessary for the command that asks about one file. Removing the second Python artifact decode should preserve its output.

Cost and risk: medium because correct parser behavior includes more than a JSON value. Preserve exact artifact hashes, decoding of split UTF-8 characters, key order, absolute-path handling, lane labels, no-branch warnings, regionless-file salvage, empty-artifact behavior, and dead-line intersection across lanes. Check the ownership of `uncovered.py`'s process-global folded state before extending it; this review has not proved it safe for multiple concurrent runs in one process.

Validation: add failing malformed-comma cases at public file-reader entrypoints, including tiny chunk boundaries. Keep independent `json.loads` comparisons for valid and malformed grammar. Compare exact function records, missing sets, context selections, warnings, and digests across both coverage formats. Add a read-count assertion that one Python lane plus missing-line collection reads the artifact once. Re-run the existing streaming, coverage reader, path-normalization, branch fallback, and uncovered-line tests. Measure a real large context artifact before claiming a production speedup.

## 3. Twin lookup allocates every rejected result

**Finding:** every brief's twin query constructs a dictionary for every indexed function before filtering by similarity. Most unrelated functions therefore pay for a result that is immediately discarded.

| Evidence | Location |
| --- | --- |
| Brief obtains a shared index and calls the twin query | `src/crapkit/cli/queue.py:510`, `src/crapkit/cli/queue.py:549` |
| Every non-self entry becomes a full payload | `src/crapkit/dup.py:172` |
| Similarity filtering happens after that list is built | `src/crapkit/dup.py:207` |
| Sorting and top cut happen only afterward | `src/crapkit/dup.py:209` |

Synthetic probe with 25,000 unrelated pre-indexed functions: 25,000 payload dictionaries created, zero twins returned, 7.27 MiB peak transient Python allocation, 0.0717 seconds under tracemalloc. The measurement excludes index construction and source loading. It shows avoidable allocation, not that this stage dominates total brief latency.

Before diagram: `shared shingle index -> intersection for every function -> payload for every function -> similarity filter -> sort -> top`.

After diagram: `shared shingle index -> similarity qualification -> payload only for qualifying functions -> same order and top`.

Proposed change: filter before constructing a payload and avoid the intermediate list of all results. Preserve the current rounded-similarity comparison; filtering raw ratios first can change behavior around a threshold. Consider bounded top selection only after measurements show that qualifying results themselves are large.

Deletion test: remove the eager `_twin_scores` result list. Callers cannot observe rejected payloads. Preserve the shared process-local `FunctionIndex`: deleting that index would reintroduce the repeated shingling already removed for batch briefs.

Cost and risk: small. The main risk is changing rounding, stable ties, nested-span labels, or ordering when replacing the pipeline.

Validation: assert identical public `find_twins` output for unrelated, exact, contained, nested, same-name, and threshold-rounding cases; retain existing batch reuse tests. Add a mechanism assertion that rejected candidates never construct payloads. Repeat the scratch allocation probe, then sample an actual large batch before giving a production performance estimate.

## 4. Move the retired two-pass analyzer into test support

**Finding:** `merge.py` still describes and implements the old production analysis architecture even though `analyze.py` now obtains both complexity columns from one token pass. Its two-pass types and merge code are used only by tests. `FunctionRecord` is the active production type and must remain available.

| Evidence | Location |
| --- | --- |
| Current one-pass analysis builds records directly | `src/crapkit/analyze.py:174`, `src/crapkit/analyze.py:333` |
| Retired input type | `src/crapkit/merge.py:11` |
| Retired grouping, mismatch, and merge implementation | `src/crapkit/merge.py:37`, `src/crapkit/merge.py:59` |
| Independent two-pass correctness oracle still calls it | `tests/unit/test_analyze_one_pass.py:103`, `tests/unit/test_analyze_one_pass.py:143` |
| Remaining callers are merger and recorded-fixture tests | `tests/unit/test_merge.py:8`, `tests/unit/test_recorded_fixtures.py:12` |

Before diagram: `production package -> current analyzer + dormant old analyzer`, with tests importing both from production.

After diagram: `production package -> current analyzer and function records`; `tests -> independent old analyzer oracle`.

Proposed change: move `RawFn` and two-pass merge logic into test support, preserving the independent oracle used to prove the optimized pass. Update the production module description so it states what exists today. Do not combine the oracle with the implementation it checks.

Deletion test: a repository-wide Python caller search found no production call to `merge_passes` and no production use of `RawFn`. Removing those from the shipped package changes no known CLI behavior. Retain `FunctionRecord` and avoid unnecessary import churn. External direct Python imports are the compatibility risk; the documented product surface is the CLI and MCP server, but confirm release policy before removal.

Other small removals found during the same caller search: `cache.updated_cache(..., stale_hashes=...)` accepts an unused argument whose only supplied value is in a test (`src/crapkit/cache.py:36`, `tests/unit/test_cache.py:29`); `coupling.partners` has only test callers after production moved to cached ranking and `packet.coupling_partners` (`src/crapkit/coupling.py:83`, `src/crapkit/packet.py:326`). These are cleanup tasks, not material performance projects.

Validation: retain and run the independent one-pass versus two-pass analysis check, recorded goldens, import checks, and the focused cache/coupling tests. Do not replace behavioral comparison with a test that merely asserts a symbol was deleted.

## Existing strengths to retain

- Explicit git-derived file lists, centralized deepest-path scope ownership, compiled exclusion matching, and named unclaimed/oversized files.
- One lizard tokenization per file, reused extension chains, module-scope registration in spawned workers, fixed source decoding, analysis-version invalidation, and independent parser compatibility tests.
- Streaming artifact reads with hashes calculated from the same bytes, exact-start score indexing, innermost span attribution, statement fallback, and clear coverage flags.
- Three history products with distinct purposes: compressed raw commit log, per-file churn, ranked coupling. Their existence is justified; shared key helpers alone do not justify merging them into a generic cache framework.
- Process-local shingle-index reuse across batch briefs, singleton-owner compression, early source release in all-pairs duplication, and explicit exclusion of nested-span pairs from the global report.

## Review coverage and limits

Read in full or followed through core caller paths: `analyze.py`, `cache.py`, `score.py`, `universe.py`, `coverage_istanbul.py`, `coverage_py.py`, `covstream.py`, `churn.py`, `churn_cache.py`, `coupling.py`, `coupling_cache.py`, `dup.py`, `merge.py`, and `snapshot.py`.

Inspected selected control/registration paths and documented accepted limits: `churn_log.py`, `lizardcognitive.py`, `lizardrust.py`, `lizardshell.py`, `lizardpowershell.py`, `uncovered.py`, and `cli/scoring.py`, `cli/queue.py`, `cli/reports.py`, `lanes.py`. This was not a full language-parser correctness audit.

Read repository contributing instructions, `CONTEXT.md`, both accepted ADRs, the handoff, and the codebase-design skill. Examined recent analysis/coverage/duplication history, including the one-pass work, streaming-reader consolidation, batch twin index, and latest nesting repairs. Inspected the relevant cache, warm path, reader-registration, one-pass, streaming, coverage, duplication, coupling, merger, and recorded-fixture tests. Existing strengths and recent changes informed what this report does not propose replacing.

## Reproduction files

Run from the repository or any directory with its installed dependencies:

```powershell
python -B 'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\architecture\analysis\probes.py'
python -B 'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\architecture\analysis\cost_probes.py'
```

`probes-output.txt` records correctness and malformed-cache results. `cost-output.txt` records allocation measurements. Probe scripts write only beneath this review's `work/architecture/analysis` directory and use `-B` to avoid bytecode writes.
