Review at HEAD 20f00e1371334f84aa70bba6f7b23bfc4bdae0f6. Repository remained clean. No coverage, verify, production store reads, or repo edits. Probes use temporary SQLite fixtures and pure functions, saved beside this file in probe.py and evidence.json.

1. P1. Preserve the trust decision when pruning runs.

Demonstrated defect. Four temporary runs were enough: coverage 1, failed verify 2, coverage 3, coverage 4. Before retention, pick_baseline selected run 1 and named failure 2 as blocker. prune_keep_set(..., keep=1) kept only runs 3 and 4. After deletion, pick_baseline selected run 4 and had no blocker. Retention erased both the trusted comparison point and the evidence forbidding the new one. A later verify or ratchet seed can accept the state the failure rejected.

Evidence and callers:
- src/crapkit/cli/reports.py:252-269, _runs_prune computes a keep-set then deletes runs.
- src/crapkit/store.py:1268-1282, prune_keep_set protects the digest pair, every passing verify, newest rowful run, and overrides. It does not protect the selected default baseline or an unanswered failure.
- src/crapkit/store.py:1162-1173 and 1186-1197, pick_baseline derives taint only from surviving run history.
- src/crapkit/cli/verifying.py:107-118, verify consumes that decision. cli/ratchet_cmds.py also calls pick_baseline through _latest_full_run.
- Existing test_store_prune.py:108-127 preserves a failed verify only when it is the newest run. test_ratchet_trust.py:138-157 proves that later coverage cannot clear a failure, but does not combine that scenario with prune.
- Recent commits 6847c3b and 999e5bb already repaired adjacent trust and retention readers.

Change: make retention preserve the evidence used by the existing trust decision, including the selected baseline and outstanding failure. Keep those rules beside baseline selection so a new reason to reject a run cannot disappear during retention. Do not add another trust predicate.

Deletion test: remove retention's independent assumption that only passing verifies and the newest rowful run affect future decisions. The store module earns its keep; deleting its transactional deletion would push consistency requirements into every caller. Keep that part.

Diagram description: before, the history branches into independent retention and baseline decisions, then deletion changes the latter. After, the trust decision's required run IDs feed retention before the transactional delete.

Cost/risk: small to medium change across store and its contract tests. A correct keep=1 may keep more history and disk; the documented parameter is already a floor. Preserve passing verifies, audit references, digest pairs, and cached-rollup deletion. Validate baseline choice and refusal text before/after prune for coverage after a failure, multiple failures, later passing verify, crashed verify, no earlier baseline, and repeated prune.

2. P1. Finish the existing per-function identity migration across claims and reports.

Demonstrated defects. keys.py and verify already distinguish same-named twins by ordinal. Claims, digest, history, and parts of explain still discard that distinction.

Measured fixture results:
- Claim 7 held twin #2 at CRAP 20. Twin #1 at CRAP 4 caused closable_claims to close claim 7 against ceiling 6.
- A first twin regressed 10 -> 12; its unchanged second twin overwrote it in digest's map. An unrelated function improved 5 -> 3, keeping totals equal. Digest returned quiet=true and zero lines.
- One run containing two same-named twins produced two history entries for one function, both carrying run_id=1. The span lookup selected the first twin.

Evidence and caller flow:
- src/crapkit/keys.py:52-77 already owns the ordinal rule; src/crapkit/verify.py:142-158 uses it for per-twin marks and gates.
- src/crapkit/worklist.py:206-224 keys claim completion by bare path/long_name. cli/verifying.py:412-422 releases the returned IDs.
- src/crapkit/cli/queue.py:92-100 hides every same-named row when any twin is claimed; 625-635 combines all twins' attempt histories; 703 passes bare long_name to function_history.
- src/crapkit/digest.py:119 and 134-135 define a bare-name map; cli/reports.py:79-80 calls it with store.read_crap, which discards start at store.py:645-657.
- src/crapkit/store.py:827-837 chooses the first matching span. 1071-1085 returns every matching twin, contrary to its one-row-per-run contract.
- src/crapkit/cli/reports.py:354-363 applies ctx.ordinal only to the ratchet mark. History and dark lines still use the bare name. An explicit explain f#2 can therefore combine twin #2's mark with twin #1's span and every twin's history.
- src/crapkit/packet.py:189-202 emits only the bare identifier for named functions, even named twins; report.py:267-269 also prints a bare-name drilldown command.
- tests/unit/test_twin_keys.py:341-352 validates only explain's selected mark. test_claims.py and test_digest.py use unique-name fixtures.

Change: carry the existing ordinal identity through selection, claim ownership/completion, history, digest matching, and drilldown. Retire bare-name maps where the operation means one function. Keep deliberate aggregate views explicit. Preserve the compact digest read by retaining enough identity to distinguish twins instead of restoring every scored field.

Deletion test: remove the local bare-name identity rules in these readers. The ordinal rule already exists and earns its keep across gates and ratchets; another identity module would add work. Complete adoption of the existing one.

Diagram description: before, inventory feeds an ordinal branch for gates and a bare-name branch for claims/reports, which merge twins. After, all per-function operations use the ordinal branch, with display names only at rendering.

Cost/risk: medium change across several small modules and JSON contract tests. Legacy claims lack precise handles; compatibility needs a stated conservative rule. Ordinals must count over the whole file before floor/scope filtering, preserve line-shift behavior, and follow current rename semantics. Validate claims and histories for named/anonymous twins, ordering changes, duplicate scopes, removed twins, explain #2 mark/span/history/test alignment, and digest regressions hidden by equal totals. Keep keys.py's first-twin bare key compatibility, shared admission, and file-scoped SQL reads.

3. P1. Make selecting and taking a claim one atomic operation.

Demonstrated defect under a valid interleaving. Two SnapshotStore connections both ran _unclaimed on the same ranked row before either claimed. Both then ran _maybe_claim, and the store contained two open claims for the same function. Both callers would emit that function as their work. This violates the documented purpose of claims.

Evidence and callers:
- src/crapkit/cli/queue.py:59-67 performs free-list lookup, HEAD lookup, insertion, then emits the original ranked list.
- src/crapkit/cli/queue.py:92-100 checks ownership outside a transaction with insertion.
- src/crapkit/cli/queue.py:124-137 inserts each batch item separately.
- src/crapkit/store.py:94-102 attempts has no uniqueness constraint for open ownership. 875-888 inserts unconditionally.
- tests/unit/test_claims.py covers ordering, persistence, release, and migration, but no competing callers.

Change: put claim acquisition at the SQLite transaction where exclusivity can be enforced. Return only work that this caller acquired and continue through ranked candidates when another session owns one. Keep expensive churn, git and ranking reads outside the short acquisition transaction. Coordinate with candidate 2 so ownership means the exact function.

Deletion test: delete the CLI's check-then-insert ownership protocol and its caller-side ordering requirement. Retain pure ranking and admission. The persistence module should own exclusivity because every process already meets there.

Diagram description: before, A and B independently read free, both insert, both emit. After, A reserves the candidate in a short transaction; B sees it held and reserves the next candidate.

Cost/risk: medium store migration and queue change. Duplicate existing open claims need deterministic treatment; attempt history must remain intact. Avoid holding the SQLite lock while git or duplication runs. Validate two real CLI processes synchronized before acquisition, --top batches with partial conflicts, no-claim reads, idempotent releases, crashes after commit, and distinct twins. Keep explicit opt-in claiming, ordered attempts, and release idempotence.

4. P2. Stop current-schema read commands from acquiring the migration write lock.

Demonstrated reliability defect and measured latency. A temporary store was created and closed. Another SQLite connection held BEGIN IMMEDIATE without changing anything. SnapshotStore(path), the entry point for read commands, failed with OperationalError: database is locked after 5.486 seconds. A normal SELECT against that state is allowed; constructor writes created the conflict.

Evidence and callers:
- src/crapkit/store.py:385-417 runs schema creation, seed inserts, migration, restacking, index creation and commit on every open.
- src/crapkit/store.py:399-405 performs INSERT OR IGNORE even when all code rows already exist.
- src/crapkit/store.py:496-533 drops old indexes and starts a restacking transaction every time; deflate_lanes scans for old lane encodings every time.
- cli/queue.py:27-37 and cli/reports.py:68-74 use that constructor for read operations. All other _open_store callers share it.
- src/crapkit/store.py:782-792 makes rollup cache writes best effort, but the command can fail before it reaches that protection.
- tests/unit/test_store_rollup.py:169-185 tests contention only after the reader has already opened its store.

Change: establish a current-schema open path that reads without seeding or migration writes. Perform real upgrades at a narrow explicit setup step, with transaction and retry rules owned by the store. Keep cache population optional when writers contend. Do not make a separate database implementation for each command.

Deletion test: remove recurring setup writes from the successful no-upgrade read path. Keep the migration implementation and its atomic build/swap discipline; deleting that would distribute compatibility knowledge into callers.

Diagram description: before, every reader passes through a writer-only setup phase before SELECT. After, current stores go straight to reads; only an old shape enters transactional upgrade, and cache writes remain best effort.

Cost/risk: medium, because old schema compatibility and mixed-version writers are deliberate contracts. A version shortcut must not silently stop migrating stores an older crapkit writes. Validate every old schema fixture, interrupted upgrade, simultaneous first opens, current-store opens while a writer holds a lock, malformed migration, and best-effort rollups. Retain identity normalization, fixed verdict codes, compressed provenance, indexed path reads, and atomic rewrites.

5. P3. Replace repeated baseline-history scans with one ordered walk.

Measured algorithm cost on pure fixtures, not a production timing claim. pick_baseline on 500/1,000/2,000 coverage runs took 3.898/15.746/67.538 ms. Doubling history roughly quadrupled runtime. The common all-coverage case still scans the whole history once per candidate although the newest one is usable immediately.

Evidence and callers:
- src/crapkit/store.py:1152-1159 creates a filtered verify list per candidate.
- src/crapkit/store.py:1162-1173 walks that list again.
- src/crapkit/store.py:1180-1197 builds all candidates eagerly, then uses only the first acceptable prefix.
- cli/verifying.py:113 and cli/ratchet_cmds.py's _latest_full_run consume the result.

Change: walk ordered history once, carrying the current outstanding failure and remembering the last acceptable baseline. Produce the existing selected/skipped/blocker answer from that walk. Combine implementation with candidate 1 if trust selection is already changing.

Deletion test: remove _verdict_verifies/_blocking_verify's repeated filtered-list construction and eager all-candidate assembly. Preserve the single trust decision returned to callers. No extra selector layer is needed.

Diagram description: before, each trusted candidate rescans all earlier history, then the first acceptable candidate wins. After, one chronological pass updates the failure and candidate state and returns the same answer.

Cost/risk: small once trust semantics are fixed. Present local timings as fixture measurements only; production significance depends on retained history. Validate output equivalence for generated run histories including crashed, failed and passing verifies, and benchmark 1k/2k/4k rows to confirm linear growth. Keep explicit --baseline override behavior and rejection diagnostics.

Coverage inventory:
- Inspected implementations of store.py, keys.py, ratchet.py, worklist.py, digest.py, report.py, cli/queue.py, and cli/reports.py. Inspected related identity, history, selection, and scoring-policy paths in packet.py, verify.py, cli/verifying.py, score.py, and ratchet_report.py. Scoring-policy implementation itself was sampled only; tests pinned the cc-only policy contract.
- claims.py, brief.py, trend.py, selection.py and scoring_policy.py do not exist at this HEAD. Their responsibilities live mainly in cli/queue.py, worklist.py, cli/reports.py, store.py, packet.py and score.py.
- Read contributing instructions, CONTEXT.md, both ADRs, codebase-design and unslop skills. Reviewed recent git history for store/queue/keys/digest and relevant diffs 6847c3b/999e5bb.
- Inspected tests for claims, digest, twin keys, shared trust/twin keys, store prune, store rollups, ratchet trust, scoring policy, and test inventories for worklist/report/batch/queue command behavior. Did not run project test suites.
- Existing depth to retain: the pure report renderer consumes the existing queue/trend payloads; shared Admission keeps both queue views aligned; rollups avoid rescoring history; specialized SQLite projections reduce allocations; keys.py owns twin identity; ratchet operations keep marks monotonic and compare metric stamps; batch loader shares expensive reads.
- No candidate depends on a speculative new abstraction. The first four reproduce failures. Candidate 5 has measured fixture cost and an unmeasured production payoff.
