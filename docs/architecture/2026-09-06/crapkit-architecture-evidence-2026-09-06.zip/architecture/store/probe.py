import sys, json, tempfile, sqlite3, time, threading
from pathlib import Path
sys.path.insert(0, r'C:\Users\jfgag\crapkit\src')
from crapkit.store import SnapshotStore, prune_keep_set, pick_baseline
from crapkit.score import ScoredRow
from crapkit.cli.queue import _unclaimed, _maybe_claim
from crapkit.worklist import closable_claims
from crapkit.digest import build_digest
from crapkit.packet import regrowth

out={}
def row(name='f( )', start=1, crap=20.0):
    return ScoredRow('src','src/a.py',name,start,start+5,4,4,4,5,0,1,0.0,'measured',crap,'ok' if crap<=6 else 'add-tests')
base=Path(__file__).parent
with tempfile.TemporaryDirectory(dir=base, prefix='probe-') as tmp:
    root=Path(tmp)
    # Exact interleaving available to independent next-item processes.
    a=SnapshotStore(root/'claims.sqlite'); b=SnapshotStore(root/'claims.sqlite')
    candidates=[row()]
    free_a, _=_unclaimed(a,candidates); free_b, _=_unclaimed(b,candidates)
    _maybe_claim(a,'c1',True,free_a); _maybe_claim(b,'c1',True,free_b)
    out['non_atomic_claim']={'first_selected':len(free_a),'second_selected':len(free_b),'open_claims':len(a.open_claims()),'claim_ids':[c['id'] for c in a.open_claims()]}
    a._conn.close(); b._conn.close()
    twins=[row('__post_init__( self )',1,4.0),row('__post_init__( self )',20,20.0)]
    held=[{'id':7,'path':'src/a.py','long_name':'__post_init__( self )','handle':'__post_init__#2','commit':'c1'}]
    out['twin_claim_closure']={'claimed_twin_crap':twins[1].crap,'ceiling':6,'closed_claim_ids':closable_claims(held,twins,target=6,scope_targets={},stale_commits=set())}
    # A compensating improvement in another function hides the first twin's regression entirely.
    prev=[row('f( )',1,10),row('f( )',20,5),row('g( )',40,5)]
    cur=[row('f( )',1,12),row('f( )',20,5),row('g( )',40,3)]
    d=build_digest(prev,cur,ceiling_of=lambda _:6)
    out['twin_digest']={'first_twin_before':10,'first_twin_after':12,'quiet':d.quiet,'lines':d.lines}
    s=SnapshotStore(root/'history.sqlite')
    rid=s.write_run(commit='c1',tool_versions={},rows=twins)
    hist=s.function_history('src/a.py','__post_init__( self )')
    out['twin_history']={'run_count':len(s.list_runs()),'history_count':len(hist),'history':hist,'regrowth':regrowth(hist),'span_for_name':s.function_span(rid,'src/a.py','__post_init__( self )')}
    s._conn.close()
    # Retention must preserve the default trust verdict, not just the digest pair.
    s=SnapshotStore(root/'prune.sqlite')
    original=s.write_run(commit='good',tool_versions={},rows=[row()],lanes={'py':{}},kind='coverage')
    failure=s.write_run(commit='bad',tool_versions={},rows=[row()],lanes={'py':{}},kind='verify')
    s.set_verdict_ok(failure,False,findings=1)
    c3=s.write_run(commit='bad',tool_versions={},rows=[row()],lanes={'py':{}},kind='coverage')
    c4=s.write_run(commit='bad',tool_versions={},rows=[row()],lanes={'py':{}},kind='coverage')
    before=pick_baseline(s.list_runs()); keep=prune_keep_set(s.list_runs(),s.override_run_ids(),keep=1)
    deleted=s.prune_runs(keep); after=pick_baseline(s.list_runs())
    out['prune_trust']={'original_baseline':original,'failed_verify':failure,'newest_coverage':c4,'before_baseline':before.run['id'] if before.run else None,'before_blocker':before.blocker['id'] if before.blocker else None,'keep_ids':sorted(keep),'deleted_runs':deleted,'after_baseline':after.run['id'] if after.run else None,'after_blocker':after.blocker['id'] if after.blocker else None}
    s._conn.close()
    # A warmed current-schema read still acquires a write lock in __init__.
    p=root/'locked.sqlite'; s=SnapshotStore(p); s.write_run(commit='c1',tool_versions={},rows=[row()]); s._conn.close()
    blocker=sqlite3.connect(p); blocker.execute('BEGIN IMMEDIATE')
    start=time.perf_counter()
    try:
        reader=SnapshotStore(p); out['open_while_writer']={'result':'opened'};reader._conn.close()
    except sqlite3.OperationalError as e:
        out['open_while_writer']={'result':type(e).__name__,'message':str(e),'seconds':round(time.perf_counter()-start,3)}
    finally:
        blocker.rollback();blocker.close()
    # Pure selector growth on real run-shaped dictionaries.
    timings=[]
    for n in (500,1000,2000):
        runs=[{'id':i+1,'kind':'coverage','lanes':{'py':{}},'verdict_ok':None} for i in range(n)]
        start=time.perf_counter();pick_baseline(runs)
        timings.append({'runs':n,'milliseconds':round((time.perf_counter()-start)*1000,3)})
    out['baseline_selection_growth']=timings
print(json.dumps(out,indent=2))
(base/'evidence.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
