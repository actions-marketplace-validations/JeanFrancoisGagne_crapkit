import json, os
from pathlib import Path
from tempfile import TemporaryDirectory
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
import pytest
from crapkit.config import pytest_testpaths_at
from crapkit.scaffold import pytest_testpaths
cases = [
    {'name':'empty-dot-pytest-ini', 'files':{'.pytest.ini':'', 'pyproject.toml':'[tool.pytest.ini_options]\ntestpaths = ["later"]\n'}},
    {'name':'empty-pytest-ini', 'files':{'pytest.ini':'', 'pyproject.toml':'[tool.pytest.ini_options]\ntestpaths = ["tests_a", "tests_b"]\n'}},
    {'name':'dot-pytest-ini', 'files':{'.pytest.ini':'[pytest]\ntestpaths = actual\n', 'pyproject.toml':'[tool.pytest.ini_options]\ntestpaths = ["other"]\n'}},
    {'name':'toml-string-testpaths', 'files':{'pyproject.toml':'[tool.pytest.ini_options]\ntestpaths = "tests_a tests_b"\n'}},
    {'name':'percent-in-ini', 'files':{'pytest.ini':'[pytest]\ntestpaths = tests_100%\n'}},
]
results=[]
for case in cases:
    with TemporaryDirectory(prefix='pytest-',dir=Path(__file__).parent) as directory:
        root=Path(directory)
        for name,content in case['files'].items():
            (root/name).write_text(content,encoding='utf-8')
        config=pytest.Config.fromdictargs({},['--rootdir',str(root),str(root)])
        try:
            selected=config.inipath.name if config.inipath else None
            actual=config.getini('testpaths')
        finally:
            config._ensure_unconfigure()
        try:
            scaffold=pytest_testpaths(case['files'])
        except Exception as exc:
            scaffold=type(exc).__name__+': '+str(exc)
        results.append({'case':case['name'],'pytest_version':pytest.__version__,'pytest_selected_file':selected,'pytest_actual_testpaths':actual,'guard':pytest_testpaths_at(root),'scaffold':scaffold})
print(json.dumps(results,indent=2))
Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2),encoding='utf-8')

