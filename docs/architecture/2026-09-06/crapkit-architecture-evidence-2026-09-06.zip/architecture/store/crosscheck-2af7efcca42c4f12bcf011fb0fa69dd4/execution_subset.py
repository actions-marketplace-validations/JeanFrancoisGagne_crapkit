"""Read-only review probes. All files stay under this script's scratch directory."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
from unittest.mock import patch

from crapkit.config import Lane, load_config_text
from crapkit.cli.scoring import _collect_lanes
from crapkit.lanes import LaneOutcome, build_retest_command, retest_lane
from crapkit.mutate import file_mutants
from crapkit.mutate_pool import _seed, _pool_lock, drop_pool
from crapkit.verify import evaluate

BASE = Path(__file__).resolve().parent
SCRATCH = BASE / 'scratch'
SCRATCH.mkdir(exist_ok=True)
results = {}

cfg = load_config_text('''
[[scope]]
name = "src"
paths = ["src"]
languages = ["python"]
[[lane]]
name = "unit"
command = "echo first"
artifact = "first.json"
parser = "coveragepy"
scopes = ["src"]
[[lane]]
name = "unit"
command = "echo second"
artifact = "second.json"
parser = "coveragepy"
scopes = ["src"]
''')
first, second = cfg.lanes
outcomes = {
    first: (LaneOutcome({}, {'failures': ['test_math::fails'], 'scopes': ['src']}, {}), ''),
    second: (LaneOutcome({}, {'failures': [], 'scopes': ['src']}, {}), ''),
}
_, provenance, errors, succeeded = _collect_lanes(SCRATCH, cfg.lanes, outcomes)
failures = {f for prov in provenance.values() for f in prov.get('failures', ())}
verdict = evaluate(fresh=[], changed_ranges={}, ratchet=[], baseline_failures=set(),
                   fresh_failures=failures, target=6)
results['duplicate_lanes'] = {
    'accepted_names': [lane.name for lane in cfg.lanes],
    'input_failure': 'test_math::fails', 'retained_failures': sorted(failures),
    'verdict_ok': verdict.ok, 'lane_errors': errors,
}

retest = SCRATCH / 'empty_retest.py'
retest.write_text("from pathlib import Path\nPath('junit.xml').write_text('<testsuite tests=\"0\"/>')\nraise SystemExit(5)\n", encoding='utf-8')
lane = Lane('unit', 'unused', 'unused.json', 'coveragepy', ('src',),
            results_artifact='junit.xml', timeout_seconds=5,
            retest_command=f'"{sys.executable}" "{retest}"')
flakes = retest_lane(SCRATCH, lane, {'test_math::fails'})
results['zero_test_retest'] = {'runner_exit': 5, 'tests_reported': 0, 'failures_forgiven': sorted(flakes)}
retest.write_text("from pathlib import Path\nPath('junit.xml').write_text('<testsuite tests=\"1\"><testcase classname=\"other\" name=\"passes\"/></testsuite>')\nraise SystemExit(2)\n", encoding='utf-8')
flakes = retest_lane(SCRATCH, lane, {'test_math::fails'})
results['unrelated_test_retest'] = {'runner_exit': 2, 'reported_pass': 'other::passes',
                                   'requested_test': 'test_math::fails', 'failures_forgiven': sorted(flakes)}


print(json.dumps(results, indent=2))
(BASE/'execution-results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')

