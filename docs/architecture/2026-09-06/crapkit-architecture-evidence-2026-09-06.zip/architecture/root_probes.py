import json
from pathlib import Path
from tempfile import TemporaryDirectory

from crapkit.config import pytest_testpaths_at
from crapkit.scaffold import pytest_testpaths

cases = [
    {'name':'empty-pytest-ini', 'files':{'pytest.ini':'', 'pyproject.toml':'[tool.pytest.ini_options]\ntestpaths = ["tests_a", "tests_b"]\n'}},
    {'name':'dot-pytest-ini', 'files':{'.pytest.ini':'[pytest]\ntestpaths = actual\n', 'pyproject.toml':'[tool.pytest.ini_options]\ntestpaths = ["other"]\n'}},
    {'name':'toml-string-testpaths', 'files':{'pyproject.toml':'[tool.pytest.ini_options]\ntestpaths = "tests_a tests_b"\n'}},
    {'name':'percent-in-ini', 'files':{'pytest.ini':'[pytest]\ntestpaths = tests_100%\n'}},
]
results = []
for case in cases:
    with TemporaryDirectory(prefix='crapkit-review-') as directory:
        root = Path(directory)
        for name, content in case['files'].items():
            (root/name).write_text(content, encoding='utf-8')
        guard = pytest_testpaths_at(root)
        try:
            scaffold = pytest_testpaths(case['files'])
        except Exception as exc:
            scaffold = type(exc).__name__ + ': ' + str(exc)
        results.append({'case':case['name'], 'guard':guard, 'scaffold':scaffold})
target = Path(__file__).with_suffix('.json')
target.write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(results,indent=2))
