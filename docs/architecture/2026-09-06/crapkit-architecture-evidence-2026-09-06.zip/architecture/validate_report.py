import json
from pathlib import Path
import re
import zipfile

out = Path(__file__).parent.parents[1] / 'outputs'
root = Path(r'C:\Users\jfgag\crapkit')
candidates = json.loads((out/'crapkit-architecture-candidates-2026-09-06.json').read_text())
issues = []
references = 0
for item in candidates:
    if not item['before'] or not item['after']:
        issues.append(item['id'])
    for ref in item['files']:
        path, number = ref.rsplit(':', 1)
        lines = (root/path).read_text(encoding='utf-8-sig').splitlines()
        references += 1
        if not 1 <= int(number) <= len(lines):
            issues.append(ref)
text = (out/'crapkit-architecture-review-2026-09-06.html').read_text(encoding='utf-8')
ids = set(re.findall(r'id="([^"]+)"',text))
links = re.findall(r'href="#([^"]+)"',text)
issues.extend(link for link in links if link not in ids)
with zipfile.ZipFile(out/'crapkit-architecture-evidence-2026-09-06.zip') as archive:
    result = {'candidates':len(candidates), 'source_references':references, 'archive_entries':len(archive.namelist()), 'archive_error':archive.testzip(), 'issues':issues}
print(json.dumps(result,indent=2))
assert not issues and result['archive_error'] is None
