"""Check report inputs, links, source coverage and deterministic rendering."""
import fnmatch
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import subprocess
import sys

WORK = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\jfgag\crapkit')
REPORT = REPO / 'docs/architecture/2026-09-07-re-audit'


class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids, self.links, self.cards, self.figures = set(), [], 0, 0

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if 'id' in values:
            self.ids.add(values['id'])
        if tag == 'a':
            self.links.append(values.get('href', ''))
        self.cards += tag == 'article'
        self.figures += tag == 'figure'


def source_coverage(data):
    before = json.loads((WORK / 'root-before.json').read_text())
    modules = [name for name in before['inputs'] if name.startswith('src/') and name.endswith('.py')]
    paths = [path for row in data['coverage'] for path in row['paths']]
    missing = [name for name in modules if not any(fnmatch.fnmatch(name, path) for path in paths)]
    return dict(modules=len(modules), exact_or_pattern_dispositions=len(modules) - len(missing),
                unmatched_paths=missing)


def validate_links(page):
    for link in page.links:
        if link.startswith('#'):
            assert link[1:] in page.ids, link
        else:
            assert (REPORT / link).is_file(), link


def deterministic():
    path = REPORT / 'architecture-review.html'
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    subprocess.run([sys.executable, str(REPORT / 'build_report.py')], check=True)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    return digest


def main():
    data = json.loads((REPORT / 'report-data.json').read_text(encoding='utf-8'))
    page = Page()
    page.feed((REPORT / 'architecture-review.html').read_text(encoding='utf-8'))
    validate_links(page)
    assert page.cards == len(data['candidates']) and page.figures == page.cards * 2
    result = dict(cards=page.cards, before_after_figures=page.figures, links_valid=True,
                  reproducible_html_sha256=deterministic(), coverage=source_coverage(data))
    (WORK / 'report-validation.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
