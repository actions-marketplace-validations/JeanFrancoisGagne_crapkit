"""Exercise exported records and packet commands through disposable real repos."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

WORK = Path(__file__).resolve().parent
PYTHON = WORK.parent / 'implementation/configured-runtime/venv/Scripts/python.exe'
SOURCE = Path(r'C:\Users\jfgag\crapkit\src')
sys.path.insert(0, str(SOURCE))
from crapkit.ratchet import RatchetEntry, dump_ratchet, load_ratchet


def git(root, *args):
    return subprocess.check_output(['git', '-c', 'user.name=Audit', '-c',
                                    'user.email=audit@example.invalid', *args], cwd=root)


def cli(root, name, *args):
    result = subprocess.run([str(PYTHON), '-m', 'crapkit', *args, '--repo', str(root)],
                            cwd=root, env={**os.environ, 'PYTHONPATH': str(SOURCE),
                                           'CRAPKIT_AUDIT_ONLY': 'expanded'}, capture_output=True)
    (WORK / f'records-{name}.stdout.txt').write_bytes(result.stdout)
    (WORK / f'records-{name}.stderr.txt').write_bytes(result.stderr)
    return dict(exit=result.returncode, stdout=result.stdout.decode('utf-8'),
                stderr=result.stderr.decode('utf-8'))


def prepare(path, label):
    root = Path(tempfile.mkdtemp(prefix=f'records-{label}-', dir=WORK))
    (root / 'src').mkdir()
    (root / path).write_text('def f(x):\n    return x\n', encoding='utf-8')
    (root / '.gitignore').write_text('.crapkit/\nbaseline.tsv\ncaptured.json\n')
    template = f'"{PYTHON.as_posix()}" capture.py {{files}}'
    (root / 'crapkit.toml').write_text('''[crapkit]
target=6
[crapkit.scoped_tests]
src=''' + json.dumps(template) + '''
[[scope]]
name="src"
paths=["src"]
languages=["python"]
coverage_optional=true
''', encoding='utf-8')
    (root / 'capture.py').write_text("import json, sys\nfrom pathlib import Path\nPath('captured.json').write_text(json.dumps(sys.argv[1:]))\n")
    git(root, 'init', '-q')
    git(root, 'add', '.')
    git(root, 'commit', '-qm', 'record fixture')
    return root


def ratchet_result(path):
    exported = dump_ratchet([RatchetEntry(path, 'f( x )', 2.0)])
    try:
        return dict(exported=exported, rows=[tuple(row) for row in load_ratchet(exported)])
    except ValueError as error:
        return dict(exported=exported, error=str(error))


def roundtrip(path, label):
    root = prepare(path, label)
    cli(root, label + '-coverage', 'coverage', '--json')
    exported = cli(root, label + '-export', 'verify', '--emit-baseline', 'baseline.tsv',
                   '--reuse-artifacts', '--no-tighten', '--json')
    verified = cli(root, label + '-verify', 'verify', '--baseline-tsv', 'baseline.tsv',
                   '--reuse-artifacts', '--no-tighten', '--json')
    return dict(root=str(root), path=path, export=exported, verify=verified,
                ratchet=ratchet_result(path))


def packet_command(path, label):
    root = prepare(path, label)
    cli(root, label + '-coverage', 'coverage', '--json')
    brief = cli(root, label + '-brief', 'brief', path, 'f', '--json')
    commands = json.loads(brief['stdout'])['commands']
    environment = {**os.environ, 'CRAPKIT_AUDIT_ONLY': 'expanded', 'PYTHONPATH': str(SOURCE)}
    result = subprocess.run(commands['scoped_tests'], shell=True, cwd=root, env=environment,
                            capture_output=True)
    packet_args = json.loads((root / 'captured.json').read_text())
    direct = cli(root, label + '-direct', 'test-scoped', path)
    direct_args = json.loads((root / 'captured.json').read_text())
    return dict(path=path, commands=commands, packet_exit=result.returncode,
                packet_args=packet_args, direct_exit=direct['exit'], direct_args=direct_args)


def main():
    cases = dict(control=roundtrip('src/a.py', 'control'),
                 separator=roundtrip('src/a\u2028b.py', 'separator'),
                 packet=packet_command('src/%CRAPKIT_AUDIT_ONLY%.py', 'packet'))
    (WORK / 'records-result.json').write_text(json.dumps(cases, indent=2), encoding='utf-8')
    print(json.dumps(cases, indent=2))


if __name__ == '__main__':
    main()
