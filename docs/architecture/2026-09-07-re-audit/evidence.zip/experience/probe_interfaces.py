"""Read frozen source through CLI and serialization interfaces; use scratch fixtures."""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from urllib.parse import urlsplit, unquote

import crapkit
from crapkit.sarif import diff_uncovered_results

ROOT = Path(os.environ["PYTHONPATH"]).resolve().parent
SCRATCH = Path(__file__).resolve().parent
assert Path(crapkit.__file__).resolve() == ROOT / "src/crapkit/__init__.py"


def run(command, cwd, **options):
    completed = subprocess.run(command, cwd=cwd, capture_output=True, timeout=30, **options)
    return {"exit": completed.returncode, "stdout": completed.stdout.decode("utf-8", "replace"),
            "stderr": completed.stderr.decode("utf-8", "replace")}


def mcp_probe(work):
    repo = work / "repo-\u0101"
    repo.mkdir()
    (repo / "crapkit.toml").write_text(
        '[crapkit]\ntarget=6\n[[scope]]\nname="src"\npaths=["src"]\n'
        'languages=["python"]\ncoverage_optional=true\n', encoding="utf-8")
    frames = [
        {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
         "params": {"name": "get_next_item", "arguments": {}}},
        {"jsonrpc": "2.0", "id": 2, "method": "ping"},
    ]
    environment = dict(os.environ, PYTHONUTF8="0")
    direct = run([sys.executable, "-m", "crapkit", "next-item", "--repo", str(repo)],
                 work, env=environment)
    wire = run([sys.executable, "-m", "crapkit", "mcp", "--repo", str(repo)], work,
               env=environment, input="".join(json.dumps(x) + "\n" for x in frames).encode())
    return {"direct_cli": direct, "mcp": wire}


def action_probe(work):
    repo = work / "git-paths"
    repo.mkdir()
    assert run(["git", "init", "--quiet", str(repo)], work)["exit"] == 0
    names = [" leading.py", "line\u2028break.py", "plain.py"]
    for name in names:
        (repo / name).write_text("def f():\n    return 1\n", encoding="utf-8")
    assert run(["git", "add", "--", *names], repo)["exit"] == 0
    diff = subprocess.run(["git", "-c", "core.quotePath=false", "diff", "--cached", "--name-only"],
                          cwd=repo, capture_output=True, check=True)
    changed = work / "changed.txt"
    changed.write_bytes(diff.stdout)
    rows = [{"path": name, "start": 1, "function": "f( )", "ccn": 7, "risk": 7,
             "remedy": "decompose"} for name in names]
    worklist = work / "worklist.json"
    worklist.write_text(json.dumps({"active": rows}), encoding="utf-8")
    output = work / "comment.md"
    command = [sys.executable, str(ROOT / "tools/action/comment.py"), "--changed", str(changed),
               "--worklist", str(worklist), "--top", "10", "--out", str(output)]
    result = run(command, work)
    result.update({"git_path_bytes_hex": diff.stdout.hex(), "expected_paths": names,
                   "comment": output.read_text(encoding="utf-8")})
    return result


def sarif_probe():
    paths = ["src/a#b.py", "src/a%20b.py", "src/a?b.py", "src/a b.py"]
    results = diff_uncovered_results([(path, 1) for path in paths])
    locations = []
    for path, result in zip(paths, results):
        uri = result["locations"][0]["physicalLocation"]["artifactLocation"]["uri"]
        parsed = urlsplit(uri)
        locations.append({"source_path": path, "uri": uri, "decoded_uri_path": unquote(parsed.path),
                          "query": parsed.query, "fragment": parsed.fragment})
    return locations


def doctor_probe(work):
    shims = work / "shims"
    shims.mkdir()
    shim = shims / "crapkit.cmd"
    shim.write_text("@echo off\r\nexit /b 7\r\n", encoding="ascii")
    environment = dict(os.environ, PATH=str(shims) + os.pathsep + os.environ.get("PATH", ""))
    direct = run([str(shim), "--version"], work, env=environment)
    command = [sys.executable, "-m", "crapkit", "doctor", "--plugin-root", str(ROOT / "plugin")]
    result = run(command, work, env=environment)
    return {"shim": direct, "doctor": result}


def main():
    with tempfile.TemporaryDirectory(prefix="interfaces-", dir=SCRATCH) as directory:
        work = Path(directory)
        result = {"source": str(ROOT), "python": sys.executable,
                  "mcp_utf8": mcp_probe(work), "action_paths": action_probe(work),
                  "sarif_paths": sarif_probe(), "plugin_doctor": doctor_probe(work)}
    (SCRATCH / "probe_interfaces.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
