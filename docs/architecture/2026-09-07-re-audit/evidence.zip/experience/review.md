# Interface audit

Four adapters fail bounded replays. A fifth opportunity removes conflicting copies of current mutation guidance.

Source: C:/Users/jfgag/crapkit at b11e2c165411b5ff9caa6b4b8486aafe477dfeb8.

| ID | Strength | Observed result |
|---|---|---|
| UI1 | Strong | A Windows MCP call loses the CLI's UTF-8 refusal and emits text:null. |
| UI2 | Strong | The Action comment receives three real Git paths, reports four, and displays only one worklist row. |
| UI3 | Strong | SARIF paths containing # or literal %20 identify a different URI path. |
| UI4 | Strong | Plugin doctor exits 0 when the launcher used by the plugin exits 7. |
| UI5 | Worth exploring | Current adoption, handbook and skill guidance contradict the pool contract. Delete the copied implementation details and link to the configuration reference. |

The fixes deepen existing adapters: the MCP adapter owns child decoding; the Action reader owns Git record framing; output adapters distinguish URI locations from workflow filenames; plugin health keeps failed execution distinct from a version.

The SARIF location contract uses a URI reference. The probe checks how the produced reference resolves; no code-scanning service was contacted. See the [OASIS SARIF 2.1.0 specification, section 3.4.3](https://docs.oasis-open.org/sarif/sarif/v2.1.0/os/sarif-v2.1.0-os.html).

## Evidence and limits

- findings.json contains exact source anchors, caller flows, the deletion test, proposed changes, tests to preserve/add, diagrams, costs, risks, ADR dispositions and the full owned-scope map.
- probe_interfaces.py reproduces four cases. probe_interfaces.json preserves raw child stdout, stderr and exit codes plus Git record bytes.
- docs-drift.md records the contradictory current claims and runtime call path.
- The probe asserts that crapkit imports from the frozen checkout. It uses the existing configured-runtime Python 3.11.2 environment and temporary fixtures inside this directory.
- Focused tests run: 0. Full suites run: 0. Bounded probes: 4. No new benchmark or speed claim.
- No root source, test, configuration, ledger or artifact changes; no installation, commit, hosted action, MCP client integration, SARIF upload or publication.
- The Action case uses real Git cached name output with the Action's line framing and the public comment CLI. The question-mark SARIF case is synthetic because Windows filenames cannot contain '?'.

Replay from PowerShell:

```powershell
$env:PYTHONPATH = 'C:\Users\jfgag\crapkit\src'
& 'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\implementation\configured-runtime\venv\Scripts\python.exe' 'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\re-audit-20260907\experience\probe_interfaces.py'
```

## Retain

Keep ADR 0001 tool-result refusals and ADR 0002 nearest-config discovery. Keep the lazy CLI facade, subprocess reuse of command behavior, exact identity selectors, HTML escaping, workflow delimiter escaping, streamed SARIF output, per-run missing-line folds and narrow digest values.

Admin file size does not justify another module. The static plugin hook matrix reflects the host's manifest shape. No generalized output framework or retained MCP command process is justified by these findings.

Parent owns state/config/queue/verdict internals and path command quoting. Other reviewers own analysis/readers/Git/cache and process/testing/release/workflow internals. Historical architecture artifacts, binary demos and hosted integrations are excluded from this bounded review.
