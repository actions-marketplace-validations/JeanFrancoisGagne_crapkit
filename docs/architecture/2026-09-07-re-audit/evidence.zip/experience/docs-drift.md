# Mutation guidance has two current answers

Source: C:/Users/jfgag/crapkit at b11e2c165411b5ff9caa6b4b8486aafe477dfeb8.

| Current surface | Verified location | Claim |
|---|---|---|
| Adoption guide | docs/adoption.md:187,191 | Pool storage is described for workers above one; a single worker is said to mutate the working tree and leave nothing. |
| Handbook | docs/handbook.html:815 | Retained workers are described only above one; single-worker runs are called untouched. |
| Installed agent skill | plugin/skills/crapkit/SKILL.md:34 | The cleanup row describes the worktrees workers above one keep. |
| Configuration reference | docs/configuration.md:48 | Every worker uses a retained detached worktree, including one; dirty, untracked and deleted inputs are copied. |
| Runtime | src/crapkit/mutate_pool.py:353,365 | Every nonempty mutant list computes a worker count and calls _run_parallel. There is no live-tree single-worker branch. |

The current rule should stay in docs/configuration.md. Adoption and the skill need the cleanup action and a link to that rule, not another explanation of worker internals. The handbook can give the same short instruction. Clearly dated release history may keep past behavior.

This is a source-backed documentation finding. No mutation campaign ran during this review. The runtime reviewer owns broader mutation behavior.
