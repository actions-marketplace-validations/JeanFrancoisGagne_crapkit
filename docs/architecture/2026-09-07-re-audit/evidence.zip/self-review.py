"""Run Crapkit's bounded review commands against the frozen audit checkout."""
import json
import os
from pathlib import Path
import subprocess
import time

WORK = Path(__file__).resolve().parent
CLONE = WORK / 'self-checkout'
PYTHON = WORK.parent / 'implementation/configured-runtime/venv/Scripts/python.exe'


def command(name, args):
    env = {**os.environ, 'PYTHONPATH': str(CLONE / 'src')}
    started = time.perf_counter()
    result = subprocess.run([str(PYTHON), '-m', 'crapkit', *args, '--repo', str(CLONE)],
                            cwd=CLONE, env=env, capture_output=True)
    (WORK / f'self-{name}.json').write_bytes(result.stdout)
    (WORK / f'self-{name}.stderr.txt').write_bytes(result.stderr)
    return dict(command=args, exit=result.returncode, seconds=time.perf_counter()-started)


if __name__ == '__main__':
    commands = {
        'inventory': ['inventory', '--db', str(WORK / 'inventory.sqlite'), '--json'],
        'worklist': ['worklist', '--top', '20', '--json'],
        'duplication': ['duplication', '--top', '20', '--json'],
        'coupling': ['coupling', '--top', '20', '--json'],
        'verify': ['verify', '--reuse-artifacts', '--no-tighten', '--base',
                   '47629ea14ddea38e55ce2332d08297c31888acb9', '--json'],
    }
    results = {name: command(name, args) for name, args in commands.items()}
    (WORK / 'self-commands.json').write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps(results, indent=2))
