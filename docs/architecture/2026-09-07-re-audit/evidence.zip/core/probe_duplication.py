"""Run process-seed determinism and bounded synthetic duplication-cost probes."""
import gc
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import tracemalloc

sys.dont_write_bytecode = True
sys.path.insert(0, 'C:/Users/jfgag/crapkit/src')
from crapkit.dup import find_duplicates
from crapkit.snapshot import InventoryRow

BASE = Path(__file__).parent
def row(path, text):
    return InventoryRow('src', path, 'f', 1, len(text.splitlines()), 3, 3, 3,
                        len(text.splitlines()), 0, 0)

def tie_case():
    x = [f'    x{i} = first({i})' for i in range(20)]
    y = [f'    y{i} = second({i})' for i in range(20)]
    sources = {
        'a.py': '\n'.join(['def a():', *x, *y]),
        'b.py': '\n'.join(['def b():', *x, '    z=1', '    q=2', '    p=3']),
        'c.py': '\n'.join(['def c():', *y, '    z=4', '    q=5', '    p=6']),
    }
    rows = [row(path, text) for path, text in sources.items()]
    pairs = find_duplicates(rows, lambda: sources, top=1)
    return {'pairs': pairs, 'sources': sources}

if len(sys.argv) > 1 and sys.argv[1] == 'seed':
    print(json.dumps(tie_case()))
    raise SystemExit

out = {'seeds': {}, 'benchmark': []}
for seed in range(1, 11):
    env = dict(os.environ, PYTHONHASHSEED=str(seed), PYTHONDONTWRITEBYTECODE='1')
    result = subprocess.run([sys.executable, str(Path(__file__)), 'seed'], env=env,
                            capture_output=True, text=True, check=True)
    out['seeds'][str(seed)] = json.loads(result.stdout)
for count in (150, 300, 600):
    sources = {f'file-{i:04}.py': 'def f():\n' + '\n'.join(
        f'    line_{j} = compute({j})' for j in range(10)) for i in range(count)}
    rows = [row(path, source) for path, source in sources.items()]
    gc.collect()
    tracemalloc.start()
    start = time.perf_counter()
    result = find_duplicates(rows, lambda: sources, top=1)
    elapsed = time.perf_counter() - start
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    out['benchmark'].append({'functions': count, 'potential_pairs': count*(count-1)//2,
                             'returned': len(result), 'seconds_with_tracemalloc': elapsed,
                             'peak_python_mb': peak/1024**2})
(BASE/'duplication-results.json').write_text(json.dumps(out, indent=2), encoding='utf-8')
print(json.dumps({'seed_pairs': {seed: v['pairs'] for seed,v in out['seeds'].items()},
                  'benchmark': out['benchmark']}, indent=2))
