"""Repeatable, isolated reader and Git diff probes for frozen b11e2c1."""
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'C:/Users/jfgag/crapkit/src')
from crapkit import covstream, gitio
from crapkit.config import load_config_text
from crapkit.diffparse import changed_ranges
from crapkit.hook import gate_staged
from crapkit.score import score_rows
from crapkit.snapshot import InventoryRow

BASE = Path(__file__).parent
OUT = {}
row = InventoryRow('core', 'app.py', 'f', 1, 3, 6, 6, 6, 3, 1, 0, 0, 1)
for covered, total in [(1, 2), (4, 2), (-1, 2), (0, -2), (True, 2), (1.5, 2)]:
    data = {'meta': {'branch_coverage': True}, 'files': {'app.py': {'functions': {'f': {
        'start_line': 1, 'executed_lines': [2, 3], 'missing_lines': [],
        'summary': {'covered_lines': 2, 'num_statements': 2,
                    'num_branches': total, 'covered_branches': covered}}}}}}
    artifact = BASE / 'counter-artifact.json'
    artifact.write_text(json.dumps(data), encoding='utf-8')
    try:
        coverage, _ = covstream.parse_coveragepy_file(artifact, path_prefix='')
        result = score_rows([row], coverage, lane_scopes={'core'})[0]
        OUT[f'coverage_{covered!r}_{total!r}'] = result._asdict()
    except Exception as exc:
        OUT[f'coverage_{covered!r}_{total!r}'] = {'exception': type(exc).__name__, 'message': str(exc)}

repo = BASE / 'diff-repo'
repo.mkdir(exist_ok=True)
def git(*args):
    return subprocess.run(['git', *args], cwd=repo, check=True, text=True,
                          encoding='utf-8', capture_output=True).stdout

if not (repo / '.git').exists():
    subprocess.run(['git', 'clone', '--shared', '--no-checkout', '-q',
                    'C:/Users/jfgag/crapkit', str(repo)], check=True)
    git('read-tree', 'HEAD')
source = 'def bad(x):\n' + ''.join(f'    if x == {i}: return {i}\n' for i in range(7)) + '    return 0\n'
(repo / 'b').mkdir(exist_ok=True)
(repo / 'b/app.py').write_text(source, encoding='utf-8')
git('-c', 'core.hooksPath=', 'add', 'b/app.py')
cfg = load_config_text('[crapkit]\ntarget=6\n[[scope]]\nname="core"\npaths=["b"]\nlanguages=["python"]\ncoverage_optional=true\n')
for label, key, value in [('default', 'color.ui', 'false'),
                          ('color_always', 'color.ui', 'always'),
                          ('mnemonic', 'diff.mnemonicPrefix', 'true'),
                          ('noprefix', 'diff.noprefix', 'true')]:
    git('config', 'color.ui', 'false')
    git('config', 'diff.mnemonicPrefix', 'false')
    git('config', 'diff.noprefix', 'false')
    git('config', key, value)
    diff = gitio.staged_diff(repo)
    (BASE / f'diff-{label}.txt').write_text(diff, encoding='utf-8')
    record = {'ranges': changed_ranges(diff)}
    try:
        result = gate_staged(repo, cfg)
        record['gate'] = {'violations': [r._asdict() for r in result.violations],
                          'unscoped': result.unscoped}
        with gitio.staged_reads(repo) as reads:
            started = gate_staged(repo, cfg, reads)
        record['started_gate'] = {'violations': [r._asdict() for r in started.violations],
                                  'unscoped': started.unscoped}
    except Exception as exc:
        record['gate'] = {'exception': type(exc).__name__, 'message': str(exc)}
    OUT[f'diff_{label}'] = record

(BASE / 'admission-and-diff.json').write_text(json.dumps(OUT, indent=2), encoding='utf-8')
print(json.dumps(OUT, indent=2))
