"""Read-only public-seam probes; no POSIX filesystem behavior is claimed."""
import argparse
import io
import json
from contextlib import redirect_stdout
from pathlib import Path
import sys
from unittest.mock import patch

sys.dont_write_bytecode = True
sys.path.insert(0, 'C:/Users/jfgag/crapkit/src')
from crapkit.churn import parse_git_log
from crapkit.cli import queue
from crapkit.config import Config, Scope
from crapkit.snapshot import InventoryRow
from crapkit.universe import scan_files
from crapkit.worklist import build_worklist

BASE = Path(__file__).parent
out = {}
exact = r'src/a\b.py'
cfg = Config(scopes=(Scope('src', ('src',), ('python',)),))
assigned = scan_files([exact], cfg)
churn = parse_git_log('\x01author\n"src/a\\\\b.py"\n')
row = InventoryRow('src', assigned.by_scope['src'][0], 'f', 1, 9, 8, 8, 8, 9, 0, 0)
worklist = build_worklist([row], churn, floor=5, top=1)
out['tracked_path'] = {
    'scope_of_probe': 'Pure Python seam. The literal-backslash filename is valid on POSIX; no POSIX filesystem test was performed.',
    'exact_input': exact, 'assigned': assigned._asdict(), 'churn_keys': list(churn),
    'active_total': worklist.active_total,
    'dormant': [e._asdict() for e in worklist.dormant],
}

claim = {'id': 7, 'path': 'src/app.py', 'long_name': 'f( )', 'handle': 'f',
         'key_name': 'f( )', 'key_version': 1, 'commit': 'same'}
class ReadOnlyClaims:
    def __init__(self):
        self.requested = []
    def open_claims(self):
        return [claim]
    def close_claims(self, ids):
        self.requested = ids
        return len(ids)

root = BASE / 'named-root'
stand = root / 'src'
out['claims_release'] = {'scope_of_probe': 'Public cmd_claims with a read-only fake store and declared working directory. No claim rows were written or released.',
                         'root': str(root), 'stand': str(stand),
                         'shared_rebased_path': queue._repo_relative('app.py', root, stand), 'cases': {}}
for name in ('app.py', 'src/app.py', './src/app.py', r'src\app.py'):
    store = ReadOnlyClaims()
    args = argparse.Namespace(repo=None, action='release', all=False, target=[name,'f'], json=True)
    current = stand if name == 'app.py' else root
    record = {'stand': str(current)}
    with patch.object(queue, '_command_root', return_value=root), patch.object(queue, '_open_store', return_value=store), patch.object(Path, 'cwd', return_value=current):
        captured = io.StringIO()
        try:
            with redirect_stdout(captured):
                record['exit'] = queue.cmd_claims(args)
            record['stdout'] = captured.getvalue()
            record['requested_closures'] = store.requested
        except Exception as exc:
            record['exception'] = type(exc).__name__
            record['message'] = str(exc)
    out['claims_release']['cases'][name] = record

(BASE/'root-path-results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
