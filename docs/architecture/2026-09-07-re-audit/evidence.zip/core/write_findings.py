"""Compile this bounded audit's measured results and reviewed source references."""
import json
from pathlib import Path

base = Path(__file__).parent
evidence = str(base).replace('\\', '/')
root = 'C:/Users/jfgag/crapkit/'
def ref(path, start, end):
    return {'file': root+path, 'start': start, 'end': end}
def ev(name):
    return evidence+'/'+name

findings = {
 'commit': 'b11e2c165411b5ff9caa6b4b8486aafe477dfeb8',
 'scope': 'Core analysis, readers, coverage parsing, Git facts/paths, caching, churn, coupling and duplication',
 'candidates': [
  {
   'id': 'CORE-01',
   'title': 'Make the Git diff module own the format its consumers parse',
   'recommendation': 'Strong',
   'classification': 'Proved correctness defect',
   'files': [ref('src/crapkit/gitio.py',34,38), ref('src/crapkit/gitio.py',138,162),
             ref('src/crapkit/gitio.py',375,380), ref('src/crapkit/diffparse.py',41,49),
             ref('src/crapkit/hook.py',143,156)],
   'problem': 'The Git adapter fixes relative paths and quoting but inherits display configuration. Its consumers require plain unified diff headers with a known new-side prefix. A user can change display preferences and make the gate miss a staged function.',
   'trigger': 'A repository or global Git configuration sets color.ui=always, diff.mnemonicPrefix=true, or diff.noprefix=true. The no-prefix case additionally requires a real path beginning b/.',
   'evidence_paths': [ev('probe_admission_and_diff.py'),ev('admission-and-diff.json'),
                      ev('diff-default.txt'),ev('diff-color_always.txt'),ev('diff-mnemonic.txt'),ev('diff-noprefix.txt')],
   'actual_outcomes': [
      'Default config: staged b/app.py produces changed range 1..9 and one gate violation at ccn=8.',
      'color.ui=always: changed_ranges returns {}, and both GitReads and the prestarted staged_reads adapter return zero violations and zero unscoped notices.',
      'diff.mnemonicPrefix=true: the same staged file becomes i/b/app.py and returns zero violations, plus an unscoped notice for the wrong path.',
      'diff.noprefix=true: the real b/ directory is stripped, so the file becomes app.py and returns zero violations, plus an unscoped notice for the wrong path.',
      'The clone shares frozen objects and has its own index/config. The probe creates no Git commits and does not modify the audited checkout.'
   ],
   'deletion_test': 'Deleting gitio would scatter process flags and record framing across the gate, verify, rescore, mutation selection and history readers. The module earns its place. Deepen its current interface by keeping the diff-format requirements inside the adapter.',
   'solution': 'Have every parsed diff request a fixed, machine-readable format, independent of user display preferences. Apply that rule to both ordinary reads and prestarted reads. Keep configuration inspection able to read the actual user setting.',
   'locality': 'The Git module owns the format once, so diffparse and each verdict caller stop depending on ambient Git preferences.',
   'leverage': 'One fix protects the pre-commit gate, verify changed-line selection, rescore, and mutation targeting. The existing GitReads and prestarted adapters provide real variation at the seam.',
   'tests_to_preserve_or_add': [
      'Add real-Git tests that pass the same staged ccn=8 source through gate_staged with normal and prestarted reads under color, mnemonic-prefix and no-prefix settings.',
      'Preserve nested-root paths, C-quoted paths, Unicode separators, renamed-file handling, literal added +++ source lines and config_value tests.',
      'Check diff_since callers against the same pinned format and cover user-defined diff prefixes/output settings before declaring the family fixed.'
   ],
   'before_diagram': 'Git display config --> GitReads / prestarted reads --> variable diff text --> fixed diffparse assumptions --> empty or wrong changed paths --> gate passes',
   'after_diagram': 'Git display config --> Git diff module with fixed record format --> both read adapters --> exact changed paths --> gate judges the staged function',
   'costs_risks': ['Small implementation scope, but audit all diff-producing paths so only one adapter is not repaired.',
                   'Keep human configuration inspection separate from flags used for machine-readable output. Do not globally change repository or user Git configuration.',
                   'No measured spawn or parsing overhead is required by the correction.'],
   'adr_conflict': None
  },
  {
   'id': 'CORE-02',
   'title': 'Admit coverage measurements before they become scoring facts',
   'recommendation': 'Strong',
   'classification': 'Proved correctness defect on malformed finite artifact counters',
   'files': [ref('src/crapkit/coverage_py.py',22,32),ref('src/crapkit/coverage_istanbul.py',17,33),
             ref('src/crapkit/covstream.py',39,46),ref('src/crapkit/score.py',22,23)],
   'problem': 'The shared JSON reader rejects nonfinite numeric tokens, but the coverage.py adapter copies finite counters into FnCoverage without checking their meaning. A measurement can claim more covered branches than total branches, or a negative total. The scorer receives an impossible coverage value shaped like an ordinary measurement.',
   'trigger': 'A coverage artifact contains covered_branches=4 and num_branches=2, or contains a negative branch total. This requires malformed or manually altered artifact bytes; the probe does not claim coverage.py normally emits them.',
   'evidence_paths': [ev('probe_admission_and_diff.py'),ev('admission-and-diff.json'),ev('focused-checks.txt')],
   'actual_outcomes': [
      'Valid control, covered=1 and total=2: cov=0.5, ccn=6, CRAP=10.5, remedy=add-tests.',
      'covered=4 and total=2: public parse_coveragepy_file then score_rows returns cov=2.0, CRAP=-30.0, remedy=ok.',
      'covered=0 and total=-2: the branch count loses to statement fallback, returning cov=1.0 and CRAP=6.0.',
      'Negative covered counts, boolean counts and fractional counts are also accepted.',
      'Existing nonfinite-number tests pass and cover a separate, already solved defect.'
   ],
   'deletion_test': 'The coverage adapters earn their place by hiding artifact shape and attribution. Removing them would put format rules into the scorer and lane callers. Remove the unchecked passage from decoded JSON to trusted measurement instead of adding checks to each downstream consumer.',
   'solution': 'Give artifact admission responsibility for valid coverage counts and relationships. Reject impossible measurements with the artifact path and function named, then let scoring keep its simple arithmetic. Check both adapter formats for the same domain promises, while preserving their different attribution rules.',
   'locality': 'Count validation belongs where external artifact values become coverage facts. Scoring and verdict code can then rely on coverage remaining between zero and one.',
   'leverage': 'The reader seam protects every consumer of the scored run, including the worklist, gate, ratchet and reports, without duplicating validation in them.',
   'tests_to_preserve_or_add': [
      'Add public-file-reader-to-score tests for covered greater than total, negative counters, booleans and fractional counters, for branch and statement totals.',
      'Preserve legitimate zero-branch statement fallback, zero-statement invocation fallback, branchless-report warnings and regionless-file salvage.',
      'Keep nonfinite JSON, streaming chunk framing, artifact digests and same-span refusal checks.'
   ],
   'before_diagram': 'JSON numeric syntax check --> unchecked coverage.py summary --> FnCoverage ratio 2.0 --> CRAP -30 --> ok',
   'after_diagram': 'Streaming JSON --> coverage adapter admits counts and relationships --> valid FnCoverage --> simple score arithmetic; invalid artifact --> named refusal',
   'costs_risks': ['No evidence of a normal producer emitting these values. This is artifact admission robustness with a proved wrong-result outcome.',
                   'Validation must preserve existing fallback behavior for valid reports. Avoid silently clamping corrupt counts into a plausible score.',
                   'A semantics change needs review against the repository ANALYSIS_VERSION rule.'],
   'adr_conflict': None
  },
  {
   'id': 'CORE-03',
   'title': 'Give duplicate ranking a complete deterministic order',
   'recommendation': 'Strong',
   'classification': 'Proved deterministic-output defect',
   'files': [ref('src/crapkit/dup.py',29,30),ref('src/crapkit/dup.py',89,125),ref('src/crapkit/dup.py',233,242)],
   'problem': 'The inverted shingle index introduces pairs in hash-dependent order. The final ranking sorts on similarity and the first function only. Tied pairs sharing that function keep their random insertion order, and top truncation exposes the difference to callers.',
   'trigger': 'One function has two equally similar duplicates in other files. Their shared shingles differ, and the returned top cut intersects the tie. The probe uses the default similarity and min_lines settings.',
   'evidence_paths': [ev('probe_duplication.py'),ev('duplication-results.json'),ev('duplication-stdout.json')],
   'actual_outcomes': [
      'The same three source strings and inventory rows return a.py+b.py with PYTHONHASHSEED 1,3,9,10.',
      'They return a.py+c.py with PYTHONHASHSEED 2,4,5,6,7,8.',
      'Both pairs have similarity 0.8095. Only the process hash seed changes; top=1 and default similarity=0.8 remain fixed.',
      'The existing duplication tests pass, including within-process ordering and twin/pair agreement.'
   ],
   'deletion_test': 'The duplication module hides source normalization, containment and pairing for callers, so deleting it would spread real complexity. Its depth needs a complete ranking guarantee, not an extra wrapper or a new module.',
   'solution': 'Make pair ordering total over both functions and the relevant identity fields before applying the requested cut. Keep randomized shingles internal to matching; they must not decide which pair a caller sees.',
   'locality': 'The duplicate-ranking module owns stable tie handling once, so CLI, MCP and report callers do not need to resort or retain extra pairs.',
   'leverage': 'Stable output makes repeated runs reviewable and makes top-N decisions consistent across processes and platforms.',
   'tests_to_preserve_or_add': [
      'Run the same tied-pair fixture in fresh Python processes with several hash seeds, and assert identical ordered payloads at top=1 and without an intersecting cut.',
      'Preserve containment scoring, nested-span exclusion, min_lines admission, twins, process-local index reuse and released source-text behavior.',
      'Include both function identities in tests so equal start lines and same-named functions cannot form another unresolved tie.'
   ],
   'before_diagram': 'Function sources --> randomized shingle insertion --> shared pair map --> partial sort key --> process-dependent top pair',
   'after_diagram': 'Function sources --> shingle matching --> complete pair ranking --> stable top pair',
   'costs_risks': ['Small correction in the existing ranking module. A tie may intentionally return a different pair after the fix, but it will then remain stable.',
                   'This evidence establishes output nondeterminism, not a changed similarity score or verdict.'],
   'adr_conflict': None
  },
  {
   'id': 'CORE-04',
   'title': 'Let the duplicate result limit bound retained pair work',
   'recommendation': 'Worth exploring',
   'classification': 'Measured synthetic cost; consumer frequency unmeasured',
   'files': [ref('src/crapkit/dup.py',118,125),ref('src/crapkit/dup.py',233,242)],
   'problem': 'A request for one duplicate pair builds counts for every pair, then allocates payloads for every qualifying pair, sorts them all and discards all but one. A clone-heavy corpus makes retained work quadratic despite the small requested result.',
   'trigger': 'Many admitted functions share their normalized body. The probe uses 150, 300 and 600 functions in separate synthetic files, each 11 lines, with top=1.',
   'evidence_paths': [ev('probe_duplication.py'),ev('duplication-results.json')],
   'actual_outcomes': json.loads((base/'duplication-results.json').read_text())['benchmark'],
   'deletion_test': 'Removing the result limit would remove a promise callers need. Removing the inverted index would move cost to broad pair comparisons. Keep both concepts, but make the module retain only the ranking state needed for the requested answer where exact matching permits it.',
   'solution': 'Explore bounded candidate retention and delayed payload creation inside the duplicate module, preserving exact scores and total ordering. Measure consumer corpora before choosing a broader algorithm change.',
   'locality': 'The duplicate module owns the cost of its top argument, rather than requiring callers to prefilter or sample rows and change the answer.',
   'leverage': 'Small duplicate requests can avoid paying for payloads that no caller receives. A successful change benefits CLI and MCP duplicate queries directly.',
   'tests_to_preserve_or_add': [
      'Compare bounded results with the current exhaustive result on small random corpora, ties, containment and multiple top values.',
      'Retain clone-heavy peak-allocation and runtime probes; timings currently include tracemalloc overhead and are not production latency figures.',
      'Preserve early source-text release and singleton-owner optimization.'
   ],
   'before_diagram': '600 functions --> 179700 pair counts --> 179700 pair payloads --> sort all --> return 1',
   'after_diagram': 'Functions --> exact matching with bounded retained ranking --> build selected payloads --> return requested pairs',
   'costs_risks': ['The benchmark is synthetic; no production out-of-memory incident or normal-corpus frequency was measured.',
                   'Exact containment ranking may still require quadratic comparisons for dense overlap. Lower retained memory is a narrower, testable objective than promising linear work.',
                   'Use CORE-03 complete ordering as a prerequisite so a memory optimization does not preserve random ties.'],
   'adr_conflict': None
  }
 ],
 'coverage': [
  {'modules':['src/crapkit/analyze.py','src/crapkit/cache.py'],
   'checks':['Read registration, source decode, reader/content cache identity, typed cache decoding, stat stamps, worker verification, pool selection and cold duplicate sharing.',
             'Ran selected cache identity, cold duplicate and typed-mode tests; inspected source-mutation regression tests.'],
   'sound':['Reader and TypeScript mode are part of cache identity.', 'Workers hash and parse the same captured bytes.', 'Cold identical files parse once, then retain distinct path records.', 'Typed corrupt cache rows rebuild cold.']},
  {'modules':['src/crapkit/snapshot.py','src/crapkit/repotext.py'],
   'checks':['Read deterministic inventory sort and streamed TSV export; ran snapshot tests.', 'Read shared UTF-8 BOM decoding and targeted UTF-16 rejection.'],
   'sound':['Inventory ordering includes occurrence and handles shared-line functions.', 'Repository text has a shared decoder for captured and file-read bytes.'],
   'cross_owner_lead':'Raw tab/newline fields in TSV export were forwarded to the parent owning portable state for assessment.'},
  {'modules':['src/crapkit/coverage_py.py','src/crapkit/coverage_istanbul.py','src/crapkit/covstream.py'],
   'checks':['Read complete JSON framing, chunk refill/value completion, format projections, branch/statement/invocation fallbacks, smallest-span heap ownership and context selection.',
             'Ran streaming reader contract, nonfinite-number and same-span checks.', 'Probed malformed finite counters through reader and score seam.'],
   'sound':['One artifact walk supplies measurements, missing lines and the digest of the same bytes.', 'Nonfinite tokens and trailing malformed JSON are refused.', 'Same-span measured source functions are refused instead of sharing ambiguous coverage.']},
  {'modules':['src/crapkit/lizardcognitive.py','src/crapkit/lizardtypescript.py','src/crapkit/lizardrust.py','src/crapkit/lizardshell.py','src/crapkit/lizardpowershell.py','src/crapkit/_pygdefer.py'],
   'checks':['Read cognitive token ownership, function state, nesting, shell block logic and reader-specific placement.',
             'Read TypeScript expression state, Rust match adapter, shell heredoc/token/function reader, PowerShell tokens/switch/function reader and deferred Pygments lifecycle.',
             'Ran cognitive-reader-chain and TypeScript-expression tests. Reviewed Rust and reader registration contracts.'],
   'sound':['Reader registration lives at analyze module scope for spawned workers.', 'Python reads function ownership after lizard processes the token.', 'Swift/Kotlin receive the chain position their draining preprocessor requires.', 'Ambiguous TypeScript angle syntax produces an explicit refusal.', 'Pygments proxies leave sys.modules after the import context.']},
  {'modules':['src/crapkit/gitio.py','src/crapkit/gitpaths.py','src/crapkit/diffparse.py'],
   'checks':['Read ordinary and streamed commands, NUL framing, staged batch reads, prestarted adapters, GitFacts, HEAD fast path, worktree lifecycle and diff hunk parser.',
             'Ran diff parser tests and probed display-config changes with real Git through both staged-read adapters.'],
   'sound':['Exact NUL path records avoid stripping spaces and Unicode separators.', 'Staged blob framing respects binary body sizes and falls back for line-bearing names.', 'The ref fast path falls back to Git when it cannot prove an object name.', 'Worktree reset guards against a missing .git before destructive cleanup.']},
  {'modules':['src/crapkit/churn.py','src/crapkit/churn_cache.py','src/crapkit/churn_log.py','src/crapkit/coupling.py','src/crapkit/coupling_cache.py'],
   'checks':['Read log header/path framing, recency math, per-file map cache, compressed log publication/refresh, pair counting/filtering and ranked cache keys.', 'Reviewed concurrent churn-log publication regression tests and cache contracts.'],
   'sound':['Compressed log publication uses operation-owned temporary files and verifies compressed size/CRC before serving.', 'Tracked-index digest retires coupling pairs after staged removals without a HEAD change.', 'Large commits are excluded from pairing and dead names filtered before truncation.']},
  {'modules':['src/crapkit/dup.py'],
   'checks':['Read normalization, process-local index, singleton owners, shared pair counts, containment, twins and ranking.', 'Ran duplication tests, ten fresh-process hash-seed probes, and three bounded dense-clone allocation probes.'],
   'sound':['Sources are released before pair payload work.', 'Single-target twins and batch index reuse avoid repeated whole-repository shingling.', 'Nested source spans are not reported as ordinary duplicate pairs.']}
 ],
 'dismissed': [
  {'lead':'Replace the cache partition module solely because it is small.', 'reason':'It centralizes fingerprint invalidation and partial-run merging. Deletion moves those rules into callers; no new failure or measured maintenance cost justifies removal.'},
  {'lead':'Cold duplicate inputs are parsed independently.', 'reason':'Already fixed. Current tests prove one parser call for identical content and the correct reader/type identity.'},
  {'lead':'Hashing and parser reads publish records under mismatched source bytes.', 'reason':'Already fixed for analysis jobs by verified captured bytes. The worker/source tests exercise edit and delete races.'},
  {'lead':'The streaming reader repeatedly decodes an incomplete large JSON member.', 'reason':'Already fixed by _ValueFrame and one final raw_decode. Existing value-decoding checks document this case.'},
  {'lead':'Same-line measured functions silently share coverage.', 'reason':'The recent same-span guard refuses the ambiguity. The focused tests pass.'},
  {'lead':'Remove Pygments deferral or reader registration wrappers as shallow indirection.', 'reason':'Deferral has a documented startup cost, and reader adapters replace real unsupported or incorrect behavior. Deletion restores cost or wrong measurements. No new failure was reproduced.'},
  {'lead':'Treat known PowerShell casing/parameter limits, UTF-16 source handling, Rust macro arms and shell substitutions as newly discovered defects.', 'reason':'These are explicit existing reader limits with documented conventions. No new consumer case or broader parser design was measured in this audit.'},
  {'lead':'Persist builtin-hash duplicate shingles for faster warm queries.', 'reason':'The index is deliberately process-local because Python hashes are randomized. A disk cache would need a stable representation and measured benefit.'},
  {'lead':'Reopen compressed churn-log concurrent publication.', 'reason':'Operation-owned .part files and size/CRC binding now prevent one writer attaching its key to another writer bytes. The new concurrency regression tests cover the known race.'},
  {'lead':'Claim dense duplicate memory cost occurs in ordinary consumer repos.', 'reason':'The new measurements use a synthetic clone-heavy corpus. CORE-04 labels the narrower evidence and asks for consumer frequency before broader redesign.'}
 ],
 'verification': {
   'focused_result':'180 passed in 1.26s', 'output':ev('focused-checks.txt'),
   'reproduction_scripts':[ev('probe_admission_and_diff.py'),ev('probe_duplication.py')],
   'repository_after':'git status --short empty; HEAD remains b11e2c165411b5ff9caa6b4b8486aafe477dfeb8',
   'limits':'No full test suite, package installation, production source edit, Git commit, external action, or root audit ledger/artifact mutation. All scripts, caches, clone/index/config mutations, test temp directories and outputs are confined to core/.'
 }
}
(base/'findings.json').write_text(json.dumps(findings,indent=2),encoding='utf-8')
print(f"Saved {len(findings['candidates'])} candidates covering {sum(len(c['modules']) for c in findings['coverage'])} modules")
