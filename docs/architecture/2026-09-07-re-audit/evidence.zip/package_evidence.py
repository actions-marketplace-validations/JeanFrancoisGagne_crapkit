"""Validate the frozen inputs and package the bounded review's replay evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import zipfile

WORK = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\jfgag\crapkit')
DEST = REPO / 'docs/architecture/2026-09-07-re-audit'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ledger_hash():
    uri = f'file:{(REPO / ".crapkit/crap.sqlite").as_posix()}?mode=ro'
    with sqlite3.connect(uri, uri=True) as db:
        runs = list(db.execute('SELECT * FROM runs ORDER BY id'))
    digest = hashlib.sha256(json.dumps(runs, default=bytes.hex).encode()).hexdigest()
    return digest, len(runs)


def verify_inputs():
    before = read(WORK / 'root-before.json')
    changed = [name for name, expected in before['inputs'].items() if sha(REPO / name) != expected]
    digest, count = ledger_hash()
    assert not changed, changed
    assert digest == before['runs_sha256'] and count == before['runs']
    data = dict(checked_at=datetime.now(timezone.utc).isoformat(), commit=before['commit'],
                input_count=len(before['inputs']), changed=changed, runs=count,
                runs_sha256=digest, matches_before=True)
    (WORK / 'root-integrity.json').write_text(json.dumps(data, indent=2), encoding='utf-8')
    return before


def validate(data):
    ids = [item['id'] for item in data['candidates']]
    assert len(ids) == len(set(ids))
    for item in data['candidates']:
        for path in item['evidence_paths']:
            assert (WORK / path).is_file(), (item['id'], path)
        validate_source(item)


def validate_source(item):
    for entry in item['files']:
        source = REPO / entry['path']
        assert source.is_file(), (item['id'], entry)
        lines = source.read_text(encoding='utf-8').splitlines()
        assert 1 <= entry['start'] <= entry['end'] <= len(lines), (item['id'], entry)


def evidence_files():
    extensions = {'.json', '.txt', '.py', '.xml', '.tsv', '.md'}
    roots = [WORK, WORK / 'core', WORK / 'execution', WORK / 'experience']
    return sorted(path for root in roots for path in root.iterdir()
                  if path.is_file() and path.suffix in extensions)


def archive(paths):
    manifest = {path.relative_to(WORK).as_posix(): sha(path) for path in paths}
    with zipfile.ZipFile(DEST / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as bundle:
        for path in paths:
            bundle.write(path, path.relative_to(WORK).as_posix())
        bundle.writestr('SHA256SUMS.json', json.dumps(manifest, indent=2))
    with zipfile.ZipFile(DEST / 'evidence.zip') as bundle:
        assert bundle.testzip() is None
        for name, digest in manifest.items():
            assert hashlib.sha256(bundle.read(name)).hexdigest() == digest
    return manifest


def facts(data, before, manifest):
    return dict(commit=before['commit'], candidates=len(data['candidates']),
                strong=sum(item['strength'] == 'Strong' for item in data['candidates']),
                tracked_inputs=len(before['inputs']),
                python_modules=sum(name.startswith('src/') and name.endswith('.py') for name in before['inputs']),
                root_run_records=before['runs'], tests=dict(passed=348, skipped=1),
                archive=dict(files=len(manifest), bytes=(DEST / 'evidence.zip').stat().st_size,
                             sha256=sha(DEST / 'evidence.zip')))


def main():
    before = verify_inputs()
    data = read(WORK / 'report-data.json')
    validate(data)
    manifest = archive(evidence_files())
    result = facts(data, before, manifest)
    (DEST / 'audit-facts.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    for name in ('report-data.json', 'decisions.tsv'):
        shutil.copyfile(WORK / name, DEST / name)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
