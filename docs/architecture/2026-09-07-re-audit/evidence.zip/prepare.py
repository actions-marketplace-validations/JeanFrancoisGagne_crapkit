"""Freeze audit inputs and prepare an isolated Crapkit self-review checkout."""
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess

REPO = Path(r'C:\Users\jfgag\crapkit')
WORK = Path(__file__).resolve().parent
COMMIT = 'b11e2c165411b5ff9caa6b4b8486aafe477dfeb8'


def git(*args, root=REPO):
    return subprocess.check_output(['git', *args], cwd=root)


def snapshot():
    assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
    names = git('ls-files', '-z').decode().split('\0')
    hashes = {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest()
              for name in names if name}
    with sqlite3.connect(f'file:{(REPO / ".crapkit/crap.sqlite").as_posix()}?mode=ro', uri=True) as db:
        runs = list(db.execute('SELECT * FROM runs ORDER BY id'))
        with sqlite3.connect(WORK / 'root-before.sqlite') as saved:
            db.backup(saved)
    data = dict(commit=COMMIT, inputs=hashes, runs_sha256=hashlib.sha256(
        json.dumps(runs, default=bytes.hex).encode()).hexdigest(), runs=len(runs))
    (WORK / 'root-before.json').write_text(json.dumps(data, indent=2)+'\n')
    return data


def clone():
    target = WORK / 'self-checkout'
    subprocess.run(['git', 'clone', '--shared', '--no-checkout', str(REPO), str(target)], check=True)
    git('checkout', '--detach', COMMIT, root=target)
    state = target / '.crapkit'
    state.mkdir(exist_ok=True)
    shutil.copy2(WORK / 'root-before.sqlite', state / 'crap.sqlite')
    shutil.copytree(REPO / '.crapkit/cov', state / 'cov')
    for name in ('artifacts.json', 'stat-stamps.json'):
        shutil.copy2(REPO / '.crapkit' / name, state / name)
    return target


if __name__ == '__main__':
    data = snapshot()
    target = clone()
    print(json.dumps(dict(commit=COMMIT, tracked_inputs=len(data['inputs']),
                          prior_runs=data['runs'], checkout=str(target))))
