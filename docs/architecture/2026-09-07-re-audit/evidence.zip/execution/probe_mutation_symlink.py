"""Bounded real-Git proof: a worker's tracked symlink reaches source outside it."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
sys.path.insert(0, 'C:/Users/jfgag/crapkit/src')
from crapkit.mutate import file_mutants
from crapkit.mutate_pool import run_mutants

root = HERE / ('mutation-symlink-' + str(time.time_ns()))
repo = root / 'repo'
repo.mkdir(parents=True)
original = 'def enabled():\n    return True\n'
outside = root / 'source.py'
outside.write_text(original)
os.symlink(outside, repo / 'm.py')
(repo / '.gitignore').write_text('.crapkit/\n__pycache__/\n')
(repo / 'runner.py').write_text(
    'from pathlib import Path\nimport m\n'
    'if not m.enabled():\n'
    f'    Path({str(root / "observed-external.txt")!r}).write_text(Path({str(outside)!r}).read_text())\n')

def git(*args):
    return subprocess.run(['git', '-c', 'core.hooksPath=' + str(root / 'no-hooks'), *args], cwd=repo,
                          capture_output=True, text=True, check=True).stdout

git('init', '-q', '-b', 'main')
git('config', 'core.symlinks', 'true')
git('add', '.')
git('-c','user.name=Probe','-c','user.email=probe@example.invalid','commit','-qm','symlink probe')
mutant = file_mutants(original, None, 'python')[0]._replace(path='m.py')
cfg = SimpleNamespace(mutation_workers=1, mutation_timeout_seconds=5,
                      mutation_command=f'"{sys.executable}" runner.py')
result = run_mutants(repo, cfg, [mutant], lambda *args: None)
data = {'probe_root': str(root), 'git_entry': git('ls-files','--stage','m.py').strip(),
        'worker_is_symlink': (repo / '.crapkit/mutate-pool/w0/m.py').is_symlink(),
        'result': result, 'outside_during_mutation': (root / 'observed-external.txt').read_text(),
        'outside_after_mutation': outside.read_text(), 'original': original}
(HERE / 'mutation-symlink-result.json').write_text(json.dumps(data, indent=2))
print(json.dumps(data, indent=2))
