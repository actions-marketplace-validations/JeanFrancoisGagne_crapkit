"""Capture the bounded review with exact current source excerpts."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('C:/Users/jfgag/crapkit')
PARENT = HERE.parent

def refs(path, start, end):
    lines = (ROOT / path).read_text(encoding='utf-8').splitlines()
    return {'path': path, 'start': start, 'end': end,
            'source': [{'line': number, 'text': lines[number-1]}
                       for number in range(start, end+1)]}

def evidence(name):
    path = PARENT / name
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

verdict = json.loads((PARENT / 'verdict-result.json').read_text(encoding='utf-8'))
records = json.loads((PARENT / 'records-result.json').read_text(encoding='utf-8'))
trust = json.loads((HERE / 'verdict-trust-result.json').read_text(encoding='utf-8'))
junit = json.loads((HERE / 'junit-admission-result.json').read_text(encoding='utf-8'))
review = {
    'frozen_commit': 'b11e2c165411b5ff9caa6b4b8486aafe477dfeb8',
    'source_root': str(ROOT),
    'scope': 'Review root verdict, portable records and packet command probes; check declared JUnit count admission.',
    'root_probes_rerun_by_reviewer': False,
    'root_clean_after_checks': True,
    'reviewed_inputs': [evidence(name) for name in ('probe_verdict.py', 'verdict-result.json',
                                                  'probe_records.py', 'records-result.json')],
    'reviews': [
        {
            'id': 'verdict-override', 'disposition': 'Confirmed defect', 'strength': 'Strong',
            'trigger': 'A verify run has both overridable gate debt and diff coverage above the configured cap; the caller supplies --override.',
            'observed': {'control_exit': verdict['control']['exit'],
                         'override_exit': verdict['override']['exit'],
                         'override_json_ok': verdict['override']['result']['ok'],
                         'diff_uncovered_count': verdict['override']['result']['diff_uncovered_count'],
                         'diff_uncovered_max': verdict['override']['result']['diff_uncovered_max'],
                         'ledger': verdict['ledger'], 'trust': trust},
            'validity': 'The fixture establishes a real coverage baseline, changes tracked source, and runs the public verify CLI against valid current artifacts. Its no-op local alert command exercises override handling without sending a message. --no-tighten isolates ratchet writes. Artifact reuse does not waive the diff coverage cap.',
            'cause': 'cmd_verify sets ok false for the diff breach, then gate override sets ok true without the breach. Exit selection still sees the breach; JSON and persistence only see verdict.ok. Store trust therefore accepts run 3 and clears run 2 as a failure blocker.',
            'files': [refs('src/crapkit/cli/verifying.py',241,246),
                      refs('src/crapkit/cli/verifying.py',294,308),
                      refs('src/crapkit/cli/verifying.py',398,404),
                      refs('src/crapkit/cli/verifying.py',449,456),
                      refs('src/crapkit/cli/verifying.py',485,492),
                      refs('src/crapkit/cli/verifying.py',640,658),
                      refs('src/crapkit/store.py',1355,1376),
                      refs('src/crapkit/store.py',1391,1398)],
            'additional_evidence': [str(HERE/'probe_verdict_trust_readonly.py'), str(HERE/'verdict-trust-result.json')],
            'limit': 'The extra check uses list_runs on a SQLite mode=ro connection and pure trust functions. It does not run a subsequent verify or modify the ledger.'
        },
        {
            'id': 'portable-records', 'disposition': 'Confirmed defect', 'strength': 'Strong',
            'trigger': 'A tracked Python filename contains U+2028 and its scored rows are exported to a portable baseline or a ratchet record.',
            'observed': {'control_export_exit': records['control']['export']['exit'],
                         'control_import_exit': records['control']['verify']['exit'],
                         'separator_export_exit': records['separator']['export']['exit'],
                         'separator_import_exit': records['separator']['verify']['exit'],
                         'separator_import_error': records['separator']['verify']['stderr'],
                         'ratchet_error': records['separator']['ratchet']['error']},
            'validity': 'The public CLI scored the real tracked filename and emitted the baseline successfully. The same unchanged tree fails when verify reads that emitted file. The ordinary filename control succeeds. The separate ratchet control uses the public dump/load pair with a real path accepted by the same project.',
            'cause': 'Writers preserve U+2028 inside a field. Both readers use str.splitlines, which treats U+2028 as a record boundary. This violates each writer-reader roundtrip; no malformed source input is required.',
            'files': [refs('src/crapkit/verify.py',48,66), refs('src/crapkit/score.py',72,77),
                      refs('src/crapkit/score.py',92,107), refs('src/crapkit/ratchet.py',161,186),
                      refs('src/crapkit/ratchet.py',212,225)],
            'limit': 'The probe proves U+2028 in paths. It does not claim to cover every delimiter, record version, language identifier or platform.'
        },
        {
            'id': 'packet-scoped-command', 'disposition': 'Confirmed defect', 'strength': 'Strong',
            'trigger': 'On Windows, execute a packet scoped_tests command for src/%CRAPKIT_AUDIT_ONLY%.py while CRAPKIT_AUDIT_ONLY=expanded.',
            'observed': records['packet'],
            'validity': 'The reviewed updated probe sets CRAPKIT_AUDIT_ONLY=expanded in both the printed command and the direct test-scoped control. Both invoke the same configured capture command in the same project; both exit 0. The packet supplies src/expanded.py while test-scoped supplies the literal tracked path.',
            'cause': 'packet.scoped_test_command builds a shell command by double-quoting raw filenames. cmd.exe expands percent variables inside double quotes. cmd_test_scoped uses prepare_template, whose Windows adapter carries literal arguments through environment transport.',
            'files': [refs('src/crapkit/packet.py',107,118), refs('src/crapkit/cli/verifying.py',788,802),
                      refs('src/crapkit/procs.py',37,57), refs('src/crapkit/procs.py',75,87)],
            'limit': 'Measured on Windows only. Shell interpretation differences elsewhere require their own checks. The packet gate command is a separate untested sink.'
        }
    ],
    'candidates': [{
        'id': 'MEASURE-01',
        'title': 'Apply the JUnit completeness rule before admitting a lane measurement',
        'strength': 'Strong',
        'files': [refs('src/crapkit/junitparse.py',87,105), refs('src/crapkit/junitparse.py',118,136),
                  refs('src/crapkit/lanes.py',947,960), refs('src/crapkit/lanes.py',970,991),
                  refs('tests/unit/test_lane_abort.py',66,77), refs('tests/unit/test_retest_evidence.py',38,40)],
        'trigger': 'A normal lane command freshly writes valid coverage plus a testsuite declaring tests="10" with only one passed testcase, and exits 0.',
        'problem': 'run_lane accepts the inconsistent report as a finished measurement, records tests_total=1 and no failures, and returns its coverage. The same module rejects that report when reading retry evidence. The completeness rule depends on which reader the adapter calls.',
        'evidence': [{'path': str(HERE/'probe_junit_admission.py'),
                      'result': str(HERE/'junit-admission-result.json'), 'outcome': junit}],
        'deletion_test': 'Deleting the retry guard would remove a tested protection. Deleting normal result admission would discard counts and no-new-failure evidence. The useful subtraction is the duplicate choice of which completeness checks each reader runs.',
        'proposed_deepening': 'Give the JUnit module ownership of consistent report admission, with a narrow interface for extracting counts and test outcomes. Retain the explicit artifact-reuse policy at the lane seam. This adds depth by keeping the completeness rule beside the parsed report.',
        'locality_leverage': 'Locality improves because report checks change in one module. The existing parser and Windows/POSIX execution adapters keep their roles. Leverage is correctness across ordinary lanes and retries, not fewer lines.',
        'tests_to_preserve_add': [
            'Preserve one-DOM parsing, nested suites, optional tests attributes, ordinary failed and skipped cases, worker crashes and session errors.',
            'Preserve retry refusal on an explicit count mismatch and existing literal test ID transport.',
            'Add normal run_lane refusal for a fresh artifact paired with tests="10" and one testcase.',
            'Preserve explicit reuse warnings and counts omission when a report cannot support admission.'
        ],
        'before_after_diagram_content': {
            'before': 'runner -> lane adapter -> suite_summary -> unfinished check -> measured result; retry adapter -> passed_test_ids -> unfinished plus declared-count checks -> retry evidence',
            'after': 'runner or retry adapter -> JUnit module report admission -> requested counts or outcomes; explicit reuse policy remains at the lane seam'
        },
        'costs_risks': [
            'Existing producers with inconsistent declared totals would begin refusing normal execution. Check their fixtures before changing admission.',
            'Keep absent count attributes accepted. Do not infer an expected full suite size from missing metadata.',
            'The current count comparison walks descendant testcases per suite; repeated nested walks need consideration for deep reports.',
            'The architecture change is small. A local admission correction can capture most of its value without a new public interface.'
        ],
        'adr_conflict': 'None found. ADR 0001 covers MCP arguments/results; ADR 0002 covers configuration discovery.',
        'limits': 'Proved only for explicit declared-count mismatch on normal run_lane. No full coverage CLI or baseline write was run for this fixture. Reports that omit counts or lie consistently remain outside this check.'
    }],
    'dismissed': [
        {'claim': 'Normal JUnit count mismatch is an intentional trusted-runner allowance.',
         'reason': 'suite_summary documents refusal of unfinished reports; lane tests state that a freshly produced report determines whether a lane is a measurement. The retry path already treats the same explicit mismatch as incomplete. No test or comment promises acceptance for inconsistent declared counts.'},
        {'claim': 'The original packet direct control proved literal transport under the same environment.',
         'reason': 'The original helper omitted the variable. Parent corrected and replayed it. This review uses only the updated input hash and same-environment results.'},
        {'claim': 'The JUnit check detects every incomplete run.',
         'reason': 'The measurement covers a report whose own declared count contradicts its testcase content. It says nothing about missing or consistently false metadata.'}
    ]
}
(HERE / 'integration-review.json').write_text(json.dumps(review, indent=2, ensure_ascii=True)+'\n', encoding='utf-8')
print(json.dumps({'reviews': len(review['reviews']), 'candidates': len(review['candidates']),
                  'trusted_baseline': trust['selected_baseline_id'], 'junit_lane_accepted': junit['lane_accepted']}))
