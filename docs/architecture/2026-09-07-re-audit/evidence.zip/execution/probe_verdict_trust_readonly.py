"""Read the root probe's ledger without migrations and evaluate trust rules."""
import json
from pathlib import Path
import sqlite3
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, 'C:/Users/jfgag/crapkit/src')
from crapkit.store import SnapshotStore, is_trusted, pick_baseline

evidence = json.loads((HERE.parent / 'verdict-result.json').read_text(encoding='utf-8'))
db = Path(evidence['baseline']['result']['db'])
conn = sqlite3.connect(db.as_uri() + '?mode=ro', uri=True)
# Bypass the constructor: it can migrate. list_runs only reads this connection.
store = object.__new__(SnapshotStore)
store._conn = conn
runs = store.list_runs()
pick = pick_baseline(runs)
data = {'database': str(db), 'sqlite_mode': 'ro',
        'runs': [{k: row[k] for k in ('id', 'kind', 'verdict_ok', 'findings')} for row in runs],
        'trusted_run_ids': [row['id'] for row in runs if is_trusted(row)],
        'selected_baseline_id': pick.run['id'] if pick.run else None,
        'skipped_id': pick.skipped['id'] if pick.skipped else None,
        'blocker_id': pick.blocker['id'] if pick.blocker else None}
conn.close()
(HERE / 'verdict-trust-result.json').write_text(json.dumps(data, indent=2), encoding='utf-8')
print(json.dumps(data, indent=2))
