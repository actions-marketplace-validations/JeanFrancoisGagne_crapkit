"""A command that exits can leave a descendant writing a released artifact."""
import json
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = 'C:/Users/jfgag/crapkit/src'
sys.path.insert(0, SOURCE)
os.environ['PYTHONPATH'] = SOURCE
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
from crapkit.config import Lane
from crapkit.lanes import run_lane, measurement_owner

root = HERE / ('owned-descendant-' + str(time.time_ns()))
root.mkdir()
(root / 'late.py').write_text(
    'from pathlib import Path\nimport time\n'
    'Path("started").touch()\n'
    'deadline=time.monotonic()+10\n'
    'while not Path("release").exists() and time.monotonic()<deadline: time.sleep(.02)\n'
    'Path("cov.json").write_text("OLD_DESCENDANT_WRITE")\n'
    'Path("finished").touch()\n')
artifact = json.dumps({'src/a.py': {'fnMap': {}, 'f': {}, 'branchMap': {}, 'b': {}}})
(root / 'runner.py').write_text(
    'from pathlib import Path\nimport subprocess,sys\n'
    'subprocess.Popen([sys.executable,"late.py"],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)\n'
    f'Path("cov.json").write_text({artifact!r})\n')
lane = Lane(name='probe', command=f'"{sys.executable}" runner.py', artifact='cov.json', parser='istanbul',scopes=())
outcome = run_lane(root, lane)
deadline = time.monotonic()+3
while not (root/'started').exists() and time.monotonic()<deadline:
    time.sleep(.02)
data = {'probe_root':str(root),'lane_exit':outcome.provenance['exit_code'],
        'descendant_started':(root/'started').exists()}
with measurement_owner(root, [lane]):
    (root/'cov.json').write_text('NEW_OWNER_WRITE')
    (root/'release').touch()
    deadline=time.monotonic()+3
    while not (root/'finished').exists() and time.monotonic()<deadline:
        time.sleep(.02)
    data['old_descendant_finished']=(root/'finished').exists()
    data['artifact_while_new_owner_held_lock']=(root/'cov.json').read_text()
(HERE/'owned-descendant-result.json').write_text(json.dumps(data,indent=2))
print(json.dumps(data,indent=2))
