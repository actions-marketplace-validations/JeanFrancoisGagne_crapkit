"""Assemble audit evidence without changing the audited checkout."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path('C:/Users/jfgag/crapkit')

def locations(path, *ranges):
    return [{'path': path, 'start': start, 'end': end} for start, end in ranges]

candidates = [
    {
        'id': 'EX1',
        'title': 'Keep execution ownership until every writing process stops',
        'strength': 'Strong',
        'files': locations('src/crapkit/mutate_pool.py', (65, 66), (103, 108), (178, 189), (284, 301), (333, 350))
                 + locations('src/crapkit/procs.py', (129, 174), (195, 211), (257, 300))
                 + locations('src/crapkit/_process_owner.py', (21, 68))
                 + locations('src/crapkit/lanes.py', (1142, 1154), (1174, 1181)),
        'trigger': 'Kill the mutation caller while its test command is still running, then begin another mutation run. A second demonstrated trigger is a lane command that exits after spawning a child which still owns work.',
        'problem': 'The mutation pool lock dies with the caller, while its suite has a separate process lifetime. The next caller can reset and reuse the same pool before the previous suite stops. The lane helper covers caller death while the registered root lives, but run_bounded unregisters that root on exit without accounting for surviving descendants. File ownership and process lifetime remain facts each adapter must coordinate.',
        'evidence': [
            {'path': str(HERE / 'probe_mutation_crash.py'), 'result': str(HERE / 'mutation-crash-result.json'),
             'outcome': 'Real run_mutants, real Git, one worker: caller terminated; next owner acquired the same pool and read the reset source; the old suite then overwrote the new owner source with CORRUPTED_BY_OLD_SUITE. The original checkout stayed unchanged.'},
            {'path': str(HERE / 'probe_owned_descendant.py'), 'result': str(HERE / 'owned-descendant-result.json'),
             'outcome': 'Real run_lane returned exit 0 after parsing a valid artifact. Under a later measurement_owner lock, the first lane descendant replaced cov.json with OLD_DESCENDANT_WRITE.'},
            {'path': str(HERE / 'bounded-checks.json'),
             'outcome': 'Existing ownership, watch, invocation, mutation-angle, Docker and coverage-floor contracts passed: 58 passed, 1 POSIX-only skip on Windows in 4.484 seconds. Those ownership tests cover live roots and caller death, but not mutation caller death or descendants after root exit.'}
        ],
        'proved_vs_inferred': 'Both conflicting writes are proved on current Windows source. Incorrect future mutation scores, a collision with pool removal, and comparable POSIX failures are consequences to test, not measured results. No claim that ordinary well-behaved suites leave descendants.',
        'deletion_test': 'Deleting procs or the helper moves deadline handling, process registration and lock retention back into lanes and mutation callers, so both modules earn their depth. The opportunity is to delete caller-owned lifetime coordination and the mutation-specific parallel ownership rule by concentrating that behavior at the execution seam.',
        'proposed_deepening': 'Deepen the execution ownership module so process completion, surviving descendants and resource release share one lifecycle. Lane and mutation adapters should receive the same ownership guarantee, while their measurement and worktree policies remain local. Choose detached-command semantics during design rather than silently changing them.',
        'locality': 'Fix caller death and late writers at one process/resource seam instead of maintaining different cleanup guarantees for lanes and mutation pools.',
        'leverage': 'A single lifetime contract covers lane execution, flake retests and mutation workers. Tests can assert resource exclusion through that interface instead of proving isolated lock and spawn helpers separately.',
        'tests_to_preserve': ['tests/e2e/test_measurement_ownership_e2e.py', 'tests/unit/test_measurement_owner.py', 'tests/unit/test_procs.py', 'tests/unit/test_mutate_pool_kept.py', 'tests/unit/test_mutate_nested.py', 'tests/unit/test_mutate_pool.py'],
        'tests_to_add': ['Kill a real mutation caller, then retry while its previous suite is alive; prove no reused pool receives a late write.', 'Run a lane whose test runner exits before a child; prove the chosen ownership completion rule through run_lane.', 'Repeat lifetime probes on Windows and POSIX, preserving shell exit codes, deadlines, live-peer temporary fallback, and pool cleanup.'],
        'before_after': {
            'before': 'Mutation caller -> parent-held pool lock; mutation suite -> independent process tree; caller death -> lock free -> new caller resets pool <- old suite writes. Lane owner -> root PID only -> root exits -> child survives.',
            'after': 'Lane adapter / mutation adapter -> execution ownership module -> writing processes + owned resources; resources become available only after the module settles the writing lifetime.'
        },
        'costs_risks': ['Windows and POSIX need different process adapters, and process identity must remain safe against PID reuse.', 'Detaching a child deliberately may need a stated policy. Do not silently kill intentionally persistent processes without deciding that contract.', 'Retaining a lock longer changes crash recovery timing. Preserve fail-fast lane conflicts and mutation fallback to private temporary trees.', 'The existing lane helper already fixes a real caller-crash failure. Preserve that behavior rather than replacing it with an in-process lock.'],
        'adr_conflict': 'None. ADR 0001 concerns MCP argument results; ADR 0002 concerns repository-root selection. Nested mutation roots must still follow ADR 0002.'
    },
    {
        'id': 'EX2',
        'title': 'Make mutation workspace isolation include filesystem identity',
        'strength': 'Strong',
        'files': locations('src/crapkit/mutate_pool.py', (86, 108), (130, 157), (333, 350))
                 + locations('src/crapkit/gitio.py', (453, 475)),
        'trigger': 'Mutate a tracked source symlink whose destination is outside the private worktree, with Git configured to preserve symlinks.',
        'problem': 'The mutation input snapshot stores bytes and mode after following symlinks. _seed and run_one then write through a worker path without checking what file it names. A detached Git worktree isolates ordinary files but preserves symlink destinations, so the module promise that mutants never write the source tree does not hold.',
        'evidence': [
            {'path': str(HERE / 'probe_mutation_symlink.py'), 'result': str(HERE / 'mutation-symlink-result.json'),
             'outcome': 'Real Git recorded m.py with mode 120000. The kept worker preserved that symlink. During run_mutants, a suite read the source outside the worker as return False; after finally it was return True again. All files in this reproduction were under the audit scratch directory.'}
        ],
        'proved_vs_inferred': 'A write outside the worker during an ordinary mutation is proved on Windows with core.symlinks=true. A killed caller leaving that outside file modified, and hard-link or reparse-point variants, are follow-up cases rather than measured outcomes.',
        'deletion_test': 'Removing the mutation snapshot moves dirty-test/configuration/deletion capture back to worker callers, so it earns its depth. Deleting an extra helper would not solve the defect. The deepening is to concentrate input identity and safe worker materialization behind the workspace interface, removing the assumption that a path under a worktree implies an isolated file.',
        'proposed_deepening': 'Deepen the mutation workspace module to own filesystem admission and materialization together. Establish how tracked and dirty symlinks participate before any worker write, and make source isolation a guarantee callers can rely on. Choose refusal versus safe local materialization during design.',
        'locality': 'Filesystem identity, snapshot capture and mutation writes become one tested rule rather than assumptions spread across _snapshot_file, _seed and run_one.',
        'leverage': 'One workspace seam protects every mutation worker and both kept and temporary trees; callers no longer need to inspect filesystem topology to trust the isolation claim.',
        'tests_to_preserve': ['tests/unit/test_mutate_pool_kept.py: test_every_worker_measures_dirty_tests_config_dependencies_and_deletions', 'tests/unit/test_mutate_nested.py', 'tests/unit/test_mutate_pool.py: worktree preparation and cleanup checks'],
        'tests_to_add': ['Track a symlink to an outside scratch source and assert through run_mutants that the outside source never changes.', 'Exercise relative and absolute links, dirty links, ordinary files and nested roots on platforms that support them.', 'Assert the selected refusal or materialization behavior before any suite starts, and preserve source bytes across exceptions.'],
        'before_after': {
            'before': 'Source symlink -> snapshot of target bytes -> detached worker preserves symlink -> run_one writes worker path -> source outside worker changes.',
            'after': 'Source paths + filesystem identity -> mutation workspace module -> admitted private inputs -> mutant writes stay private.'
        },
        'costs_risks': ['Refusing links limits repositories that use them; materializing them can change import or build semantics. The user should choose the intended behavior during interface design.', 'Path normalization alone does not address changes between validation and write. The implementation needs a coherent filesystem identity rule.', 'Preserve captured dirty inputs across the entire Git checkout, including inputs outside a nested configuration root.'],
        'adr_conflict': 'None. Preserve ADR 0002 nested-root behavior.'
    }
]

coverage = [
    {'area': 'Lane measurement and reuse', 'modules': ['src/crapkit/lanes.py', 'src/crapkit/cli/scoring.py: ownership call sites'],
     'checks': ['Read execution/retry/log flow, declaration mtimes, refusal stamps, measurement input keys, artifact digests, duration scheduling, streaming parsing, scope checks, JUnit provenance, retests and measurement locks.', 'Inspected lane identity, retry/refusal, abort, scheduling and measurement ownership tests. Ran a real lane with a surviving descendant.'],
     'disposition': 'Existing measurement_owner spans execute/parse/stamp and resolves artifact aliases. Clean-input reuse and refusal stamps carry useful depth. EX1 covers remaining process lifetime gap; broad splitting of lanes would relocate the same policies.'},
    {'area': 'Processes, locks and self invocation', 'modules': ['src/crapkit/procs.py', 'src/crapkit/_process_owner.py', 'src/crapkit/locks.py', 'src/crapkit/invocation.py'],
     'checks': ['Read shell literal preparation, launch handshake, timeout/no-progress cleanup, root registration protocol, OS lock adapters and printed interpreter spelling.', 'Ran existing lock, process-owner and self-invocation checks.'],
     'disposition': 'Procs hides real cross-platform behavior; locks has two concrete adapters; invocation encodes documented console/module differences. These pass the deletion test. EX1 identifies unfinished lifetime coverage.'},
    {'area': 'Mutation generation', 'modules': ['src/crapkit/mutate.py'],
     'checks': ['Read language/operator selection, corpus admission, lexer masks, generic-angle protection, changed-line filtering and line replacement.', 'Read mutation language examples and ran all mutation-angle cases.'],
     'disposition': 'Language tokenization and refused ambiguity earn module depth. No suggestion based on helper count or length.'},
    {'area': 'Mutation worker state', 'modules': ['src/crapkit/mutate_pool.py', 'src/crapkit/gitio.py: worktree_add/worktree_reset/worktree_remove'],
     'checks': ['Read dirty-input capture, nested-root projection, seeding, baseline check, kept/temporary pools, OS lock fallback, fan-out, cleanup and deterministic merge.', 'Read real-Git kept/nested worker tests. Proved caller-death overlap and symlink write escape with real Git.'],
     'disposition': 'EX1 and EX2. Keep current one-worker isolation, full-checkout dirty inputs, bounded suites, bytecode handling, stable pool lock and live-peer temporary fallback.'},
    {'area': 'Watch', 'modules': ['src/crapkit/watch.py', 'src/crapkit/cli/admin.py:1599-1667'],
     'checks': ['Read static tracked-corpus selection, directory listings, fallback stats, mtime diff, subprocess rescore, bounded cycles and interruption.', 'Read cycle E2E and shell contracts; ran snapshot tests.'],
     'disposition': 'Sound narrow seam between filesystem snapshot and polling shell. Initial corpus selection is a visible limitation, not a demonstrated defect warranting redesign. No event dependency or per-cycle Git scan proposed.'},
    {'area': 'Test schedule and CI verdict', 'modules': ['tools/testing/run.py', 'tools/testing/ci.py', '.github/workflows/ci.yml', 'crapkit.toml', 'tests/e2e/conftest.py'],
     'checks': ['Read unique output ownership, both-suite schedule, JUnit completion, branch/context combination, incomplete retention, wheel build/install/source hashing, environment isolation, installed-path mapping, baseline ledger backup and verdict readback.', 'Read test_suite_schedule, test_suite_output_ownership, test_ci_verdict, test_ci_baseline_admission, test_ci_failure_evidence and installation contracts.'],
     'disposition': 'Existing modules earn depth. Complete known baseline failures and candidate suite failures remain distinct. Project coverage contexts are intentionally preserved, not forced. Did not run full suites or install wheels.'},
    {'area': 'Release', 'modules': ['tools/release/release.py', 'tools/release/README.md'],
     'checks': ['Read all release code, version table, stage guards, exact tagged HEAD/ledger proof, artifact manifests, destination binding, pending publication protocol, digest readback, Pages recovery and local plugin retry.', 'Read release recovery adapter/tests and indexed guards/destination/retag regression cases.'],
     'disposition': 'Release module earns depth: removing it would distribute version and retry obligations across callers. Single-active-stage constraint is documented; no concurrent-stage finding without operational evidence. No remote requests, release commands or publication performed.'},
    {'area': 'Build, container and dependencies', 'modules': ['pyproject.toml', 'Dockerfile', '.dockerignore'],
     'checks': ['Read package discovery, console entry point, Python floor, runtime and dev extras, subprocess coverage floor, minimal Docker copy/install, Git dependency, unprivileged identity and safe.directory.', 'Read dev/CI dependency contracts; ran Dockerfile and coverage-floor contracts.'],
     'disposition': 'No proved architectural defect. Docker checks are static, and no image build was performed. Unbounded dependency resolution is a release reproducibility tradeoff, not an observed failure.'},
    {'area': 'Generated docs', 'modules': ['tools/docs/generate.py'],
     'checks': ['Read generated schema, version support table, contributor schedule and marker replacement.'],
     'disposition': 'Generator derives operational facts from owning modules, so deletion would restore duplicated facts. No extra registry proposed.'},
    {'area': 'Demo generation', 'modules': ['tools/demo/generate.py', 'tools/demo/demo_repo.py', 'tools/demo/demo_run.py', 'tools/demo/demo_render.py', 'tools/demo/fixture/*', 'tools/demo/history/*', 'tools/demo/steps/heredoc_body.txt', 'tools/demo/README.md'],
     'checks': ['Read fixture/history/config files, fixed commit replay, own-source command capture, redaction, transcript frames, GIF/SVG rendering and font use.', 'Read deterministic rendering, escaping and absolute-path contract tests.'],
     'disposition': 'Real transcript and pure render seam has two output adapters. No generator run or image publication. Bundled font binaries/license were cataloged, not audited for visual fidelity.'},
    {'area': 'Historical coverage reproduction', 'modules': ['tools/notes/pytest_cov7_repro.py', 'tools/notes/pytest_cov7_repro.json'],
     'checks': ['Read version-pinned environments, external rcfile/data placement, subprocess measurement commands and recorded results.'],
     'disposition': 'A focused reproducible historical probe, outside the installed package. Did not repeat network installs or reinterpret old counts as current measurements.'}
]

dismissed = [
    {'idea':'Split lanes or release because each has many helpers', 'reason':'Deleting the module redistributes policy and failure handling. Function counts and file length are not architecture findings.'},
    {'idea':'Always force pytest per-test contexts', 'reason':'The runner deliberately preserves project context policy. Current tests explicitly cover both configured contexts and no contexts. No default instrumentation or overhead change proposed.'},
    {'idea':'Treat every nonzero lane exit as an invalid measurement', 'reason':'Brownfield baseline support deliberately accepts completed test failures with valid coverage/JUnit. Admission and verdict are separate facts.'},
    {'idea':'Make mutation and file-publication locks identical solely because code is similar', 'reason':'Mutation has a deliberate temporary-worktree fallback; shared artifact operations refuse peers. EX1 concerns lifecycle, not cosmetic deduplication.'},
    {'idea':'Treat release concurrency as a new proved failure', 'reason':'README requires one active stage per checkout. No concurrent release invocation was performed and no usage evidence justifies reopening that constraint.'},
    {'idea':'Replace watch polling with filesystem events', 'reason':'Scandir snapshot already has a small tested interface and portable behavior. No measured performance regression in this audit.'},
    {'idea':'Reject every partially overlapping artifact', 'reason':'Current scope judgment only diagnoses zero overlap. Flagged to parent for cross-reader semantics; no stand-alone finding asserted here.'},
    {'idea':'Claim container delivery or dependency resolution is broken', 'reason':'Static contracts passed. No install or Docker build was authorized for this audit; theoretical upstream drift is not a proved defect.'}
]

evidence = {}
for candidate in candidates:
    for location in candidate['files']:
        path = location['path']
        lines = (REPO / path).read_text(encoding='utf-8').splitlines()
        start, end = location['start'], location['end']
        assert 1 <= start <= end <= len(lines), location
        evidence[f'{path}:{start}-{end}'] = '\n'.join(f'{i}: {lines[i-1]}' for i in range(start,end+1))
(HERE / 'source-evidence.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
checks = json.loads((HERE / 'bounded-checks.json').read_text())
report = {
    'scope':'Execution, mutation/watch, maintainer testing/release/demo/docs/notes and build/container/dependency delivery',
    'frozen_commit':'b11e2c165411b5ff9caa6b4b8486aafe477dfeb8',
    'source_root':str(REPO), 'audit_root':str(HERE),
    'candidates':candidates, 'coverage':coverage, 'dismissed':dismissed,
    'verification':{'bounded_checks':{'passed':58,'skipped':1,'seconds':checks['seconds'],'evidence':'bounded-checks.json'},
                    'probes':['mutation-crash-result.json','mutation-symlink-result.json','owned-descendant-result.json'],
                    'root_status':'clean at b11e2c165411b5ff9caa6b4b8486aafe477dfeb8 after probes and selected checks',
                    'limits':['Windows live probes only; POSIX crash semantics remain to verify.', 'No full suites, package installs, Docker builds, remote requests, root edits, commits, releases or publication.', 'Initial descendant probe used an empty Istanbul artifact, correctly refused; corrected probe used a real file record and returned exit 0.']},
    'source_sha256':{path:hashlib.sha256((REPO/path).read_bytes()).hexdigest()
                     for path in sorted({item['path'] for c in candidates for item in c['files']})}
}
(HERE / 'findings.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'candidates':[c['id'] for c in candidates],'coverage_areas':len(coverage),'dismissed':len(dismissed),
                  'output':str(HERE/'findings.json')},indent=2))
