"""Run a bounded selection of current-source contracts without repo writes."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = Path('C:/Users/jfgag/crapkit')
env = {key: value for key, value in os.environ.items()
       if not key.startswith(('COVERAGE_', 'COV_CORE_'))}
env.update(PYTHONPATH=str(REPO / 'src'), PYTHONDONTWRITEBYTECODE='1',
           PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
selected = ['test_watch_snapshot.py', 'test_self_invocation.py', 'test_exclusive_lock.py',
            'test_measurement_owner.py', 'test_mutate_type_angles.py',
            'test_dockerfile_contract.py', 'test_subprocess_coverage_config.py']
command = [sys.executable, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
           '--basetemp', str(HERE / ('pytest-' + str(time.time_ns()))),
           *[str(REPO / 'tests/unit' / name) for name in selected]]
started = time.monotonic()
result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, timeout=45)
(HERE / 'bounded-checks.txt').write_text(result.stdout + result.stderr)
report = {'command': command, 'seconds': round(time.monotonic()-started, 3),
          'exit': result.returncode, 'selected': selected, 'stdout': result.stdout, 'stderr':result.stderr}
(HERE / 'bounded-checks.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
