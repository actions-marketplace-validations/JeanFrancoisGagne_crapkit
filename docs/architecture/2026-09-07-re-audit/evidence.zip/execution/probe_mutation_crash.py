"""Bounded real-Git proof: caller death frees mutation pool before suite death."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = Path('C:/Users/jfgag/crapkit/src')
sys.path.insert(0, str(SOURCE))
from crapkit.mutate_pool import _worktrees

def wait_file(path, seconds=10):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if path.exists():
            return True
        time.sleep(.03)
    return False

def main():
    root = HERE / ('mutation-crash-' + str(time.time_ns()))
    root.mkdir()
    repo = root / 'repo'
    repo.mkdir()
    source = 'def enabled():\n    return True\n'
    (repo / 'm.py').write_text(source)
    (repo / '.gitignore').write_text('.crapkit/\n__pycache__/\n')
    runner = ('from pathlib import Path\nimport os,time\nimport m\n'
              'if not m.enabled():\n'
              f'    Path({str(root / "started")!r}).write_text(str(os.getpid()))\n'
              '    deadline=time.monotonic()+15\n'
              f'    while not Path({str(root / "release")!r}).exists() and time.monotonic()<deadline: time.sleep(.03)\n'
              '    Path("m.py").write_text("CORRUPTED_BY_OLD_SUITE\\n")\n'
              f'    Path({str(root / "finished")!r}).touch()\n')
    (repo / 'runner.py').write_text(runner)
    def git(*args):
        return subprocess.run(['git', '-c', 'core.hooksPath=' + str(root / 'no-hooks'), *args], cwd=repo,
                              check=True, capture_output=True, text=True).stdout
    git('init','-q','-b','main')
    git('add','.')
    git('-c','user.name=Probe','-c','user.email=probe@example.invalid','commit','-qm','probe')
    child_script = root / 'mutation_caller.py'
    child_script.write_text(
        'from pathlib import Path\nfrom types import SimpleNamespace\nimport sys\n'
        'from crapkit.mutate import file_mutants\nfrom crapkit.mutate_pool import run_mutants\n'
        f'root=Path({str(repo)!r})\n'
        'mutant=file_mutants((root / "m.py").read_text(),None,"python")[0]._replace(path="m.py")\n'
        'cfg=SimpleNamespace(mutation_workers=1,mutation_timeout_seconds=20,mutation_command=f\'"{sys.executable}" runner.py\')\n'
        'print(run_mutants(root,cfg,[mutant],lambda *a:None),flush=True)\n')
    env = dict(os.environ, PYTHONPATH=str(SOURCE), PYTHONDONTWRITEBYTECODE='1')
    log = (root / 'caller.log').open('w')
    caller = subprocess.Popen([sys.executable, '-B', str(child_script)], cwd=root, env=env, stdout=log, stderr=log)
    observed = {'source':str(SOURCE), 'probe_root':str(root), 'caller_pid':caller.pid}
    try:
        assert wait_file(root / 'started'), 'mutated suite did not start'
        observed['suite_pid'] = int((root / 'started').read_text())
        caller.terminate()
        caller.wait(timeout=5)
        observed['caller_exit'] = caller.returncode
        with _worktrees(repo, 1) as (tree,):
            observed['new_owner_got_same_pool'] = tree == repo / '.crapkit/mutate-pool/w0'
            observed['new_owner_initial_file'] = (tree / 'm.py').read_text()
            (root / 'release').touch()
            observed['old_suite_finished'] = wait_file(root / 'finished', 5)
            observed['new_owner_file_after_old_suite'] = (tree / 'm.py').read_text()
        observed['source_checkout_unchanged'] = (repo / 'm.py').read_text() == source
    finally:
        (root / 'release').touch()
        if caller.poll() is None:
            caller.terminate()
            caller.wait(timeout=5)
        log.close()
    (HERE / 'mutation-crash-result.json').write_text(json.dumps(observed, indent=2))
    print(json.dumps(observed, indent=2))

if __name__ == '__main__':
    main()
