"""Run a tiny lane with a report that declares more cases than it contains."""
import json
import os
from pathlib import Path
import sys
import tempfile

HERE = Path(__file__).resolve().parent
SOURCE = 'C:/Users/jfgag/crapkit/src'
sys.path.insert(0, SOURCE)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
from crapkit.config import Lane
from crapkit.errors import ToolError
from crapkit.junitparse import passed_test_ids, suite_summary
from crapkit.lanes import run_lane

root = Path(tempfile.mkdtemp(prefix='junit-admission-', dir=HERE))
(root / 'src').mkdir()
(root / 'src' / 'a.py').write_text('def hot():\n    return 1\n', encoding='utf-8')
coverage = json.dumps({'src/a.py': {
    'path': 'src/a.py',
    'fnMap': {'0': {'name': 'hot', 'decl': {'start': {'line': 1}},
                    'loc': {'start': {'line': 1}, 'end': {'line': 2}}}},
    'f': {'0': 1}, 'branchMap': {}, 'b': {},
    'statementMap': {'0': {'start': {'line': 2}, 'end': {'line': 2}}},
    's': {'0': 1},
}})
xml = '<testsuite name="probe" tests="10"><testcase classname="tests" name="one"/></testsuite>'
(root / 'runner.py').write_text(
    'from pathlib import Path\n'
    f'Path("cov.json").write_text({coverage!r}, encoding="utf-8")\n'
    f'Path("junit.xml").write_text({xml!r}, encoding="utf-8")\n', encoding='utf-8')
lane = Lane(name='probe', command=f'"{sys.executable}" runner.py',
            artifact='cov.json', parser='istanbul', scopes=('src',),
            results_artifact='junit.xml')
outcome = run_lane(root, lane, scope_paths={'src': ('src/a.py',)})
failed, counts = suite_summary(xml)
data = {'root': str(root), 'reuse_artifact': False, 'declared_tests': 10,
        'observed_testcases': 1, 'lane_accepted': True,
        'coverage_entries': len(outcome.coverage), 'provenance': outcome.provenance,
        'suite_summary': {'failed': sorted(failed), 'counts': counts}}
try:
    data['passed_test_ids'] = sorted(passed_test_ids(xml))
except ToolError as exc:
    data['passed_test_ids_error'] = str(exc)
(HERE / 'junit-admission-result.json').write_text(json.dumps(data, indent=2), encoding='utf-8')
print(json.dumps(data, indent=2))
