"""Reproduce an override plus diff-coverage refusal through the public CLI."""
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import tempfile

WORK = Path(__file__).resolve().parent
PYTHON = WORK.parent / 'implementation/configured-runtime/venv/Scripts/python.exe'
SOURCE = Path(r'C:\Users\jfgag\crapkit\src')


def git(root, *args):
    return subprocess.check_output(['git', '-c', 'user.name=Audit', '-c',
                                    'user.email=audit@example.invalid', *args], cwd=root)


def run(root, name, *args):
    result = subprocess.run([str(PYTHON), '-m', 'crapkit', *args, '--repo', str(root), '--json'],
                            cwd=root, env={**os.environ, 'PYTHONPATH': str(SOURCE)}, capture_output=True)
    (WORK / f'verdict-{name}.stdout.json').write_bytes(result.stdout)
    (WORK / f'verdict-{name}.stderr.txt').write_bytes(result.stderr)
    return dict(exit=result.returncode, result=json.loads(result.stdout))


def artifact(root, lines, branches):
    missing = list(range(1, lines+1))
    summary = dict(num_branches=branches, covered_branches=0, num_statements=lines, covered_lines=0)
    region = dict(start_line=1, executed_lines=[], missing_lines=missing, summary=summary)
    data = dict(meta=dict(branch_coverage=True, version='7.16.0'),
                files={'src/app.py': dict(functions={'f': region}, executed_lines=[], missing_lines=missing)})
    (root / '.crapkit/cov.json').write_text(json.dumps(data))


def prepare(root):
    (root / 'src').mkdir()
    (root / '.crapkit').mkdir()
    (root / '.gitignore').write_text('.crapkit/\n')
    (root / 'crapkit.toml').write_text('''[crapkit]
target=6
diff_uncovered_max=0
alert_command="cmd /c exit 0"
[[scope]]
name="src"
paths=["src"]
languages=["python"]
[[lane]]
name="py"
command="echo unused"
artifact=".crapkit/cov.json"
parser="coveragepy"
scopes=["src"]
''')
    (root / 'src/app.py').write_text('def f(x):\n    return x\n')
    git(root, 'init', '-q')
    git(root, 'add', '.')
    git(root, 'commit', '-qm', 'baseline')


def main():
    root = Path(tempfile.mkdtemp(prefix='verdict-probe-', dir=WORK))
    prepare(root)
    artifact(root, 2, 0)
    baseline = run(root, 'baseline', 'coverage', '--reuse-artifacts')
    assert baseline['exit'] == 0, baseline
    body = 'def f(x):\n' + ''.join(f'    if x == {n}:\n        return {n}\n' for n in range(6)) + '    return -1\n'
    (root / 'src/app.py').write_text(body)
    artifact(root, 14, 12)
    refused = run(root, 'control', 'verify', '--reuse-artifacts', '--no-tighten')
    granted = run(root, 'override', 'verify', '--reuse-artifacts', '--no-tighten', '--override', 'audit fixture only')
    with sqlite3.connect(root / '.crapkit/crap.sqlite') as db:
        ledger = db.execute('SELECT id,kind,verdict_ok,findings FROM runs ORDER BY id').fetchall()
    result = dict(repo=str(root), baseline=baseline, control=refused, override=granted, ledger=ledger)
    (WORK / 'verdict-result.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
